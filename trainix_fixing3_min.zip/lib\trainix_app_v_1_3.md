# Trainix App Spec v1.3

## Product Brief
**Nama Aplikasi:** Trainix  
**Platform:** Android  
**Target User:** Atlet dan Pelatih  
**Masalah:** Pencatatan intensitas latihan manual dan tidak konsisten.  
**Solusi:** Digitalisasi pencatatan, manajemen program latihan tim, input skor intensitas oleh pelatih, reminder target, dan leaderboard mingguan dengan 2 skor (konsistensi + intensitas).  
**Fitur Utama:**  
- Register/Login unik  
- Multi-team dengan role berbeda (Athlete/Coach)  
- Program Latihan (preset mingguan, kategori dihitung/tidak)  
- Input Intensitas oleh Coach  
- Reminder (personal & tim)  
- Leaderboard dengan breakdown skor  
**Tech Stack:** Flutter, Firebase Auth, Firestore  
**Figma Link:** [Trainix Figma Design](https://www.figma.com/design/nH8nCKFqzsZDZKTFhHU4SX/Trainix?node-id=0-1)

---

## User Stories
### Epic: User Management
- Sebagai pengguna, saya ingin mendaftar/login dengan email & username unik.
- Sebagai pengguna, saya ingin mengedit profil (usia, gender, foto, tinggi, berat).

### Epic: Team Management
- Sebagai Coach, saya ingin membuat tim dengan detail lengkap → otomatis menjadi **Coach Owner**.
- Sebagai pengguna, saya ingin join tim via kode → role default **Athlete**, status **pending** hingga disetujui Coach.
- Sebagai Coach, saya ingin approve/reject anggota.

### Epic: Role Management
- Sebagai Coach Owner, saya ingin mempromosikan/demote anggota.  
- Sebagai pengguna, saya ingin punya role berbeda di tiap tim.

### Epic: Program Latihan
- Sebagai Coach, saya ingin membuat program mingguan dengan kategori (Kardio, Strength, Teknik, Tarung, Recovery/Flexibility).
- Sebagai Athlete, saya ingin melihat jadwal latihan.

### Epic: Intensitas Latihan
- Sebagai Coach, saya ingin input log intensitas atlet berdasarkan rumus HRR (Tanaka + Karvonen).
- Sebagai Athlete, saya ingin melihat hasil intensitas per sesi.

### Epic: Leaderboard
- Sebagai Athlete, saya ingin melihat ranking mingguan berdasarkan konsistensi & intensitas.  
- Sebagai Coach, saya ingin melihat detail breakdown per atlet.

### Epic: Reminder
- Sebagai Athlete, saya ingin membuat reminder pribadi.  
- Sebagai Coach, saya ingin membuat reminder untuk tim/atlet.

---

## Product Backlog (Ringkas)
| ID | Feature | User Story | Priority |
|----|---------|------------|----------|
| 1 | Register/Login | Mendaftar/login unik | High |
| 2 | Edit Profile | Update data diri | High |
| 3 | Create/Join Team | Membuat/join tim | High |
| 4 | Approve Members | Coach approve join | High |
| 5 | Role Assignment | Promote/demote role | High |
| 6 | Manage Program | Buat program mingguan | High |
| 7 | Input Intensitas | Coach input skor HRR | High |
| 8 | View Intensitas | Athlete lihat hasil | High |
| 9 | Leaderboard | Ranking konsistensi+intensitas | High |
| 10 | Reminder | Reminder personal/tim | Medium |

---

## Firestore Schema (Ringkas)
### users/{userId}
```
id, email, username, password_hash, name, usia, gender, photo_url, tinggi, berat, created_at, updated_at
```

### teams/{teamId}
```
id, name, cabor, kontingen, event, tgl_mulai, tgl_selesai, created_by, config{target_days, weights, allow_recovery}, created_at, updated_at
```

### teams/{teamId}/members/{userRoleId}
```
id, user_id, role ("Athlete"|"Coach"), isOwner, status ("pending"|"approved"), date_joined, approved_by
```

### teams/{teamId}/programs/{programId}
```
id, week_anchor, template, categories, target_days, created_by
```

### teams/{teamId}/trainingLogs/{logId}
```
id, programId, athleteId, score, hrr_band, date, input_by
```

### teams/{teamId}/reminders/{reminderId}
```
id, title, description, target_date, created_by, status
```

### leaderboards/{leaderboardId}
```
id, team_id, week, athleteId, scores {consistency, intensity, total}, eligible, breakdown, last_updated
```

---

## ERD (teks)
| Entity | Attributes |
|--------|------------|
| User | id, email, username, password_hash, name, usia, gender, photo_url, tinggi, berat |
| Team | id, name, cabor, kontingen, event, tgl_mulai, tgl_selesai, created_by, config |
| UserTeamRole | id, user_id, team_id, role, isOwner, status, date_joined, approved_by |
| Program | id, team_id, week_anchor, template, categories, target_days, created_by |
| TrainingLog | id, team_id, programId, athleteId, score, hrr_band, date, input_by |
| Reminder | id, team_id, athleteId, created_by, title, description, target_date, status |
| Leaderboard | id, team_id, week, athleteId, scores {consistency, intensity, total}, eligible, breakdown, last_updated |

Relasi:  
- User 1..* UserTeamRole  
- Team 1..* UserTeamRole  
- Team 1..* Program  
- Team 1..* TrainingLog  
- Team 1..* Reminder  
- Team 1..* Leaderboard  

---

## Catatan Pembaruan v1.3
- **Leaderboard**: mendukung 2 skor (konsistensi & intensitas), plus total. Ada field `eligible` & `breakdown` (cat_summary per kategori, day_score, notes).  
- **ProgramPlan/Team.config**: target_days bisa fleksibel (tidak harus Senin–Sabtu). Ada toggle kategori dihitung/tidak (misal Recovery/Flexibility excluded).  
- **Audit fields**: standar created_at/by & updated_at/by.  
- **Rumus HRR**: pakai Tanaka (HRmax) + Karvonen (HRR).  
- **Security**: hanya Coach bisa input/edit log & program. Athlete read-only.

---

## QA Checklist v1.3
1. **Data & Agregasi**  
   - Pastikan week_anchor selalu Senin (atau sesuai config).  
   - Jika program mulai/berakhir di tengah minggu → skor prorata.  
   - Recovery/Flexibility tidak dihitung ke intensitas.  
   - Skor capped 100/minggu.  
   - Idempotensi: re-run agregasi tidak mengubah skor final.

2. **Config & Overrides**  
   - ProgramPlan override Team.config.  
   - Weights bisa diubah oleh Coach → terapkan ke minggu berikutnya.  
   - Toggle kategori: pastikan konsistensi antar minggu.

3. **Firestore & Security**  
   - Hanya Coach bisa write TrainingLog, Program, Leaderboard.  
   - Audit fields tidak boleh kosong.  
   - Index Firestore: composite untuk team_id+week.

4. **UI/UX & Sorting**  
   - Default sort leaderboard: total desc, tie-break → intensitas, lalu konsistensi.  
   - Tampilkan badge “Eligible/Not Eligible”.  
   - Tooltip breakdown saat klik nama atlet.  
   - Filter by minggu.  
   - Empty state → tampilkan pesan “Belum ada data minggu ini”.

5. **Edge Cases**  
   - Atlet join di tengah minggu.  
   - Recovery-only week.  
   - Timezone per tim.  
   - Backfill log lama.  
   - Outlier skor >300 → normalisasi.

6. **Reliability & Perf**  
   - Agregasi debounce (hanya 1x per update batch).  
   - Retry mechanism jika gagal update leaderboard.  
   - Cek latency saat tim >200 atlet.

7. **QA Data Seed**  
   - Dataset dummy: 6 atlet, 1 minggu penuh, 1 minggu parsial.  
   - Simulasi skor expected untuk validasi otomatis.
