# Trainix App Spec v3

## Product Brief
- **Nama Aplikasi:** Trainix  
- **Platform:** Flutter (Android + Web)  
- **Target User:** Atlet & Pelatih  
- **Problem:** Manual logging → rawan error, tidak real-time  
- **Solution:** Firestore-based training management (multi-team, role, intensities with inputBy)  
- **Status:** Sprint 3 selesai, implementasi fitur utama done 80%  

---

## Roadmap & Backlog Status
| ID | Feature | Status |
|----|---------|--------|
| 1 | Auth (Register/Login, Reset) | ✅ Done |
| 2 | Teams (Create/Join/Leave, Role Management) | ✅ Done |
| 3 | Programs (CRUD by Coach) | ✅ Done |
| 4 | Intensities (Coach Input) | ✅ Done |
| 5 | Intensities (Athlete Self Input) | ⚠️ In Progress |
| 6 | Leaderboard | ⏳ Pending |
| 7 | Reminder | ✅ Done |
| 8 | Multi-role per Team | ✅ Done |

---

## Firestore Schema
/users/{uid}
    { name, email, username, photo_url, gender, usia }

/teams/{teamId}
    { name, cabor, kontingen, event, tgl_mulai, tgl_selesai, created_by }

/members/{userId}
    { role, isOwner, status, date_joined, approved_by }

/programs/{programId}
    { date, description, categories, created_by }

/intensities/{intensityId}
    { programId, athleteId, score, date, inputBy }  <-- CoachID / AthleteID

/reminders/{reminderId}
    { athleteId, created_by, title, description, target_date, status }

/leaderboard/{leaderboardId}
    { team_id, athleteId, total_score, last_updated }


---

## Tech Stack & Directory Layout
- **Tech:** Flutter 3.x, Provider, Firebase Auth, Cloud Firestore.  
- **Dir Layout:**  
  - `/models/` (User, Team, Program, Intensity, Reminder, Leaderboard)  
  - `/services/` (auth_service.dart, firestore_service.dart)  
  - `/providers/` (auth_provider.dart, team_provider.dart, program_provider.dart, intensity_provider.dart)  
  - `/ui/` (screens, widgets, forms)  
  - `/extensions/` (helper utils)

---

## Implementation Notes
- **inputBy** diperluas: awalnya hanya Coach (v2), sekarang Athlete juga bisa input.  
- Firestore rules perlu validasi agar Athlete hanya bisa input data **dirinya sendiri**, Coach bisa input untuk semua Athlete dalam tim.  
- Sync dengan skripsi v1.3 agar tidak terjadi inkonsistensi istilah.
