# Trainix App Spec v1

## Product Brief
**Nama Aplikasi:** Trainix  
**Platform:** Android  
**Target User:** Atlet dan Pelatih  
**Masalah:** Pencatatan intensitas latihan manual.  
**Solusi:** Digitalisasi pencatatan, program latihan tim, input skor oleh pelatih, reminder target, leaderboard.  
**Fitur Utama:** Register/Login unik, Multi-team dengan role berbeda, Program Latihan, Input Intensitas, Reminder, Leaderboard.  
**Tech Stack:** Flutter/Kotlin, Firebase Auth & Firestore.  
**Figma Link:** [Trainix Figma Design](https://www.figma.com/design/nH8nCKFqzsZDZKTFhHU4SX/Trainix?node-id=0-1&t=kopJMGymA6MPm9nr-1)

---

## User Stories
### Epic: User Management
- Sebagai pengguna, saya ingin mendaftar dan login dengan email dan username unik.
- Sebagai Atlet, saya ingin mengedit profil.
- Sebagai Pelatih, saya ingin mengedit profil.

### Epic: Team Management
- Sebagai Pelatih, saya ingin membuat Team dengan detail lengkap.
- Sebagai Atlet, saya ingin bergabung ke Team melalui kode.
- Sebagai Pelatih, saya ingin menyetujui atau menolak pendaftaran.
- Sebagai Pelatih, saya ingin mengelola daftar Atlet dan Pelatih.

### Epic: Role Management
- Sebagai Pelatih, saya ingin menetapkan role Atlet/Pelatih pada anggota Team.
- Sebagai User, saya ingin memiliki role berbeda pada setiap Team.

### Epic: Program Latihan
- Sebagai Pelatih, saya ingin membuat dan mengedit program latihan harian.
- Sebagai Atlet, saya ingin melihat jadwal latihan harian Team.

### Epic: Intensitas Latihan
- Sebagai Pelatih, saya ingin menginput skor intensitas Atlet.
- Sebagai Atlet, saya ingin melihat hasil intensitas latihan.

### Epic: Leaderboard
- Sebagai Atlet, saya ingin melihat peringkat intensitas.
- Sebagai Pelatih, saya ingin memantau leaderboard.

### Epic: Reminder
- Sebagai Atlet, saya ingin membuat reminder pribadi.
- Sebagai Pelatih, saya ingin membuat reminder untuk Atlet.
- Sebagai Atlet, saya ingin menandai reminder selesai.
- Sebagai Atlet, saya ingin melihat status reminder.

---

## Product Backlog
| ID | Feature | User Story | Priority |
|----|---------|------------|----------|
| 1 | Register/Login | Mendaftar dan login dengan email & username unik | High |
| 2 | Edit Profile | Mengedit profil user | High |
| 3 | Create Team | Pelatih membuat Team dengan detail | High |
| 4 | Join Team | Atlet bergabung melalui kode | High |
| 5 | Approve/Reject Members | Pelatih mengelola permintaan join | High |
| 6 | Role Assignment | Pelatih menetapkan role anggota | High |
| 7 | View Teams | Melihat semua Team yang diikuti | High |
| 8 | Manage Program Latihan | Membuat & edit program latihan | High |
| 9 | View Program Latihan | Atlet melihat jadwal latihan | High |
| 10 | Input Intensitas | Pelatih input skor Atlet | High |
| 11 | View Intensitas | Atlet melihat hasil intensitas | High |
| 12 | Leaderboard | Melihat peringkat Atlet | Medium |
| 13 | Create Reminder | Membuat reminder | Medium |
| 14 | Mark Reminder | Menandai reminder selesai | Medium |
| 15 | Multi-role Support | Role berbeda di tiap Team | Medium |
| 16 | Leave Team | Atlet keluar dari Team | Medium |

---

## Firestore / Database Schema
### Koleksi: users
```
{
  name, email (unik), username (unik), password_hash, usia, gender, photo_url
}
```

### Koleksi: teams
```
{
  name, cabor, kontingen, event, tgl_mulai, tgl_selesai, created_by
}
```

### Subkoleksi: members (/teams/{teamId}/members/{userId})
```
{
  role: "Atlet" | "Pelatih",
  status: "pending" | "approved" | "left",
  date_joined,
  approved_by
}
```

### Subkoleksi: programs
```
{
  date, description, categories, created_by
}
```

### Subkoleksi: intensities
```
{
  programId, athleteId, score, date, input_by
}
```

### Subkoleksi: reminders
```
{
  athleteId, created_by, title, description, target_date, status
}
```

### Koleksi: leaderboard
```
{
  total_score, last_updated
}
```

---

## ERD (teks/tabular)
### Entities
| Entity | Attributes |
|--------|------------|
| User | id, email (unik), username (unik), password_hash, name, usia, gender, photo_url |
| Team | id, name, cabor, kontingen, event, tgl_mulai, tgl_selesai, created_by |
| UserTeamRole | id, user_id, team_id, role, status, date_joined, approved_by |
| Program | id, team_id, date, description, categories, created_by |
| Intensitas | id, team_id, programId, athleteId, score, date, input_by |
| Reminder | id, team_id, athleteId, created_by, title, description, target_date, status |
| Leaderboard | id, team_id, athleteId, total_score, last_updated |

### Relasi
- User 1..* UserTeamRole
- Team 1..* UserTeamRole
- Team 1..* Program
- Team 1..* Intensitas
- Team 1..* Reminder
- Team 1..* Leaderboard
- UserTeamRole menentukan role per user+team

