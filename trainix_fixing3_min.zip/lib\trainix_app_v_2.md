# Trainix App Spec v2

## Product Brief
**Nama Aplikasi:** Trainix  
**Platform:** Android  
**Target User:** Atlet dan Pelatih  
**Masalah:** Pencatatan intensitas latihan manual.  
**Solusi:** Digitalisasi pencatatan, program latihan tim, input skor oleh pelatih, reminder target, leaderboard.  
**Fitur Utama:** Register/Login unik, Multi-team dengan role berbeda, Program Latihan, Input Intensitas, Reminder, Leaderboard.  
**Tech Stack:** Flutter, Firebase Auth & Firestore.  
**Status:** Implementasi Core Features Selesai  
**Figma Link:** [Trainix Figma Design](https://www.figma.com/design/nH8nCKFqzsZDZKTFhHU4SX/Trainix?node-id=0-1&t=kopJMGymA6MPm9nr-1)

---

## Status Implementasi
### ✅ Fitur yang Sudah Diimplementasikan
- **Sistem Otentikasi:** Login, Register, Email Verification, Forgot Password
- **Manajemen Pengguna:** User Profile dengan model lengkap
- **Manajemen Tim:** Team creation, management dengan role-based access
- **Program Pelatihan:** Training program management
- **Pelacakan Intensitas:** Training intensity tracking dan scoring
- **Leaderboard:** Sistem peringkat atlet
- **Sistem Pengingat:** Reminder management untuk atlet dan pelatih
- **Komponen UI:** Comprehensive UI components dan pages
- **Infrastruktur:** Provider pattern, Services, Error handling

### ⚠️ Isu yang Perlu Diperbaiki
- **Manajemen Rute:** Routes tidak terdefinisi di main.dart (error navigasi)
- **Alur Otentikasi:** AuthWrapper perlu penyesuaian dengan rute

### 🔄 Perubahan dari v1
- **Model Enhancement:** Struktur data lebih robust dengan copyWith methods
- **Arsitektur:** Implementasi Provider pattern untuk state management
- **Services Layer:** Dedicated services untuk setiap domain
- **UI Structure:** Organized component-based UI architecture

---

## User Stories - Status Implementasi
### Epic: User Management ✅
- ✅ Sebagai pengguna, saya ingin mendaftar dan login dengan email dan username unik.
- ✅ Sebagai Atlet, saya ingin mengedit profil.
- ✅ Sebagai Pelatih, saya ingin mengedit profil.

### Epic: Team Management ✅
- ✅ Sebagai Pelatih, saya ingin membuat Team dengan detail lengkap.
- ✅ Sebagai Atlet, saya ingin bergabung ke Team melalui kode.
- ✅ Sebagai Pelatih, saya ingin menyetujui atau menolak pendaftaran.
- ✅ Sebagai Pelatih, saya ingin mengelola daftar Atlet dan Pelatih.

### Epic: Role Management ✅
- ✅ Sebagai Pelatih, saya ingin menetapkan role Atlet/Pelatih pada anggota Team.
- ✅ Sebagai User, saya ingin memiliki role berbeda pada setiap Team.

### Epic: Program Latihan ✅
- ✅ Sebagai Pelatih, saya ingin membuat dan mengedit program latihan harian.
- ✅ Sebagai Atlet, saya ingin melihat jadwal latihan harian Team.

### Epic: Intensitas Latihan ✅
- ✅ Sebagai Pelatih, saya ingin menginput skor intensitas Atlet.
- ✅ Sebagai Atlet, saya ingin melihat hasil intensitas latihan.

### Epic: Leaderboard ✅
- ✅ Sebagai Atlet, saya ingin melihat peringkat intensitas.
- ✅ Sebagai Pelatih, saya ingin memantau leaderboard.

### Epic: Reminder ✅
- ✅ Sebagai Atlet, saya ingin membuat reminder pribadi.
- ✅ Sebagai Pelatih, saya ingin membuat reminder untuk Atlet.
- ✅ Sebagai Atlet, saya ingin menandai reminder selesai.
- ✅ Sebagai Atlet, saya ingin melihat status reminder.

---

## Product Backlog - Status Update
| ID | Feature | User Story | Priority | Status |
|----|---------|------------|----------|--------|
| 1 | Register/Login | Mendaftar dan login dengan email & username unik | High | ✅ Done |
| 2 | Edit Profile | Mengedit profil user | High | ✅ Done |
| 3 | Create Team | Pelatih membuat Team dengan detail | High | ✅ Done |
| 4 | Join Team | Atlet bergabung melalui kode | High | ✅ Done |
| 5 | Approve/Reject Members | Pelatih mengelola permintaan join | High | ✅ Done |
| 6 | Role Assignment | Pelatih menetapkan role anggota | High | ✅ Done |
| 7 | View Teams | Melihat semua Team yang diikuti | High | ✅ Done |
| 8 | Manage Program Latihan | Membuat & edit program latihan | High | ✅ Done |
| 9 | View Program Latihan | Atlet melihat jadwal latihan | High | ✅ Done |
| 10 | Input Intensitas | Pelatih input skor Atlet | High | ✅ Done |
| 11 | View Intensitas | Atlet melihat hasil intensitas | High | ✅ Done |
| 12 | Leaderboard | Melihat peringkat Atlet | Medium | ✅ Done |
| 13 | Create Reminder | Membuat reminder | Medium | ✅ Done |
| 14 | Mark Reminder | Menandai reminder selesai | Medium | ✅ Done |
| 15 | Multi-role Support | Role berbeda di tiap Team | Medium | ✅ Done |
| 16 | Leave Team | Atlet keluar dari Team | Medium | ✅ Done |
| 17 | Route Management | Fix navigasi dan rute aplikasi | High | ⚠️ In Progress |

---

## Firestore / Database Schema (Updated)
### Koleksi: users
{
id: string,
fullName: string,
email: string (unik),
role: "Athlete" | "Coach",
profileImageUrl?: string,
bio?: string,
joinDate: Timestamp,
preferences: Map<string, dynamic>
}


### Koleksi: user_team_roles
{
id: string,
userId: string,
teamId: string,
role: "Athlete" | "Coach",
joinedAt: Timestamp,
isActive: boolean
}

### Koleksi: training_programs

{
id: string,
teamId: string,
date: Timestamp,
description: string,
categories: List,
createdBy: string
}

### Koleksi: training_intensities
{
id: string,
programId: string,
athleteId: string,
score: double,
date: Timestamp,
inputBy: string
}

### Koleksi: reminders
{
id: string,
title: string,
description: string,
targetDate: Timestamp,
isCompleted: boolean,
createdBy: string,
assignedTo?: string
}

### Koleksi: leaderboard_entries
{
id: string,
athleteId: string,
teamId: string,
totalScore: double,
rank: int,
lastUpdated: Timestamp
}

## Arsitektur Teknis
### Struktur Direktori
lib/
├── models/           # Data models
├── services/         # Business logic & API calls
├── providers/        # State management
├── ui/              # User interface
│   ├── authentication/
│   ├── components/
│   ├── team_management/
│   ├── training/
│   └── user_management/
└── extensions/      # Utility extensions


### Tech Stack Implemented
- **Frontend:** Flutter
- **Backend:** Firebase (Auth, Firestore)
- **State Management:** Provider Pattern
- **Architecture:** Service-Provider-UI Pattern

---

## Next Steps / Roadmap
### Immediate Fixes (High Priority)
1. **Fix Route Management:** Implement proper routes in main.dart
2. **Auth Flow:** Ensure smooth navigation between auth states
3. **Testing:** Comprehensive testing of all features

### Future Enhancements (Medium Priority)
1. **Performance Optimization:** Optimize Firestore queries
2. **Offline Support:** Implement local caching
3. **Push Notifications:** Enhanced notification system
4. **Analytics:** User behavior tracking

### Long-term Goals (Low Priority)
1. **Multi-platform:** iOS support
2. **Advanced Features:** AI-powered training recommendations
3. **Integration:** Third-party fitness device integration

