import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/program.dart';
import '../services/program_service.dart';
import '../utils/datetime_x.dart';

class ProgramProvider with ChangeNotifier {
  final ProgramService _programService = ProgramService();
  
  List<Program> _programs = [];
  bool _isLoading = false;
  String? _errorMessage;

  List<Program> get programs => _programs;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  // Load all programs for a team
  Future<void> loadProgramsByTeam(String teamId) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      _programService.getTeamPrograms(teamId).listen((programs) {
        _programs = programs;
        _isLoading = false;
        notifyListeners();
      });
    } catch (e) {
      _errorMessage = 'Failed to load programs: ${e.toString()}';
      _isLoading = false;
      notifyListeners();
    }
  }

  // Load programs by week
  Future<void> loadProgramsByWeek(String teamId, DateTime weekStart) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      // Convert DateTime to Timestamp for Firestore query
      final weekTimestamp = asTimestamp(weekStart)!;
      _programService.getProgramsByWeek(teamId, weekTimestamp).listen((programs) {
        _programs = programs;
        _isLoading = false;
        notifyListeners();
      });
    } catch (e) {
      _errorMessage = 'Failed to load programs: ${e.toString()}';
      _isLoading = false;
      notifyListeners();
    }
  }

  // Create new program
  Future<bool> createProgram(Program program) async {
    try {
      final programId = await _programService.createProgram(program);
      if (programId != null) {
        // Add to local list with the new ID
        final newProgram = program.copyWith(id: programId);
        _programs.add(newProgram);
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      _errorMessage = 'Failed to create program: ${e.toString()}';
      notifyListeners();
      return false;
    }
  }

  // Update program
  Future<bool> updateProgram(String programId, Map<String, dynamic> data) async {
    try {
      final success = await _programService.updateProgram(programId, data);
      if (success) {
        // Update local list
        final index = _programs.indexWhere((p) => p.id == programId);
        if (index != -1) {
          // Reload the updated program
          final updatedProgram = await _programService.getProgram(programId);
          if (updatedProgram != null) {
            _programs[index] = updatedProgram;
            notifyListeners();
          }
        }
      }
      return success;
    } catch (e) {
      _errorMessage = 'Failed to update program: ${e.toString()}';
      notifyListeners();
      return false;
    }
  }

  // Delete program
  Future<bool> deleteProgram(String programId) async {
    try {
      final success = await _programService.deleteProgram(programId);
      if (success) {
        _programs.removeWhere((p) => p.id == programId);
        notifyListeners();
      }
      return success;
    } catch (e) {
      _errorMessage = 'Failed to delete program: ${e.toString()}';
      notifyListeners();
      return false;
    }
  }

  // Get program by ID
  Program? getProgramById(String programId) {
    try {
      return _programs.firstWhere((p) => p.id == programId);
    } catch (e) {
      return null;
    }
  }

  // Get programs by week (local filter)
  List<Program> getProgramsByWeek(DateTime weekStart) {
    return _programs.where((program) {
      return isSameWeek(program.weekAnchor, weekStart);
    }).toList();
  }

  // Helper method untuk membandingkan minggu
  bool isSameWeek(Timestamp timestamp, DateTime date2) {
    final date1 = asDateTime(timestamp)!;
    final startOfWeek1 = date1.subtract(Duration(days: date1.weekday - 1));
    final startOfWeek2 = date2.subtract(Duration(days: date2.weekday - 1));
    
    return startOfWeek1.year == startOfWeek2.year &&
           startOfWeek1.month == startOfWeek2.month &&
           startOfWeek1.day == startOfWeek2.day;
  }

  // Add wrapper method for UI compatibility
  Future<void> loadTeamPrograms(String teamId) async {
    await loadProgramsByTeam(teamId);
  }
}