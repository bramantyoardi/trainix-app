import 'package:cloud_firestore/cloud_firestore.dart';

/// Helper functions for converting between Timestamp and DateTime
DateTime? asDateTime(dynamic v) =>
  v is Timestamp ? v.toDate() : (v is DateTime ? v : null);

Timestamp? asTimestamp(DateTime? v) =>
  v == null ? null : Timestamp.fromDate(v);

/// Extension for Timestamp to provide DateTime-like methods
extension TimestampX on Timestamp {
  bool isBeforeDateTime(DateTime other) => toDate().isBefore(other);
  bool isAfterDateTime(DateTime other) => toDate().isAfter(other);
  int get day => toDate().day;
  int get month => toDate().month;
  int get year => toDate().year;
  
  // Additional compatibility methods
  bool isBeforeDate(DateTime other) => toDate().isBefore(other);
  bool isAfterDate(DateTime other) => toDate().isAfter(other);
  int get day$ => toDate().day;
  int get month$ => toDate().month;
  int get year$ => toDate().year;
}

/// Extension for DateTime to provide Timestamp conversion
extension DateTimeX on DateTime {
  Timestamp asTimestamp() => Timestamp.fromDate(this);
}