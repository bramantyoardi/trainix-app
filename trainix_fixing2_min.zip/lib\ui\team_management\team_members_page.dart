import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/team_provider.dart';

class TeamMembersPage extends StatefulWidget {
  final Map<String, dynamic> teamData;
  final List<Map<String, dynamic>> members;

  const TeamMembersPage({
    super.key,
    required this.teamData,
    required this.members,
  });

  @override
  State<TeamMembersPage> createState() => _TeamMembersPageState();
}

class _TeamMembersPageState extends State<TeamMembersPage> {
  late List<Map<String, dynamic>> members;
  String selectedFilter = 'Semua';

  @override
  void initState() {
    super.initState();
    members = List.from(widget.members);
  }

  @override
  Widget build(BuildContext context) {
    final isCoach = widget.teamData['role'] == 'Pelatih';
    final filteredMembers = _getFilteredMembers();

    return Scaffold(
      backgroundColor: const Color(0xFF002122),
      appBar: AppBar(
        backgroundColor: const Color(0xFF002122),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Anggota Tim',
          style: TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            _buildFilterTabs(),
            _buildMemberStats(),
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: filteredMembers.length,
                itemBuilder: (context, index) {
                  return _buildMemberCard(filteredMembers[index], isCoach);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterTabs() {
    final filters = ['Semua', 'Pelatih', 'Atlet', 'Pending'];

    return Container(
      height: 50,
      margin: const EdgeInsets.all(16),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: filters.length,
        itemBuilder: (context, index) {
          final filter = filters[index];
          final isSelected = selectedFilter == filter;

          return Container(
            margin: const EdgeInsets.only(right: 8),
            child: FilterChip(
              label: Text(
                filter,
                style: TextStyle(
                  color: isSelected ? Colors.white : Colors.white70,
                  fontFamily: 'Poppins',
                  fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                ),
              ),
              selected: isSelected,
              onSelected: (selected) {
                setState(() {
                  selectedFilter = filter;
                });
              },
              backgroundColor: const Color(0xFF1A4747),
              selectedColor: const Color(0xFF4CAF50),
              checkmarkColor: Colors.white,
              side: BorderSide(
                color: isSelected ? const Color(0xFF4CAF50) : Colors.white24,
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildMemberStats() {
    final approvedCount =
        members.where((m) => m['status'] == 'approved').length;
    final pendingCount = members.where((m) => m['status'] == 'pending').length;
    final coachCount = members
        .where((m) => m['role'] == 'Pelatih' && m['status'] == 'approved')
        .length;
    final athleteCount = members
        .where((m) => m['role'] == 'Atlet' && m['status'] == 'approved')
        .length;

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1A4747),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildStatItem('Total', '$approvedCount', Colors.white),
          _buildStatItem('Pelatih', '$coachCount', const Color(0xFF4CAF50)),
          _buildStatItem('Atlet', '$athleteCount', const Color(0xFF2196F3)),
          if (pendingCount > 0)
            _buildStatItem('Pending', '$pendingCount', Colors.orange),
        ],
      ),
    );
  }

  Widget _buildStatItem(String label, String count, Color color) {
    return Column(
      children: [
        Text(
          count,
          style: TextStyle(
            color: color,
            fontSize: 20,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w700,
          ),
        ),
        Text(
          label,
          style: const TextStyle(
            color: Colors.white70,
            fontSize: 12,
            fontFamily: 'Poppins',
          ),
        ),
      ],
    );
  }

  Widget _buildMemberCard(Map<String, dynamic> member, bool isCoach) {
    final isPending = member['status'] == 'pending';

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1A4747),
        borderRadius: BorderRadius.circular(12),
        border: isPending
            ? Border.all(color: Colors.orange.withOpacity(0.3), width: 1)
            : null,
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 25,
            backgroundImage: AssetImage(member['photo']),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  member['name'],
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    _buildRoleBadge(member['role']),
                    const SizedBox(width: 8),
                    if (isPending)
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(
                          color: Colors.orange.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Text(
                          'Pending',
                          style: TextStyle(
                            color: Colors.orange,
                            fontSize: 10,
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  'Bergabung: ${member['joinDate']}',
                  style: const TextStyle(
                    color: Colors.white54,
                    fontSize: 12,
                    fontFamily: 'Poppins',
                  ),
                ),
              ],
            ),
          ),
          if (isCoach && isPending) ...[
            IconButton(
              onPressed: () => _approveMember(member),
              icon: const Icon(Icons.check_circle, color: Colors.green),
            ),
            IconButton(
              onPressed: () => _rejectMember(member),
              icon: const Icon(Icons.cancel, color: Colors.red),
            ),
          ] else if (isCoach && !isPending) ...[
            PopupMenuButton(
              icon: const Icon(Icons.more_vert, color: Colors.white70),
              color: const Color(0xFF1A4747),
              itemBuilder: (context) => [
                PopupMenuItem(
                  value: 'change_role',
                  child: const Text(
                    'Ubah Role',
                    style: TextStyle(
                      color: Colors.white,
                      fontFamily: 'Poppins',
                    ),
                  ),
                ),
                PopupMenuItem(
                  value: 'remove',
                  child: const Text(
                    'Keluarkan',
                    style: TextStyle(
                      color: Colors.red,
                      fontFamily: 'Poppins',
                    ),
                  ),
                ),
              ],
              onSelected: (value) {
                if (value == 'change_role') {
                  _showChangeRoleDialog(member);
                } else if (value == 'remove') {
                  _showRemoveMemberDialog(member);
                }
              },
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildRoleBadge(String role) {
    Color badgeColor =
        role == 'Pelatih' ? const Color(0xFF4CAF50) : const Color(0xFF2196F3);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: badgeColor.withOpacity(0.2),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: badgeColor, width: 1),
      ),
      child: Text(
        role,
        style: TextStyle(
          color: badgeColor,
          fontSize: 12,
          fontFamily: 'Poppins',
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  List<Map<String, dynamic>> _getFilteredMembers() {
    switch (selectedFilter) {
      case 'Pelatih':
        return members
            .where((m) => m['role'] == 'Pelatih' && m['status'] == 'approved')
            .toList();
      case 'Atlet':
        return members
            .where((m) => m['role'] == 'Atlet' && m['status'] == 'approved')
            .toList();
      case 'Pending':
        return members.where((m) => m['status'] == 'pending').toList();
      default:
        return members;
    }
  }

  void _approveMember(Map<String, dynamic> member) async {
    final teamProvider = Provider.of<TeamProvider>(context, listen: false);
    final success = await teamProvider.updateMemberStatus(
      teamId: widget.teamData['id'],
      userId: member['id'],
      isActive: true,
    );

    if (success) {
      setState(() {
        member['status'] = 'approved';
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('${member['name']} disetujui bergabung'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Gagal menyetujui anggota'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void _rejectMember(Map<String, dynamic> member) async {
    final teamProvider = Provider.of<TeamProvider>(context, listen: false);
    final success = await teamProvider.removeMember(
      teamId: widget.teamData['id'],
      userId: member['id'],
    );

    if (success) {
      setState(() {
        members.remove(member);
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Permintaan ${member['name']} ditolak'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Gagal menolak anggota'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void _showChangeRoleDialog(Map<String, dynamic> member) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1A4747),
        title: Text(
          'Ubah Role ${member['name']}',
          style: const TextStyle(
            color: Colors.white,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w600,
          ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              title: const Text(
                'Coach',
                style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'Poppins',
                ),
              ),
              leading: Radio<String>(
                value: 'Coach',
                groupValue: member['role'],
                onChanged: (value) async {
                  final teamProvider = Provider.of<TeamProvider>(context, listen: false);
                  final success = await teamProvider.changeMemberRole(
                    teamId: widget.teamData['id'],
                    userId: member['id'],
                    newRole: value!,
                  );
                  
                  if (success) {
                    setState(() {
                      member['role'] = value;
                    });
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Peran ${member['name']} berhasil diubah'),
                        backgroundColor: Colors.green,
                      ),
                    );
                  } else {
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Gagal mengubah peran anggota'),
                        backgroundColor: Colors.red,
                      ),
                    );
                  }
                },
                activeColor: const Color(0xFF4CAF50),
              ),
            ),
            ListTile(
              title: const Text(
                'Athlete',
                style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'Poppins',
                ),
              ),
              leading: Radio<String>(
                value: 'Athlete',
                groupValue: member['role'],
                onChanged: (value) async {
                  final teamProvider = Provider.of<TeamProvider>(context, listen: false);
                  final success = await teamProvider.changeMemberRole(
                    teamId: widget.teamData['id'],
                    userId: member['id'],
                    newRole: value!,
                  );
                  
                  if (success) {
                    setState(() {
                      member['role'] = value;
                    });
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Peran ${member['name']} berhasil diubah'),
                        backgroundColor: Colors.green,
                      ),
                    );
                  } else {
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Gagal mengubah peran anggota'),
                        backgroundColor: Colors.red,
                      ),
                    );
                  }
                },
                activeColor: const Color(0xFF2196F3),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showRemoveMemberDialog(Map<String, dynamic> member) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1A4747),
        title: const Text(
          'Keluarkan Anggota',
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w600,
          ),
        ),
        content: Text(
          'Apakah Anda yakin ingin mengeluarkan ${member['name']} dari tim?',
          style: const TextStyle(
            color: Colors.white70,
            fontFamily: 'Poppins',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              'Batal',
              style: TextStyle(
                color: Colors.white70,
                fontFamily: 'Poppins',
              ),
            ),
          ),
          TextButton(
            onPressed: () async {
              final teamProvider = Provider.of<TeamProvider>(context, listen: false);
              final success = await teamProvider.removeMember(
                teamId: widget.teamData['id'],
                userId: member['id'],
              );

              if (success) {
                setState(() {
                  members.remove(member);
                });
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('${member['name']} dikeluarkan dari tim'),
                    backgroundColor: Colors.red,
                  ),
                );
              }
            },
            child: const Text(
              'Keluarkan',
              style: TextStyle(
                color: Colors.red,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
