import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'components/welcome_section.dart';
import 'components/teams_section.dart';
import 'components/reminders_section.dart';
import 'components/bottom_navbar.dart';
import 'components/top_navbar.dart';
import '../providers/auth_provider.dart';
import '../providers/team_provider.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<TeamProvider>(context, listen: false).loadUserTeams();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF002122),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Consumer2<AuthProvider, TeamProvider>(
              builder: (context, authProvider, teamProvider, child) {
                final user = authProvider.user;
                final userProfile = authProvider.userProfile;
                
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const TopNavBar(),
                    const SizedBox(height: 20),
                    const WelcomeSection(),
                    const SizedBox(height: 30),
                    const TeamsSection(),
                    const SizedBox(height: 30),
                    // Gunakan data dinamis untuk RemindersSection
                    if (user != null && userProfile != null)
                      RemindersSection(
                        teamId: teamProvider.teams.isNotEmpty 
                            ? teamProvider.teams.first.id 
                            : '',
                        teamName: teamProvider.teams.isNotEmpty 
                            ? teamProvider.teams.first.name 
                            : 'No Team',
                        // Gunakan role dari tim, bukan dari userProfile
                        isCoach: teamProvider.teams.isNotEmpty 
                            ? teamProvider.isCoachInTeam(teamProvider.teams.first.id)
                            : false,
                        userId: user.uid,
                      )
                    else
                      const Center(
                        child: CircularProgressIndicator(
                          color: Color(0xFF00BF63),
                        ),
                      ),
                    const SizedBox(height: 80), // Ruang untuk bottom navbar
                  ],
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}