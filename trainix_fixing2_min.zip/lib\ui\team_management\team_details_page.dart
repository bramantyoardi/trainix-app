import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/team.dart';
import '../../providers/team_provider.dart';
import '../../providers/auth_provider.dart';
import '../../models/user_team_role.dart';
import 'team_members_page.dart';

class TeamDetailsPage extends StatefulWidget {
  final Team team;

  const TeamDetailsPage({super.key, required this.team});

  @override
  State<TeamDetailsPage> createState() => _TeamDetailsPageState();
}

class _TeamDetailsPageState extends State<TeamDetailsPage> {
  late Team team;
  List<UserTeamRole> teamMembers = [];
  bool isLoadingMembers = true;
  bool isCoach = false; // Add field to track user role
  String? currentUserId; // Add field to track current user ID
  
  @override
  void initState() {
    super.initState();
    team = widget.team;
    _initializeUserData(); // Remove await, just call the method
  }

  void _initializeUserData() async {
    // Get current user ID from AuthProvider
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    currentUserId = authProvider.user?.uid;
    
    // Load team members and determine user role
    await _loadTeamMembers();
    _determineUserRole();
  }

  Future<void> _loadTeamMembers() async {
    setState(() {
      isLoadingMembers = true;
    });
    
    final teamProvider = Provider.of<TeamProvider>(context, listen: false);
    final members = await teamProvider.getTeamMembers(team.id);
    
    setState(() {
      teamMembers = members;
      isLoadingMembers = false;
    });
  }

  void _determineUserRole() {
    if (currentUserId != null && teamMembers.isNotEmpty) {
      // Find current user in team members and check their role
      final currentUserRole = teamMembers.firstWhere(
        (member) => member.userId == currentUserId,
        orElse: () => UserTeamRole(
          id: '',
          userId: '',
          teamId: '',
          role: 'athlete', // Default role
          joinedAt: Timestamp.now(), // Updated to use Timestamp
        ),
      );
      
      setState(() {
        isCoach = currentUserRole.role.toLowerCase() == 'coach' || 
                 currentUserRole.role.toLowerCase() == 'pelatih';
      });
    }
  }

  Widget _buildTeamInfo() {
    // Get current user's role for display
    String userRole = 'Atlet'; // Default
    if (currentUserId != null && teamMembers.isNotEmpty) {
      final currentUserRole = teamMembers.firstWhere(
        (member) => member.userId == currentUserId,
        orElse: () => UserTeamRole(
          id: '',
          userId: '',
          teamId: '',
          role: 'athlete',
          joinedAt: Timestamp.now(), // Updated to use Timestamp
        ),
      );
      
      // Convert role to Indonesian
      if (currentUserRole.role.toLowerCase() == 'coach') {
        userRole = 'Pelatih';
      } else if (currentUserRole.role.toLowerCase() == 'pelatih') {
        userRole = 'Pelatih';
      } else {
        userRole = 'Atlet';
      }
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF1A4747),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Text(
                  team.name,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              _buildRoleBadge(userRole), // Use dynamic role instead of hardcoded 'Pelatih'
            ],
          ),
          const SizedBox(height: 16),
          _buildInfoRow(Icons.sports, 'Cabang Olahraga', team.cabor ?? 'N/A'),
          const SizedBox(height: 12),
          _buildInfoRow(Icons.location_on, 'Kontingen', team.kontingen ?? 'N/A'),
          const SizedBox(height: 12),
          _buildInfoRow(Icons.event, 'Event', team.event ?? 'N/A'),
          const SizedBox(height: 12),
          _buildInfoRow(
              Icons.people, 'Anggota', '${team.memberCount ?? 0} orang'),
        ],
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String label, String value) {
    return Row(
      children: [
        Icon(
          icon,
          color: Colors.white70,
          size: 20,
        ),
        const SizedBox(width: 12),
        Text(
          '$label: ',
          style: const TextStyle(
            color: Colors.white70,
            fontSize: 14,
            fontFamily: 'Poppins',
          ),
        ),
        Expanded(
          child: Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontFamily: 'Poppins',
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildRoleBadge(String role) {
    Color badgeColor =
        role == 'Pelatih' ? const Color(0xFF4CAF50) : const Color(0xFF2196F3);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: badgeColor.withOpacity(0.2),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: badgeColor, width: 1),
      ),
      child: Text(
        role,
        style: TextStyle(
          color: badgeColor,
          fontSize: 12,
          fontFamily: 'Poppins',
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Widget _buildTeamCode() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1A4747),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white24, width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Kode Tim',
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontFamily: 'Poppins',
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                team.teamCode ?? 'TEAM123',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w700,
                  letterSpacing: 3,
                ),
              ),
              IconButton(
                onPressed: () {
                  // Copy to clipboard
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Kode tim disalin!'),
                      duration: Duration(seconds: 2),
                    ),
                  );
                },
                icon: const Icon(
                  Icons.copy,
                  color: Colors.white70,
                ),
              ),
            ],
          ),
          const Text(
            'Bagikan kode ini untuk mengundang anggota baru',
            style: TextStyle(
              color: Colors.white54,
              fontSize: 12,
              fontFamily: 'Poppins',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMembersSection(bool isCoach) {
    if (isLoadingMembers) {
      return const Center(
        child: CircularProgressIndicator(
          color: Color(0xFF00BF63),
        ),
      );
    }

    // Use isActive property instead of status
    final approvedMembers = teamMembers.where((m) => m.isActive).toList();
    final pendingMembers = teamMembers.where((m) => !m.isActive).toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              'Anggota Tim',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w600,
              ),
            ),
            TextButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => TeamMembersPage(
                      teamData: _teamToMap(team),
                      members: _convertToMapList(teamMembers), // Gunakan data sebenarnya dari database
                    ),
                  ),
                );
              },
              child: const Text(
                'Lihat Semua',
                style: TextStyle(
                  color: Colors.white70,
                  fontSize: 14,
                  fontFamily: 'Poppins',
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        // Show first 3 approved members
        ...approvedMembers.take(3).map((member) => _buildMemberCardFromUserTeamRole(member)),

        if (isCoach && pendingMembers.isNotEmpty) ...[
          const SizedBox(height: 16),
          Text(
            'Permintaan Bergabung (${pendingMembers.length})',
            style: const TextStyle(
              color: Colors.orange,
              fontSize: 16,
              fontFamily: 'Poppins',
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          ...pendingMembers.map((member) => _buildPendingMemberCardFromUserTeamRole(member)),
        ],
      ],
    );
  }

  // Helper method to convert UserTeamRole list to Map list for compatibility
  List<Map<String, dynamic>> _convertToMapList(List<UserTeamRole> members) {
    return members.map((member) => {
      'id': member.userId,
      'name': member.userName ?? 'Unknown User', // Use actual userName from database
      'role': member.role,
      'photo': member.userPhotoUrl ?? 'images/profile/profile1.png', // Use actual photo URL
      'status': member.isActive ? 'approved' : 'pending',
    }).toList();
  }

  Widget _buildMemberCardFromUserTeamRole(UserTeamRole member) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF1A4747),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 20,
            backgroundImage: member.userPhotoUrl != null && member.userPhotoUrl!.isNotEmpty
                ? NetworkImage(member.userPhotoUrl!)
                : const AssetImage('images/profile/profile1.png') as ImageProvider,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  member.userName ?? 'Unknown User',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w500,
                  ),
                ),
                Text(
                  member.role,
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 12,
                    fontFamily: 'Poppins',
                  ),
                ),
              ],
            ),
          ),
          _buildRoleBadge(member.role),
        ],
      ),
    );
  }

  Widget _buildPendingMemberCardFromUserTeamRole(UserTeamRole member) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF1A4747),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.orange.withOpacity(0.3), width: 1),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 20,
            backgroundImage: member.userPhotoUrl != null && member.userPhotoUrl!.isNotEmpty
                ? NetworkImage(member.userPhotoUrl!)
                : const AssetImage('images/profile/profile1.png') as ImageProvider,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  member.userName ?? 'Unknown User',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w500,
                  ),
                ),
                Text(
                  member.role,
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 12,
                    fontFamily: 'Poppins',
                  ),
                ),
              ],
            ),
          ),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              IconButton(
                onPressed: () => _approveMemberFromUserTeamRole(member),
                icon: const Icon(Icons.check_circle, color: Colors.green, size: 20),
              ),
              IconButton(
                onPressed: () => _rejectMemberFromUserTeamRole(member),
                icon: const Icon(Icons.cancel, color: Colors.red, size: 20),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _approveMemberFromUserTeamRole(UserTeamRole member) async {
    final teamProvider = Provider.of<TeamProvider>(context, listen: false);
    final success = await teamProvider.updateMemberStatus(
      teamId: team.id,
      userId: member.userId,
      isActive: true,
    );

    if (success) {
      _loadTeamMembers(); // Refresh member list
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('${member.userName ?? 'User'} disetujui bergabung'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Gagal menyetujui anggota'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void _rejectMemberFromUserTeamRole(UserTeamRole member) async {
    final teamProvider = Provider.of<TeamProvider>(context, listen: false);
    final success = await teamProvider.removeMember(
      teamId: team.id,
      userId: member.userId,
    );

    if (success) {
      _loadTeamMembers(); // Refresh member list
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Permintaan ${member.userName ?? 'User'} ditolak'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Gagal menolak anggota'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Widget _buildCoachActions() {
    return Column(
      children: [
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => TeamMembersPage(
                    teamData: _teamToMap(team),
                    members: _convertToMapList(teamMembers), // Gunakan data sebenarnya dari database
                  ),
                ),
              );
            },
            icon: const Icon(Icons.people, color: Colors.white),
            label: const Text(
              'Kelola Anggota',
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w500,
              ),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF1A4747),
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
        ),
        const SizedBox(height: 12),
        SizedBox(
          width: double.infinity,
          child: OutlinedButton.icon(
            onPressed: () {
              // Navigate to edit team
            },
            icon: const Icon(Icons.edit, color: Colors.white70),
            label: const Text(
              'Edit Tim',
              style: TextStyle(
                color: Colors.white70,
                fontSize: 16,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w500,
              ),
            ),
            style: OutlinedButton.styleFrom(
              side: const BorderSide(color: Colors.white24),
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildAthleteActions() {
    return SizedBox(
      width: double.infinity,
      child: OutlinedButton.icon(
        onPressed: () {
          _showLeaveTeamDialog();
        },
        icon: const Icon(Icons.exit_to_app, color: Colors.red),
        label: const Text(
          'Keluar dari Tim',
          style: TextStyle(
            color: Colors.red,
            fontSize: 16,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w500,
          ),
        ),
        style: OutlinedButton.styleFrom(
          side: const BorderSide(color: Colors.red),
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
    );
  }

  void _approveMember(Map<String, dynamic> member) async {
    final teamProvider = Provider.of<TeamProvider>(context, listen: false);
    final success = await teamProvider.updateMemberStatus(
      teamId: team.id,
      userId: member['id'],
      isActive: true,
    );

    if (success) {
      _loadTeamMembers(); // Refresh member list from database
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('${member['name']} disetujui bergabung'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Gagal menyetujui anggota'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void _rejectMember(Map<String, dynamic> member) async {
    final teamProvider = Provider.of<TeamProvider>(context, listen: false);
    final success = await teamProvider.removeMember(
      teamId: team.id,
      userId: member['id'],
    );

    if (success) {
      _loadTeamMembers(); // Refresh member list from database
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Permintaan ${member['name']} ditolak'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Gagal menolak anggota'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void _showLeaveTeamDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1A4747),
        title: const Text(
          'Keluar dari Tim',
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w600,
          ),
        ),
        content: const Text(
          'Apakah Anda yakin ingin keluar dari tim ini?',
          style: TextStyle(
            color: Colors.white70,
            fontFamily: 'Poppins',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              'Batal',
              style: TextStyle(
                color: Colors.white70,
                fontFamily: 'Poppins',
              ),
            ),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Anda telah keluar dari tim'),
                  backgroundColor: Colors.orange,
                ),
              );
            },
            child: const Text(
              'Keluar',
              style: TextStyle(
                color: Colors.red,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

@override
Widget build(BuildContext context) {
  return Scaffold(
    appBar: AppBar(
      title: Text(team.name),
      backgroundColor: const Color(0xFF1E1E1E),
      foregroundColor: Colors.white,
    ),
    backgroundColor: const Color(0xFF1E1E1E),
    body: isLoadingMembers
        ? const Center(
            child: CircularProgressIndicator(
              color: Color(0xFF65EAE8),
            ),
          )
        : SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildTeamInfo(),
                const SizedBox(height: 20),
                _buildMembersSection(),
                if (isCoach) ...[
                  const SizedBox(height: 20),
                  _buildCoachActions(),
                ],
              ],
            ),
          ),
  );
}

Widget _buildMembersSection() {
  return Card(
    color: const Color(0xFF2A2A2A),
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Anggota Tim',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                '${teamMembers.length} orang',
                style: const TextStyle(
                  color: Color(0xFF65EAE8),
                  fontSize: 14,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ...teamMembers.map((member) => ListTile(
            leading: CircleAvatar(
              backgroundColor: member.role.toLowerCase() == 'coach' 
                  ? Colors.orange 
                  : const Color(0xFF65EAE8),
              child: Text(
                member.userId.substring(0, 1).toUpperCase(),
                style: const TextStyle(color: Colors.white),
              ),
            ),
            title: Text(
              member.userId, // You might want to show actual name
              style: const TextStyle(color: Colors.white),
            ),
            subtitle: Text(
              member.role == 'coach' ? 'Pelatih' : 'Atlet',
              style: const TextStyle(color: Colors.grey),
            ),
          )).toList(),
        ],
      ),
    ),
  );
}

Widget _buildCoachActions() {
  return Card(
    color: const Color(0xFF2A2A2A),
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Aksi Pelatih',
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),
          ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => TeamMembersPage(
                    teamId: team.id,
                    teamName: team.name,
                  ),
                ),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF65EAE8),
              foregroundColor: Colors.black,
            ),
            child: const Text('Kelola Anggota'),
          ),
        ],
      ),
    ),
  );
}
