import 'package:flutter/material.dart';

class HRRCalculator {
  // Konstanta untuk perhitungan HRR
  static const int _defaultRestingHeartRate = 60; // Default RHR
  static const int _maxHeartRateBase = 220; // Formula: 220 - age (Tanaka)

  // HRR Band definitions sesuai spec v1.3
  static const Map<String, Map<String, dynamic>> _hrrBands = {
    'Zone 1': {
      'min': 50,
      'max': 60,
      'description': 'Recovery/Active Recovery',
      'color': 0xFF4CAF50, // Green
    },
    'Zone 2': {
      'min': 60,
      'max': 70,
      'description': 'Aerobic Base',
      'color': 0xFF2196F3, // Blue
    },
    'Zone 3': {
      'min': 70,
      'max': 80,
      'description': 'Aerobic Threshold',
      'color': 0xFFFF9800, // Orange
    },
    'Zone 4': {
      'min': 80,
      'max': 90,
      'description': 'Lactate Threshold',
      'color': 0xFFFF5722, // Deep Orange
    },
    'Zone 5': {
      'min': 90,
      'max': 100,
      'description': 'VO2 Max',
      'color': 0xFFF44336, // Red
    },
  };

  // Calculate maximum heart rate using Tanaka formula
  static int calculateMaxHeartRate(int age) {
    return _maxHeartRateBase - age;
  }

  // Calculate HRR percentage using Karvonen method
  static double calculateHRRPercentage({
    required int currentHeartRate,
    required int age,
    int? restingHeartRate,
  }) {
    final rhr = restingHeartRate ?? _defaultRestingHeartRate;
    final maxHR = calculateMaxHeartRate(age);
    
    if (currentHeartRate <= rhr) return 0.0;
    if (currentHeartRate >= maxHR) return 100.0;
    
    final hrr = ((currentHeartRate - rhr) / (maxHR - rhr)) * 100;
    return hrr.clamp(0.0, 100.0);
  }

  // Get HRR band from percentage
  static String getHRRBand(double hrrPercentage) {
    for (final entry in _hrrBands.entries) {
      final min = entry.value['min'] as int;
      final max = entry.value['max'] as int;
      
      if (hrrPercentage >= min && hrrPercentage < max) {
        return entry.key;
      }
    }
    
    // If above all zones, return Zone 5
    if (hrrPercentage >= 90) return 'Zone 5';
    
    // If below all zones, return Zone 1
    return 'Zone 1';
  }

  // Get HRR band from heart rate
  static String getHRRBandFromHeartRate({
    required int currentHeartRate,
    required int age,
    int? restingHeartRate,
  }) {
    final hrrPercentage = calculateHRRPercentage(
      currentHeartRate: currentHeartRate,
      age: age,
      restingHeartRate: restingHeartRate,
    );
    
    return getHRRBand(hrrPercentage);
  }

  // Calculate target heart rate range for a zone using Karvonen method
  static Map<String, int> getTargetHeartRateRange({
    required String zone,
    required int age,
    int? restingHeartRate,
  }) {
    final rhr = restingHeartRate ?? _defaultRestingHeartRate;
    final maxHR = calculateMaxHeartRate(age);
    final bandInfo = _hrrBands[zone];
    
    if (bandInfo == null) {
      return {'min': rhr, 'max': maxHR};
    }
    
    final minPercentage = bandInfo['min'] as int;
    final maxPercentage = bandInfo['max'] as int;
    
    final minHR = ((minPercentage / 100) * (maxHR - rhr) + rhr).round();
    final maxHR_zone = ((maxPercentage / 100) * (maxHR - rhr) + rhr).round();
    
    return {
      'min': minHR,
      'max': maxHR_zone,
    };
  }

  // Calculate compliance percentage
  static double calculateCompliance({
    required int minutesInBand,
    required int totalMinutes,
  }) {
    if (totalMinutes == 0) return 0.0;
    return (minutesInBand / totalMinutes).clamp(0.0, 1.0);
  }

  // Calculate minutes in target HRR band
  static int calculateMinutesInBand({
    required int avgHeartRate,
    required int totalMinutes,
    required String targetZone,
    required int age,
    int? restingHeartRate,
  }) {
    final targetRange = getTargetHeartRateRange(
      zone: targetZone,
      age: age,
      restingHeartRate: restingHeartRate,
    );
    
    // Simplified calculation - assumes average HR represents the entire session
    if (avgHeartRate >= targetRange['min']! && avgHeartRate <= targetRange['max']!) {
      return totalMinutes;
    }
    
    // If not in target zone, calculate proportional time based on proximity
    final midTarget = (targetRange['min']! + targetRange['max']!) / 2;
    final deviation = (avgHeartRate - midTarget).abs();
    final maxDeviation = targetRange['max']! - targetRange['min']!;
    
    if (deviation > maxDeviation) return 0;
    
    final proximity = 1.0 - (deviation / maxDeviation);
    return (totalMinutes * proximity).round();
  }

  // Enhanced HRR-based score calculation
  static double calculateHRRScore({
    required int hrRest,
    required int age,
    required int hrAvg,
    required int hrPeak,
    required int minutesInBand,
    required int totalMinutes,
    required String targetZone,
  }) {
    // Calculate HRR percentage for average HR
    final avgHRRPercentage = calculateHRRPercentage(
      currentHeartRate: hrAvg,
      age: age,
      restingHeartRate: hrRest,
    );
    
    // Calculate compliance
    final compliance = calculateCompliance(
      minutesInBand: minutesInBand,
      totalMinutes: totalMinutes,
    );
    
    // Base score from HRR percentage
    double baseScore = avgHRRPercentage;
    
    // Compliance multiplier (higher compliance = higher score)
    double complianceMultiplier = 0.5 + (compliance * 0.5); // 0.5 to 1.0
    
    // Duration factor (optimal around 30-60 minutes)
    double durationFactor = 1.0;
    if (totalMinutes >= 30 && totalMinutes <= 60) {
      durationFactor = 1.0;
    } else if (totalMinutes < 30) {
      durationFactor = totalMinutes / 30.0; // Penalty for short sessions
    } else {
      durationFactor = 1.0 + ((totalMinutes - 60) * 0.005); // Diminishing returns
    }
    
    // Zone intensity factor
    double zoneFactor = 1.0;
    switch (targetZone) {
      case 'Zone 1':
        zoneFactor = 0.8;
        break;
      case 'Zone 2':
        zoneFactor = 1.0;
        break;
      case 'Zone 3':
        zoneFactor = 1.2;
        break;
      case 'Zone 4':
        zoneFactor = 1.4;
        break;
      case 'Zone 5':
        zoneFactor = 1.6;
        break;
    }
    
    final finalScore = baseScore * complianceMultiplier * durationFactor * zoneFactor;
    return finalScore.clamp(0.0, 200.0);
  }

  // Preview calculation for UI (before submission)
  static Map<String, dynamic> calculatePreview({
    required int hrRest,
    required int age,
    required int hrAvg,
    required int totalMinutes,
    String? targetZone,
  }) {
    final zone = targetZone ?? getHRRBandFromHeartRate(
      currentHeartRate: hrAvg,
      age: age,
      restingHeartRate: hrRest,
    );
    
    final hrrPercentage = calculateHRRPercentage(
      currentHeartRate: hrAvg,
      age: age,
      restingHeartRate: hrRest,
    );
    
    final targetRange = getTargetHeartRateRange(
      zone: zone,
      age: age,
      restingHeartRate: hrRest,
    );
    
    final minutesInBand = calculateMinutesInBand(
      avgHeartRate: hrAvg,
      totalMinutes: totalMinutes,
      targetZone: zone,
      age: age,
      restingHeartRate: hrRest,
    );
    
    final compliance = calculateCompliance(
      minutesInBand: minutesInBand,
      totalMinutes: totalMinutes,
    );
    
    return {
      'hrrPercentage': hrrPercentage,
      'zone': zone,
      'targetRange': targetRange,
      'minutesInBand': minutesInBand,
      'compliance': compliance,
      'bandLow': targetRange['min'],
      'bandHigh': targetRange['max'],
    };
  }

  // Calculate training score based on HRR (legacy method for backward compatibility)
  static double calculateTrainingScore({
    required double hrrPercentage,
    required int durationMinutes,
  }) {
    // Base score dari HRR percentage
    double baseScore = hrrPercentage;
    
    // Duration multiplier (semakin lama semakin tinggi, tapi ada diminishing returns)
    double durationMultiplier = 1.0;
    if (durationMinutes > 60) {
      durationMultiplier = 1.0 + ((durationMinutes - 60) * 0.01); // +1% per menit di atas 60
    } else if (durationMinutes < 30) {
      durationMultiplier = 0.5 + (durationMinutes * 0.0167); // Penalty untuk durasi pendek
    }
    
    // Zone bonus (zone yang lebih tinggi mendapat bonus)
    double zoneBonus = 1.0;
    final band = getHRRBand(hrrPercentage);
    switch (band) {
      case 'Zone 1':
        zoneBonus = 0.8;
        break;
      case 'Zone 2':
        zoneBonus = 1.0;
        break;
      case 'Zone 3':
        zoneBonus = 1.2;
        break;
      case 'Zone 4':
        zoneBonus = 1.4;
        break;
      case 'Zone 5':
        zoneBonus = 1.6;
        break;
    }
    
    final finalScore = baseScore * durationMultiplier * zoneBonus;
    return finalScore.clamp(0.0, 200.0); // Max score 200
  }

  // Get all HRR bands info
  static Map<String, Map<String, dynamic>> getAllHRRBands() {
    return Map.from(_hrrBands);
  }

  // Get HRR band info
  static Map<String, dynamic>? getHRRBandInfo(String bandName) {
    return _hrrBands[bandName];
  }

  // Validate heart rate data
  static bool isValidHeartRate(int heartRate, int age) {
    if (heartRate < 40 || heartRate > 220) return false;
    
    final maxHR = calculateMaxHeartRate(age);
    return heartRate <= maxHR + 10; // Allow 10 bpm tolerance
  }

  // Get recommended training zones for different goals
  static List<String> getRecommendedZones(String trainingGoal) {
    switch (trainingGoal.toLowerCase()) {
      case 'recovery':
        return ['Zone 1'];
      case 'base_building':
      case 'aerobic':
        return ['Zone 1', 'Zone 2'];
      case 'tempo':
      case 'threshold':
        return ['Zone 3', 'Zone 4'];
      case 'interval':
      case 'vo2max':
        return ['Zone 4', 'Zone 5'];
      case 'mixed':
      default:
        return ['Zone 2', 'Zone 3', 'Zone 4'];
    }
  }

  // Method untuk mendapatkan warna HRR band berdasarkan string
  static Color getHRRBandColor(String hrrBand) {
    // Extract band number from string like "Zone 1", "HRR 1", "Band 1", etc.
    final RegExp numberRegex = RegExp(r'\d+');
    final match = numberRegex.firstMatch(hrrBand);
    final bandNumber = match != null ? int.parse(match.group(0)!) : 1;
    
    return getHRRBandColorByNumber(bandNumber);
  }

  // Method untuk mendapatkan warna HRR band berdasarkan nomor
  static Color getHRRBandColorByNumber(int bandNumber) {
    switch (bandNumber) {
      case 1:
        return const Color(0xFF4CAF50); // Green
      case 2:
        return const Color(0xFF8BC34A); // Light Green
      case 3:
        return const Color(0xFFFFEB3B); // Yellow
      case 4:
        return const Color(0xFFFF9800); // Orange
      case 5:
        return const Color(0xFFF44336); // Red
      default:
        return const Color(0xFF9E9E9E); // Grey
    }
  }

  // Method untuk mendapatkan deskripsi HRR band
  static String getHRRBandDescription(int hrrBand) {
    switch (hrrBand) {
      case 1:
        return 'Very Light (50-60%)';
      case 2:
        return 'Light (60-70%)';
      case 3:
        return 'Moderate (70-80%)';
      case 4:
        return 'Hard (80-90%)';
      case 5:
        return 'Very Hard (90-100%)';
      default:
        return 'Unknown';
    }
  }

  // Calculate HRR Zone with named parameters
  static Map<String, num> calculateHRRZone({
    required int age,
    required int hrRest,
    required double targetLowPercent,
    required double targetHighPercent,
    int? hrAvg,
    int? hrPeak,
    int? minutesInBand,
    String? targetZone,
    double? compliance,
  }) {
    final hrMax = (208 - 0.7 * age).round();             // Tanaka
    final hrr = hrMax - hrRest;                          // Karvonen
    final low = (hrRest + hrr * targetLowPercent).round();
    final high = (hrRest + hrr * targetHighPercent).round();
    return {'low': low, 'high': high};
  }
}