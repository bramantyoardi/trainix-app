import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/program.dart';
import 'firestore_service.dart';

class ProgramService {
  final FirestoreService _firestoreService;
  final _db = FirebaseFirestore.instance;

  ProgramService(this._firestoreService);

  Stream<List<Program>> getTeamPrograms(String teamId) {
    return _db
        .collection('programs')
        .where('teamId', isEqualTo: teamId)
        .orderBy('weekAnchor')
        .snapshots()
        .map((snap) => snap.docs.map((d) => Program.fromFirestore(d)).toList());
  }

  Stream<List<Program>> getProgramsByWeek(String teamId, Timestamp weekStart) {
    return _db
        .collection('programs')
        .where('teamId', isEqualTo: teamId)
        .where('weekAnchor', isEqualTo: weekStart)
        .snapshots()
        .map((snap) => snap.docs.map((d) => Program.fromFirestore(d)).toList());
  }

  Future<bool> createProgram(Program program) async {
    try {
      print('Creating program: ${program.name}');
      await _firestoreService.addDocument('programs', program.toJson());
      return true;
    } catch (e) {
      print('Error creating program: $e');
      return false;
    }
  }

  Future<bool> updateProgram(Program program) async {
    try {
      print('Updating program: ${program.id}');
      await _firestoreService.updateDocument('programs', program.id, program.toJson());
      return true;
    } catch (e) {
      print('Error updating program: $e');
      return false;
    }
  }

  Future<bool> deleteProgram(String programId) async {
    try {
      print('Deleting program: $programId');
      await _firestoreService.deleteDocument('programs', programId);
      return true;
    } catch (e) {
      print('Error deleting program: $e');
      return false;
    }
  }

  Future<Program?> getProgram(String programId) async {
    try {
      print('Getting program: $programId');
      final doc = await _firestoreService.getDocument('programs', programId);
      if (doc != null) {
        return Program.fromJson({'id': programId, ...doc});
      }
      return null;
    } catch (e) {
      print('Error getting program: $e');
      return null;
    }
  }

  bool isSameWeek(DateTime date1, DateTime date2) {
    final startOfWeek1 = date1.subtract(Duration(days: date1.weekday - 1));
    final startOfWeek2 = date2.subtract(Duration(days: date2.weekday - 1));
    return startOfWeek1.year == startOfWeek2.year &&
           startOfWeek1.month == startOfWeek2.month &&
           startOfWeek1.day == startOfWeek2.day;
  }
}