import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_app_check/firebase_app_check.dart';
import 'package:flutter/foundation.dart';
import 'dart:io' show Platform;
import 'package:provider/provider.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'firebase_options.dart';

import 'providers/auth_provider.dart' as app_auth;
import 'providers/team_provider.dart';
import 'providers/program_provider.dart';
import 'providers/intensity_provider.dart';
import 'providers/reminder_provider.dart';
import 'providers/leaderboard_provider.dart';
import 'providers/training_log_provider.dart';
import 'providers/notification_provider.dart';
import 'providers/security_provider.dart';
import 'services/notification_service.dart';
import 'ui/authentication/auth_page.dart';
import 'ui/authentication/login_page.dart';
import 'ui/authentication/register_page.dart';
import 'ui/authentication/email_verification_page.dart';
import 'ui/authentication/forgot_password_page.dart';
import 'ui/authentication/splash_screen.dart';
import 'ui/main_screen.dart';
import 'ui/homepage.dart';
import 'ui/teams_page.dart';
import 'ui/team_management/create_team_page.dart';
import 'ui/team_management/join_team_page.dart';
import 'ui/training/training_dashboard_page.dart';
import 'ui/training/program_list_page.dart';
import 'ui/training/leaderboard_page.dart';
import 'ui/training/reminder_list_page.dart';
import 'ui/training/create_reminder_page.dart';
import 'ui/user_management/profile_page.dart';
import 'ui/user_management/edit_profile_page.dart';
import 'ui/user_management/change_password_page.dart';
import 'ui/settings_page.dart';
import 'models/reminder.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Inisialisasi Firebase secara normal untuk Android menggunakan konfigurasi FlutterFire
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  // Tentukan provider App Check berdasarkan dart-define APP_CHECK_DEBUG
  const bool appCheckDebug = bool.fromEnvironment('APP_CHECK_DEBUG', defaultValue: false);

  // Aktifkan Firebase App Check sesuai mode
  await FirebaseAppCheck.instance.activate(
    androidProvider: appCheckDebug ? AndroidProvider.debug : AndroidProvider.playIntegrity,
    appleProvider: appCheckDebug ? AppleProvider.debug : AppleProvider.appAttest,
  );


  // Inisialisasi data locale Indonesia
  await initializeDateFormatting('id_ID', null);

  // Inisialisasi NotificationService di background (tidak blocking)
  NotificationService.initialize().catchError((error) {
    print('Inisialisasi NotificationService gagal: $error');
  });

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => app_auth.AuthProvider()),
        ChangeNotifierProvider(create: (_) => TeamProvider()),
        ChangeNotifierProvider(create: (_) => ProgramProvider()),
        ChangeNotifierProvider(create: (_) => IntensityProvider()),
        ChangeNotifierProvider(create: (_) => ReminderProvider()),
        ChangeNotifierProvider(create: (_) => LeaderboardProvider()),
        ChangeNotifierProvider(create: (_) => TrainingLogProvider()),
        ChangeNotifierProvider(create: (_) => NotificationProvider()),
        ChangeNotifierProvider(create: (_) => SecurityProvider()),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Trainix App',
        theme: ThemeData(
          fontFamily: 'Poppins',
        ),
        // Add locale support
        locale: const Locale('id', 'ID'),
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        supportedLocales: const [
          Locale('id', 'ID'), // Indonesian
          Locale('en', 'US'), // English (fallback)
        ],
        home: const AuthWrapper(),
        routes: {
          '/login': (context) => const LoginPage(),
          '/register': (context) => const RegisterPage(),
          '/forgot-password': (context) => const ForgotPasswordPage(),
          '/email-verification': (context) {
            final rawArgs = ModalRoute.of(context)?.settings.arguments;
            String email = '';
            String name = '';
            if (rawArgs is Map<String, dynamic>) {
              email = rawArgs['email'] ?? '';
              name = rawArgs['name'] ?? '';
            }
            return EmailVerificationPage(email: email, name: name);
          },
          // Sinkronisasi rute spesifikasi v1.1.4 (Android-only)
          '/home': (context) => const MainScreen(), // menggunakan MainScreen sebagai home container
          '/teams': (context) => const TeamsPage(),
          '/team/create': (context) => const CreateTeamPage(),
          '/team/join': (context) => const JoinTeamPage(),
          '/training/dashboard': (context) => const TrainingDashboardPage(),
          '/training/program': (context) {
            final rawArgs = ModalRoute.of(context)?.settings.arguments;
            String teamId = '';
            String teamName = '';
            bool isCoach = false;

            final teamProvider = Provider.of<TeamProvider>(context, listen: false);
            final authProvider = Provider.of<app_auth.AuthProvider>(context, listen: false);

            if (rawArgs is Map<String, dynamic>) {
              teamId = rawArgs['teamId'] ?? '';
              teamName = rawArgs['teamName'] ?? '';
              isCoach = rawArgs['isCoach'] ?? false;
            }

            // Fallback ke currentTeam jika argumen tidak disediakan
            if (teamId.isEmpty || teamName.isEmpty) {
              final currentTeam = teamProvider.currentTeam;
              if (currentTeam != null) {
                teamId = currentTeam.id;
                teamName = currentTeam.name;
                // gunakan TeamProvider untuk mengecek apakah user adalah coach di tim ini
                isCoach = teamProvider.isUserCoach(currentTeam.id);
              }
            }

            return ProgramListPage(
              teamId: teamId,
              teamName: teamName,
              isCoach: isCoach,
            );
          },
          '/training/leaderboard': (context) {
            final rawArgs = ModalRoute.of(context)?.settings.arguments;
            String teamId = '';
            String teamName = '';

            if (rawArgs is Map<String, dynamic>) {
              teamId = rawArgs['teamId'] ?? '';
              teamName = rawArgs['teamName'] ?? '';
            }

            // Fallback ke currentTeam
            final teamProvider = Provider.of<TeamProvider>(context, listen: false);
            if (teamId.isEmpty || teamName.isEmpty) {
              final currentTeam = teamProvider.currentTeam;
              if (currentTeam != null) {
                teamId = currentTeam.id;
                teamName = currentTeam.name;
              }
            }

            return LeaderboardPage(teamId: teamId, teamName: teamName);
          },
          '/training/reminders': (context) {
            final rawArgs = ModalRoute.of(context)?.settings.arguments;
            String teamId = '';
            String teamName = '';

            if (rawArgs is Map<String, dynamic>) {
              teamId = rawArgs['teamId'] ?? '';
              teamName = rawArgs['teamName'] ?? '';
            }

            // Fallback ke currentTeam
            final teamProvider = Provider.of<TeamProvider>(context, listen: false);
            if (teamId.isEmpty || teamName.isEmpty) {
              final currentTeam = teamProvider.currentTeam;
              if (currentTeam != null) {
                teamId = currentTeam.id;
                teamName = currentTeam.name;
              }
            }

            return ReminderListPage(teamId: teamId, teamName: teamName);
          },
          '/training/reminders/create': (context) {
            final rawArgs = ModalRoute.of(context)?.settings.arguments;
            String teamId = '';
            String teamName = '';
            bool isCoach = false;
            String userId = '';
            Reminder? reminderToEdit;

            if (rawArgs is Map<String, dynamic>) {
              teamId = rawArgs['teamId'] ?? '';
              teamName = rawArgs['teamName'] ?? '';
              isCoach = rawArgs['isCoach'] ?? false;
              userId = rawArgs['userId'] ?? '';
              reminderToEdit = rawArgs['reminderToEdit'] as Reminder?;
            }

            // Fallback ke currentTeam dan auth user
            final teamProvider = Provider.of<TeamProvider>(context, listen: false);
            final authProvider = Provider.of<app_auth.AuthProvider>(context, listen: false);
            if (teamId.isEmpty || teamName.isEmpty) {
              final currentTeam = teamProvider.currentTeam;
              if (currentTeam != null) {
                teamId = currentTeam.id;
                teamName = currentTeam.name;
                isCoach = teamProvider.isUserCoach(currentTeam.id);
              }
            }
            if (userId.isEmpty) {
              userId = authProvider.user?.uid ?? '';
            }

            return CreateReminderPage(
              teamId: teamId,
              teamName: teamName,
              isCoach: isCoach,
              userId: userId,
              reminderToEdit: reminderToEdit,
            );
          },
          '/profile': (context) => const ProfilePage(),
          '/profile/edit': (context) => const EditProfilePage(),
          '/profile/change-password': (context) => const ChangePasswordPage(),
          '/settings': (context) => const SettingsPage(),
        },
      ),
    );
  }
}

class AuthWrapper extends StatelessWidget {
  const AuthWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<app_auth.AuthProvider>(
      builder: (context, app_auth.AuthProvider authProvider, child) {
        if (authProvider.isLoading) {
          return const SplashScreen();
        }

        if (authProvider.isLoggedIn) {
          // Update FCM token when user logs in
          WidgetsBinding.instance.addPostFrameCallback((_) {
            final notificationProvider = Provider.of<NotificationProvider>(context, listen: false);
            notificationProvider.updateFCMToken(authProvider.user?.uid ?? '');
          });
          
          return const MainScreen();
        }

        return const AuthPage();
      },
    );
  }
}
