import 'package:cloud_firestore/cloud_firestore.dart';
import 'team.dart';

class UserTeamRole {
  final String id;
  final String userId;
  final String teamId;
  final String role; // 'Athlete' or 'Coach'
  final Timestamp joinedAt;
  final bool isActive;
  final String? invitedBy;
  final Timestamp? invitedAt;
  final String? approvedBy;
  final Timestamp? dateJoined;
  final String status; // 'pending', 'approved', 'rejected'
  final bool isOwner;
  final String? userName;
  final String? userEmail;
  final String? userPhotoUrl;
  // ADD MISSING TEAM PROPERTY
  final Team? team;

  UserTeamRole({
    required this.id,
    required this.userId,
    required this.teamId,
    required this.role,
    required this.joinedAt,
    this.isActive = true,
    this.invitedBy,
    this.invitedAt,
    this.approvedBy,
    this.dateJoined,
    this.status = 'pending',
    this.isOwner = false,
    this.userName,
    this.userEmail,
    this.userPhotoUrl,
    this.team, // ADD TEAM PROPERTY
  });

  factory UserTeamRole.fromJson(Map<String, dynamic> json) {
    return UserTeamRole(
      id: json['id'] ?? '',
      userId: json['user_id'] ?? json['userId'] ?? '',
      teamId: json['team_id'] ?? json['teamId'] ?? '',
      role: json['role'] ?? 'Member',
      joinedAt: json['joined_at'] is Timestamp 
          ? json['joined_at'] as Timestamp
          : (json['joinedAt'] is Timestamp
              ? json['joinedAt'] as Timestamp
              : (json['joined_at'] != null 
                  ? Timestamp.fromDate(DateTime.parse(json['joined_at']))
                  : (json['joinedAt'] != null
                      ? Timestamp.fromDate(DateTime.parse(json['joinedAt']))
                      : Timestamp.now()))),
      isActive: json['is_active'] ?? json['isActive'] ?? true,
      invitedBy: json['invited_by'] ?? json['invitedBy'],
      invitedAt: json['invited_at'] is Timestamp 
          ? json['invited_at'] as Timestamp
          : (json['invitedAt'] is Timestamp
              ? json['invitedAt'] as Timestamp
              : (json['invited_at'] != null 
                  ? Timestamp.fromDate(DateTime.parse(json['invited_at']))
                  : (json['invitedAt'] != null
                      ? Timestamp.fromDate(DateTime.parse(json['invitedAt']))
                      : null))),
      approvedBy: json['approved_by'] ?? json['approvedBy'],
      dateJoined: json['date_joined'] is Timestamp 
          ? json['date_joined'] as Timestamp
          : (json['dateJoined'] is Timestamp
              ? json['dateJoined'] as Timestamp
              : (json['date_joined'] != null 
                  ? Timestamp.fromDate(DateTime.parse(json['date_joined']))
                  : (json['dateJoined'] != null
                      ? Timestamp.fromDate(DateTime.parse(json['dateJoined']))
                      : null))),
      status: json['status'] ?? 'pending',
      isOwner: json['is_owner'] ?? json['isOwner'] ?? false,
      userName: json['user_name'] ?? json['userName'],
      userEmail: json['user_email'] ?? json['userEmail'],
      userPhotoUrl: json['user_photo_url'] ?? json['userPhotoUrl'],
      // PARSE TEAM FROM JSON
      team: json['team'] != null 
          ? (json['team'] is Map<String, dynamic> 
              ? Team.fromJson(json['team']) 
              : json['team'] as Team)
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'user_id': userId,
      'team_id': teamId,
      'role': role,
      'joined_at': joinedAt,
      'is_active': isActive,
      'invited_by': invitedBy,
      'invited_at': invitedAt,
      'approved_by': approvedBy,
      'date_joined': dateJoined,
      'status': status,
      'is_owner': isOwner,
      'user_name': userName,
      'user_email': userEmail,
      'user_photo_url': userPhotoUrl,
      // INCLUDE TEAM IN JSON (not for Firestore write)
      'team': team?.toJson(),
    };
  }

  // Alias for Firestore writes
  Map<String, dynamic> toFirestore() => toJson();

  UserTeamRole copyWith({
    String? id,
    String? userId,
    String? teamId,
    String? role,
    Timestamp? joinedAt,
    bool? isActive,
    String? invitedBy,
    Timestamp? invitedAt,
    String? approvedBy,
    Timestamp? dateJoined,
    String? status,
    bool? isOwner,
    String? userName,
    String? userEmail,
    String? userPhotoUrl,
    Team? team, // ADD TEAM TO COPYWITH
  }) {
    return UserTeamRole(
      id: id ?? this.id,
      userId: userId ?? this.userId,
      teamId: teamId ?? this.teamId,
      role: role ?? this.role,
      joinedAt: joinedAt ?? this.joinedAt,
      isActive: isActive ?? this.isActive,
      invitedBy: invitedBy ?? this.invitedBy,
      invitedAt: invitedAt ?? this.invitedAt,
      approvedBy: approvedBy ?? this.approvedBy,
      dateJoined: dateJoined ?? this.dateJoined,
      status: status ?? this.status,
      isOwner: isOwner ?? this.isOwner,
      userName: userName ?? this.userName,
      userEmail: userEmail ?? this.userEmail,
      userPhotoUrl: userPhotoUrl ?? this.userPhotoUrl,
      team: team ?? this.team, // INCLUDE TEAM IN COPYWITH
    );
  }
}