import 'package:cloud_firestore/cloud_firestore.dart';

class Reminder {
  final String id;
  final String title;
  final String description;
  final Timestamp dateTime;
  final String teamId;
  final String createdBy;
  final bool isCompleted;
  final String? athleteId;
  final Timestamp? targetDate;
  final String status;

  Reminder({
    required this.id,
    required this.title,
    required this.description,
    required this.dateTime,
    required this.teamId,
    required this.createdBy,
    this.isCompleted = false,
    this.athleteId,
    this.targetDate,
    this.status = 'pending',
  });

  factory Reminder.fromJson(Map<String, dynamic> json) {
    return Reminder(
      id: json['id'] ?? '',
      title: json['title'] ?? '',
      description: json['description'] ?? '',
      dateTime: json['date_time'] is Timestamp 
          ? json['date_time'] as Timestamp
          : (json['dateTime'] is Timestamp
              ? json['dateTime'] as Timestamp
              : (json['date_time'] != null 
                  ? Timestamp.fromDate(DateTime.parse(json['date_time'])) 
                  : (json['dateTime'] != null
                      ? Timestamp.fromDate(DateTime.parse(json['dateTime']))
                      : Timestamp.now()))),
      teamId: json['team_id'] ?? json['teamId'] ?? '',
      createdBy: json['created_by'] ?? json['createdBy'] ?? '',
      isCompleted: json['is_completed'] ?? json['isCompleted'] ?? false,
      targetDate: json['target_date'] is Timestamp 
          ? json['target_date'] as Timestamp
          : (json['targetDate'] is Timestamp
              ? json['targetDate'] as Timestamp
              : (json['target_date'] != null 
                  ? Timestamp.fromDate(DateTime.parse(json['target_date'])) 
                  : (json['targetDate'] != null
                      ? Timestamp.fromDate(DateTime.parse(json['targetDate']))
                      : null))),
      athleteId: json['athlete_id'] ?? json['athleteId'],
      status: json['status'] ?? 'pending',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'date_time': dateTime,
      'team_id': teamId,
      'created_by': createdBy,
      'is_completed': isCompleted,
      'athlete_id': athleteId,
      'target_date': targetDate,
      'status': status,
    };
  }

  Reminder copyWith({
    String? id,
    String? title,
    String? description,
    Timestamp? dateTime,
    String? teamId,
    String? createdBy,
    bool? isCompleted,
    String? athleteId,
    Timestamp? targetDate,
    String? status,
  }) {
    return Reminder(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      dateTime: dateTime ?? this.dateTime,
      teamId: teamId ?? this.teamId,
      createdBy: createdBy ?? this.createdBy,
      isCompleted: isCompleted ?? this.isCompleted,
      athleteId: athleteId ?? this.athleteId,
      targetDate: targetDate ?? this.targetDate,
      status: status ?? this.status,
    );
  }
}