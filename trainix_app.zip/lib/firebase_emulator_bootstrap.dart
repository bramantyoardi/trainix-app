// lib/firebase_emulator_bootstrap.dart

import 'dart:io' show Platform;

import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_app_check/firebase_app_check.dart';

Future<void> configureFirebaseForTests() async {
  // Pastikan Firebase sudah di-init sebelum fungsi ini dipanggil.
  // Arahkan SDK MOBILE ke emulator
  final host = Platform.isAndroid ? '10.0.2.2' : '127.0.0.1';

  // Baca port dari dart-define jika tersedia, fallback ke default
  const firestorePort = int.fromEnvironment('EMU_FIRESTORE_PORT', defaultValue: 8080);
  const authPort = int.fromEnvironment('EMU_AUTH_PORT', defaultValue: 9099);

  FirebaseFirestore.instance.useFirestoreEmulator(host, firestorePort);
  await FirebaseAuth.instance.useAuthEmulator(host, authPort);

  // App Check debug untuk test/emulator
  await FirebaseAppCheck.instance.activate(
    androidProvider: AndroidProvider.debug,
    appleProvider: AppleProvider.debug,
  );
}