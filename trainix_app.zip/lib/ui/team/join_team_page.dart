// Redirect to the actual implemented JoinTeamPage to avoid duplication/confusion
export '../team_management/join_team_page.dart';