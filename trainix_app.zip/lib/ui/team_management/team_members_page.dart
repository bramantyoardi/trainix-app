import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/team_provider.dart';
import '../../providers/auth_provider.dart';
import '../../models/user_team_role.dart';

class TeamMembersPage extends StatefulWidget {
  final String teamId;
  final String teamName;

  const TeamMembersPage({
    super.key,
    required this.teamId,
    required this.teamName,
  });

  @override
  State<TeamMembersPage> createState() => _TeamMembersPageState();
}

class _TeamMembersPageState extends State<TeamMembersPage> {
  int _selectedTabIndex = 0; // 0 Semua, 1 Pelatih, 2 Atlet, 3 Pending
  bool _isCoach = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final teamProvider = Provider.of<TeamProvider>(context, listen: false);
      final auth = Provider.of<AuthProvider>(context, listen: false);
      teamProvider.loadTeamMembers(widget.teamId);
      if (auth.user != null) {
        teamProvider
            .isCoachInTeam(teamId: widget.teamId, userId: auth.user!.uid)
            .then((value) {
          if (mounted) setState(() => _isCoach = value);
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF002122),
      appBar: AppBar(
        backgroundColor: const Color(0xFF002122),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Anggota Tim',
          style: TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Consumer<TeamProvider>(
          builder: (context, teamProvider, child) {
            final members = teamProvider.teamMembers;

            final total = members.length;
            final coachCount = members.where((m) => m.role.toLowerCase() == 'coach').length;
            final athleteCount = members.where((m) => m.role.toLowerCase() == 'athlete').length;
            final pendingCount = members.where((m) => m.status == 'pending').length;

            List<UserTeamRole> filtered;
            switch (_selectedTabIndex) {
              case 1:
                filtered = members.where((m) => m.role.toLowerCase() == 'coach').toList();
                break;
              case 2:
                filtered = members.where((m) => m.role.toLowerCase() == 'athlete').toList();
                break;
              case 3:
                filtered = members.where((m) => m.status == 'pending').toList();
                break;
              default:
                filtered = members;
            }

            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Tabs
                Row(
                  children: [
                    _buildTab('Semua', 0),
                    const SizedBox(width: 8),
                    _buildTab('Pelatih', 1),
                    const SizedBox(width: 8),
                    _buildTab('Atlet', 2),
                    const SizedBox(width: 8),
                    _buildTab('Pending', 3),
                  ],
                ),
                const SizedBox(height: 16),

                // Counters (Total, Pelatih, Atlet)
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    _buildCounter('Total', total, Colors.white),
                    _buildCounter('Pelatih', coachCount, const Color(0xFF00BF63)),
                    _buildCounter('Atlet', athleteCount, Colors.blueAccent),
                  ],
                ),
                const SizedBox(height: 16),

                Expanded(
                  child: filtered.isEmpty
                      ? const Center(
                          child: Text(
                            'Belum ada anggota untuk kategori ini',
                            style: TextStyle(color: Colors.white70),
                          ),
                        )
                      : ListView.builder(
                          itemCount: filtered.length,
                          itemBuilder: (context, index) {
                            final u = filtered[index];
                            return Container(
                              margin: const EdgeInsets.only(bottom: 10),
                              decoration: BoxDecoration(
                                color: const Color(0xFF123A3B),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: ListTile(
                                leading: CircleAvatar(
                                  backgroundColor: const Color(0xFF265B5C),
                                  child: Text(
                                    (u.userName != null && u.userName!.isNotEmpty)
                                        ? u.userName!.substring(0, 1).toUpperCase()
                                        : '?',
                                    style: const TextStyle(color: Colors.white),
                                  ),
                                ),
                                title: Text(
                                  u.userName ?? u.userEmail ?? u.userId,
                                  style: const TextStyle(color: Colors.white),
                                ),
                                subtitle: Text(
                                  '${u.role} • ${u.status ?? 'approved'}',
                                  style: const TextStyle(color: Colors.white70),
                                ),
                                trailing: (u.status == 'pending' && _isCoach)
                                    ? Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          TextButton(
                                            onPressed: () async {
                                              final teamProvider = Provider.of<TeamProvider>(context, listen: false);
                                              final auth = Provider.of<AuthProvider>(context, listen: false);
                                              final ok = await teamProvider.updateMemberStatus(
                                                teamId: widget.teamId,
                                                userId: u.userId,
                                                status: 'approved',
                                                approvedBy: auth.user?.uid,
                                              );
                                              if (!mounted) return;
                                              if (ok) {
                                                ScaffoldMessenger.of(context).showSnackBar(
                                                  const SnackBar(content: Text('Anggota disetujui')),
                                                );
                                                await teamProvider.loadTeamMembers(widget.teamId);
                                              } else {
                                                ScaffoldMessenger.of(context).showSnackBar(
                                                  const SnackBar(content: Text('Gagal menyetujui anggota')),
                                                );
                                              }
                                            },
                                            style: TextButton.styleFrom(foregroundColor: const Color(0xFF00BF63)),
                                            child: const Text('Approve'),
                                          ),
                                          const SizedBox(width: 8),
                                          TextButton(
                                            onPressed: () async {
                                              final teamProvider = Provider.of<TeamProvider>(context, listen: false);
                                              final auth = Provider.of<AuthProvider>(context, listen: false);
                                              final ok = await teamProvider.updateMemberStatus(
                                                teamId: widget.teamId,
                                                userId: u.userId,
                                                status: 'rejected',
                                                approvedBy: auth.user?.uid,
                                              );
                                              if (!mounted) return;
                                              if (ok) {
                                                ScaffoldMessenger.of(context).showSnackBar(
                                                  const SnackBar(content: Text('Anggota ditolak')),
                                                );
                                                await teamProvider.loadTeamMembers(widget.teamId);
                                              } else {
                                                ScaffoldMessenger.of(context).showSnackBar(
                                                  const SnackBar(content: Text('Gagal menolak anggota')),
                                                );
                                              }
                                            },
                                            style: TextButton.styleFrom(foregroundColor: Colors.redAccent),
                                            child: const Text('Reject'),
                                          ),
                                        ],
                                      )
                                    : null,
                              ),
                            );
                          },
                        ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _buildTab(String label, int index) {
    final selected = _selectedTabIndex == index;
    return GestureDetector(
      onTap: () => setState(() => _selectedTabIndex = index),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFF00BF63) : const Color(0xFF123A3B),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: selected ? Colors.black : Colors.white,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }

  Widget _buildCounter(String title, int value, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: const Color(0xFF123A3B),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            Text(
              '$value',
              style: TextStyle(
                color: color,
                fontSize: 18,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              title,
              style: const TextStyle(color: Colors.white70),
            ),
          ],
        ),
      ),
    );
  }
}
