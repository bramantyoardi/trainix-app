import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../services/encryption_service.dart';
import '../../providers/team_provider.dart';
import '../../models/team.dart';

class JoinTeamPage extends StatefulWidget {
  const JoinTeamPage({super.key});

  @override
  State<JoinTeamPage> createState() => _JoinTeamPageState();
}

class _JoinTeamPageState extends State<JoinTeamPage> {
  final TextEditingController _codeController = TextEditingController();
  Team? _previewTeam;
  bool _searching = false;
  bool _joining = false;

  @override
  void dispose() {
    _codeController.dispose();
    super.dispose();
  }

  Future<void> _lookupTeam(String code) async {
    final teamProvider = Provider.of<TeamProvider>(context, listen: false);
    setState(() {
      _searching = true;
      _previewTeam = null;
    });
    try {
      final team = await teamProvider.getTeamByCode(code);
      setState(() {
        _previewTeam = team;
      });
    } finally {
      setState(() {
        _searching = false;
      });
    }
  }

  Future<void> _join() async {
    final teamProvider = Provider.of<TeamProvider>(context, listen: false);
    final raw = _codeController.text.trim().toUpperCase();
    if (!EncryptionService.isValidTeamCode(raw)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Kode tim harus 6 karakter (A-Z, 0-9)')),
      );
      return;
    }
    setState(() => _joining = true);
    try {
      final ok = await teamProvider.joinTeamByCode(raw);
      if (ok) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Permintaan bergabung dikirim. Menunggu persetujuan pelatih.')),
        );
        Navigator.pop(context, true);
      } else {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(teamProvider.errorMessage ?? 'Gagal bergabung ke tim')),
        );
      }
    } finally {
      if (mounted) setState(() => _joining = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF002122),
      appBar: AppBar(
        backgroundColor: const Color(0xFF002122),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Gabung Tim',
          style: TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      // Fix overflow di layar kecil/keyboard dengan scrollable layout
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
            const Text(
              'Masukkan Kode Tim',
              style: TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _codeController,
              onChanged: (v) {
                final code = v.trim().toUpperCase();
                if (code.length == 6 && EncryptionService.isValidTeamCode(code)) {
                  _lookupTeam(code);
                } else {
                  setState(() => _previewTeam = null);
                }
              },
              textCapitalization: TextCapitalization.characters,
              maxLength: 6,
              style: const TextStyle(color: Colors.white, fontFamily: 'Poppins'),
              decoration: InputDecoration(
                counterText: '',
                hintText: 'Misal: 8A9B82',
                hintStyle: TextStyle(color: Colors.white.withOpacity(0.6), fontFamily: 'Poppins'),
                filled: true,
                fillColor: const Color(0xFF123A3B),
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: const BorderSide(color: Colors.white24),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: const BorderSide(color: Colors.white24),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: const BorderSide(color: Colors.white38),
                ),
              ),
            ),
            const SizedBox(height: 12),

            if (_searching)
              const Center(
                child: Padding(
                  padding: EdgeInsets.all(8.0),
                  child: CircularProgressIndicator(color: Colors.white),
                ),
              ),

            if (_previewTeam != null)
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: const Color(0xFF123A3B),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _previewTeam!.name,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      'Cabang Olahraga: ${_previewTeam!.cabor ?? '-'}',
                      style: const TextStyle(color: Colors.white70, fontFamily: 'Poppins'),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      'Kontingen: ${_previewTeam!.kontingen ?? '-'}',
                      style: const TextStyle(color: Colors.white70, fontFamily: 'Poppins'),
                    ),
                  ],
                ),
              ),

            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _joining ? null : _join,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF00BF63),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                child: _joining
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                      )
                    : const Text(
                        'Gabung Tim',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w600,
                        ),
                      ),
              ),
            ),
            ],
          ),
        ),
      ),
    );
  }
}
