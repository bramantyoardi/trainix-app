import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:provider/provider.dart';
import '../../providers/team_provider.dart';
import '../../providers/auth_provider.dart';
import '../../models/team.dart';
import '../../services/encryption_service.dart';

class CreateTeamPage extends StatefulWidget {
  const CreateTeamPage({super.key});

  @override
  State<CreateTeamPage> createState() => _CreateTeamPageState();
}

class _CreateTeamPageState extends State<CreateTeamPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _caborController = TextEditingController();
  final TextEditingController _kontingenController = TextEditingController();
  final TextEditingController _eventController = TextEditingController();

  DateTime? _startDate;
  DateTime? _endDate;
  bool _submitting = false;

  @override
  void dispose() {
    _nameController.dispose();
    _caborController.dispose();
    _kontingenController.dispose();
    _eventController.dispose();
    super.dispose();
  }

  Future<void> _pickDate({required bool isStart}) async {
    final initialDate = isStart
        ? (_startDate ?? DateTime.now())
        : (_endDate ?? _startDate ?? DateTime.now());
    final firstDate = DateTime(2020, 1, 1);
    final lastDate = DateTime(2100, 12, 31);
    final picked = await showDatePicker(
      context: context,
      initialDate: initialDate,
      firstDate: firstDate,
      lastDate: lastDate,
    );
    if (picked != null) {
      setState(() {
        if (isStart) {
          _startDate = picked;
          if (_endDate != null && _endDate!.isBefore(_startDate!)) {
            _endDate = null;
          }
        } else {
          _endDate = picked;
        }
      });
    }
  }

  Future<void> _submit() async {
    final auth = Provider.of<AuthProvider>(context, listen: false);
    final teamProvider = Provider.of<TeamProvider>(context, listen: false);

    if (!_formKey.currentState!.validate()) return;
    if (auth.user == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Anda harus login untuk membuat tim')),
      );
      return;
    }

    setState(() => _submitting = true);

    // Tampilkan dialog loading
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return const AlertDialog(
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 16),
              Text('Membuat tim...'),
            ],
          ),
        );
      },
    );

    try {
      final code = EncryptionService.generateTeamCode();
      // Pastikan semua field terisi dengan nilai default jika kosong
      final cabor = _caborController.text.trim().isEmpty ? 'Umum' : _caborController.text.trim();
      final kontingen = _kontingenController.text.trim().isEmpty ? 'Umum' : _kontingenController.text.trim();
      final event = _eventController.text.trim().isEmpty ? 'Latihan Reguler' : _eventController.text.trim();
      
      final team = Team(
        id: '',
        name: _nameController.text.trim(),
        description: 'Tim ${_nameController.text.trim()} - $cabor',
        coachId: auth.user!.uid,
        coachName: auth.userProfile?.name ?? auth.user!.displayName ?? 'Coach',
        createdAt: Timestamp.now(),
        tglMulai: _startDate != null ? Timestamp.fromDate(_startDate!) : Timestamp.fromDate(DateTime.now()),
        tglSelesai: _endDate != null ? Timestamp.fromDate(_endDate!) : Timestamp.fromDate(DateTime.now().add(const Duration(days: 30))),
        config: TeamConfig(targetDays: 6, weights: {}),
        cabor: cabor,
        kontingen: kontingen,
        event: event,
        teamCode: code,
      );

      final ok = await teamProvider.createTeam(team);
      
      // Tutup dialog loading
      if (mounted) {
        Navigator.of(context).pop();
      }
      
      if (ok) {
        if (!mounted) return;
        
        // Refresh data tim setelah berhasil membuat tim
        await teamProvider.loadUserTeams();
        
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Tim berhasil dibuat'),
            backgroundColor: Colors.green,
          ),
        );
        Navigator.pop(context, true);
      } else {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(teamProvider.errorMessage ?? 'Gagal membuat tim'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } catch (e) {
      // Tutup dialog loading jika terjadi error
      if (mounted) {
        Navigator.of(context).pop();
      }
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Terjadi kesalahan: $e'),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final textStyle = const TextStyle(color: Colors.white, fontFamily: 'Poppins');
    final hintStyle = TextStyle(color: Colors.white.withOpacity(0.6), fontFamily: 'Poppins');

    return Scaffold(
      backgroundColor: const Color(0xFF002122),
      appBar: AppBar(
        backgroundColor: const Color(0xFF002122),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Buat Tim Baru',
          style: TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildLabel('Nama Tim'),
              _buildInput(
                controller: _nameController,
                hint: 'Masukkan nama tim',
                validator: (v) => v == null || v.trim().isEmpty ? 'Nama tim wajib diisi' : null,
              ),
              const SizedBox(height: 16),

              _buildLabel('Cabang Olahraga'),
              _buildInput(
                controller: _caborController,
                hint: 'Contoh: Karate, Taekwondo, dll',
              ),
              const SizedBox(height: 16),

              _buildLabel('Kontingen'),
              _buildInput(
                controller: _kontingenController,
                hint: 'Contoh: Jawa Barat, DKI Jakarta',
              ),
              const SizedBox(height: 16),

              _buildLabel('Event/Kejuraan'),
              _buildInput(
                controller: _eventController,
                hint: 'Contoh: PON 2024, Asian Games',
              ),
              const SizedBox(height: 16),

              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildLabel('Tanggal Mulai'),
                        _buildDatePicker(
                          label: _startDate == null
                              ? 'Pilih tanggal'
                              : _formatDate(_startDate!),
                          onTap: () => _pickDate(isStart: true),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildLabel('Tanggal Selesai'),
                        _buildDatePicker(
                          label: _endDate == null
                              ? 'Pilih tanggal'
                              : _formatDate(_endDate!),
                          onTap: () => _pickDate(isStart: false),
                        ),
                      ],
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _submitting ? null : _submit,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF00BF63),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: _submitting
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                        )
                      : const Text(
                          'Buat Tim',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLabel(String text) {
    return Text(
      text,
      style: const TextStyle(
        color: Colors.white,
        fontSize: 14,
        fontFamily: 'Poppins',
        fontWeight: FontWeight.w600,
      ),
    );
  }

  Widget _buildInput({
    required TextEditingController controller,
    String? hint,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: controller,
      validator: validator,
      style: const TextStyle(color: Colors.white, fontFamily: 'Poppins'),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: TextStyle(color: Colors.white.withOpacity(0.6), fontFamily: 'Poppins'),
        filled: true,
        fillColor: const Color(0xFF123A3B),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: Colors.white24),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: Colors.white24),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: Colors.white38),
        ),
      ),
    );
  }

  Widget _buildDatePicker({required String label, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: const Color(0xFF123A3B),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.white24),
        ),
        child: Row(
          children: [
            Expanded(
              child: Text(
                label,
                style: const TextStyle(color: Colors.white, fontFamily: 'Poppins'),
              ),
            ),
            const Icon(Icons.calendar_today, color: Colors.white70),
          ],
        ),
      ),
    );
  }

  String _formatDate(DateTime date) {
    return '${date.day.toString().padLeft(2, '0')}-${date.month.toString().padLeft(2, '0')}-${date.year}';
  }
}
