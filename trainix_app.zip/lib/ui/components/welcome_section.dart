import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';

class WelcomeSection extends StatelessWidget {
  const WelcomeSection({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<AuthProvider>(
      builder: (context, authProvider, child) {
        final fallbackName = authProvider.userProfile?.name ??
            authProvider.user?.displayName ??
            (authProvider.user?.email != null
                ? authProvider.user!.email!.split('@').first
                : 'User');
        return Text(
          'Welcome back, $fallbackName',
          style: const TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w500,
          ),
        );
      },
    );
  }
}