import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../providers/team_provider.dart';
import 'components/welcome_section.dart';
import 'components/teams_section.dart';
import 'components/reminders_section.dart';
import 'components/top_navbar.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool _isCoach = false;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    // Delay initial data loading until after first frame to avoid
    // provider notifyListeners during build phase exceptions.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadInitialData();
    });
  }

  Future<void> _loadInitialData() async {
    final teamProvider = Provider.of<TeamProvider>(context, listen: false);
    await teamProvider.loadUserTeams();
    _checkUserRole();
  }

  Future<void> _checkUserRole() async {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final teamProvider = Provider.of<TeamProvider>(context, listen: false);
    
    if (authProvider.user != null) {
      bool isCoach = false;
      if (teamProvider.teams.isNotEmpty) {
        isCoach = await teamProvider.isCoachInTeam(
          teamId: teamProvider.teams.first.id,
          userId: authProvider.user!.uid,
        );
      }
      
      if (mounted) {
        setState(() {
          _isCoach = isCoach;
          _isLoading = false;
        });
      }
    } else {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF002122),
      body: SafeArea(
        child: Column(
          children: [
            const TopNavBar(),
            Expanded(
              child: Consumer2<AuthProvider, TeamProvider>(
                builder: (context, authProvider, teamProvider, child) {
                  final user = authProvider.user;
                  
                  if (user == null) {
                    return const Center(
                      child: CircularProgressIndicator(
                        color: Color(0xFF00BF63),
                      ),
                    );
                  }

                  if (_isLoading) {
                    return const Center(
                      child: CircularProgressIndicator(
                        color: Color(0xFF00BF63),
                      ),
                    );
                  }

                  final teamIdForReminders = _isCoach && teamProvider.teams.isNotEmpty
                      ? teamProvider.teams.first.id
                      : '';
                  final teamNameForReminders = _isCoach && teamProvider.teams.isNotEmpty
                      ? teamProvider.teams.first.name
                      : 'All Teams';

                  return ListView(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    children: [
                      const WelcomeSection(),
                      const SizedBox(height: 24),

                      TeamsSection(
                        isCoach: _isCoach,
                        userId: authProvider.user?.uid ?? '',
                      ),
                      const SizedBox(height: 24),

                      RemindersSection(
                        teamId: teamIdForReminders,
                        teamName: teamNameForReminders,
                        isCoach: _isCoach,
                        userId: authProvider.user?.uid ?? '',
                      ),

                      const SizedBox(height: 80),
                    ],
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}