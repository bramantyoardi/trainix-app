// Removed web-only import 'dart:html' to ensure compatibility on Android/iOS.

import 'package:flutter/material.dart';
import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import '../models/team.dart';
import '../models/user_team_role.dart';
import '../services/team_service.dart';
import '../services/firestore_service.dart';

class TeamProvider extends ChangeNotifier {
  final TeamService _teamService = TeamService(FirestoreService());

  List<Team> _teams = [];
  List<UserTeamRole> _userTeamRoles = [];
  List<UserTeamRole> _teamMembers = [];
  bool _isLoading = false;
  String? _errorMessage;
  StreamSubscription<List<UserTeamRole>>? _userTeamsSub;

  List<Team> get teams => _teams;
  List<UserTeamRole> get userTeamRoles => _userTeamRoles;
  List<UserTeamRole> get teamMembers => _teamMembers;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  // Getter untuk currentTeam yang dipakai UI
  Team? get currentTeam => _teams.isNotEmpty ? _teams.first : null;

  // Load user teams
  Future<void> loadUserTeams() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      // Prevent multiple concurrent listeners causing duplicated updates
      await _userTeamsSub?.cancel();
      _userTeamsSub = _teamService.getUserTeams(user.uid).listen(
        (userTeamRoles) {
          // Convert UserTeamRole list to Team list safely (skip null)
          _teams = userTeamRoles
              .where((role) => role.team != null)
              .map((role) => role.team!)
              .toList();
          _userTeamRoles = userTeamRoles;
          _isLoading = false;
          notifyListeners();
        },
        onError: (error) {
          // Handle Firestore stream errors gracefully (e.g., missing index)
          _errorMessage = 'Failed to load teams: $error';
          _isLoading = false;
          _teams = [];
          _userTeamRoles = [];
          notifyListeners();
        },
        cancelOnError: false,
      );
    } catch (e) {
      _errorMessage = 'Failed to load teams: $e';
      _isLoading = false;
      notifyListeners();
    }
  }

  // Create new team
  Future<bool> createTeam(Team team) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return false;

    try {
      final teamId = await _teamService.createTeam(team, user.uid);
      if (teamId != null) {
        // Ensure the list reflects server state after transaction commit
        await loadUserTeams();
        return true;
      }
      return false;
    } on FirebaseException catch (e) {
      _errorMessage = 'Firestore: ${e.code} — ${e.message ?? 'no message'}';
      notifyListeners();
      return false;
    } catch (e) {
      _errorMessage = e.toString();
      notifyListeners();
      return false;
    }
  }

  // Join team by invite code
  Future<bool> joinTeamByInviteCode(String inviteCode) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return false;

    try {
      final success = await _teamService.joinTeamByCode(
        inviteCode,
        user.uid,
      );
      if (success) {
        // Refresh teams list
        await loadUserTeams();
        return true;
      }
      return false;
    } catch (e) {
      _errorMessage = 'Failed to join team: $e';
      notifyListeners();
      return false;
    }
  }

  // Leave team
  Future<bool> leaveTeam(String teamId) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return false;

    try {
      final success = await _teamService.leaveTeam(user.uid, teamId);
      if (success) {
        _teams.removeWhere((team) => team.id == teamId);
        notifyListeners();
      }
      return success;
    } catch (e) {
      _errorMessage = 'Failed to leave team: $e';
      notifyListeners();
      return false;
    }
  }

  // Update team
  Future<bool> updateTeam(String teamId, Map<String, dynamic> data) async {
    try {
      final success = await _teamService.updateTeam(teamId, data);
      if (success) {
        // Update local list
        final index = _teams.indexWhere((team) => team.id == teamId);
        if (index != -1) {
          // Reload the updated team
          final updatedTeam = await _teamService.getTeam(teamId);
          if (updatedTeam != null) {
            _teams[index] = updatedTeam;
            notifyListeners();
          }
        }
      }
      return success;
    } catch (e) {
      _errorMessage = e.toString();
      notifyListeners();
      return false;
    }
  }

  // Delete team
  Future<bool> deleteTeam(String teamId) async {
    try {
      final success = await _teamService.deleteTeam(teamId);
      if (success) {
        _teams.removeWhere((team) => team.id == teamId);
        notifyListeners();
      }
      return success;
    } catch (e) {
      _errorMessage = e.toString();
      notifyListeners();
      return false;
    }
  }

  // Get team by ID
  Team? getTeamById(String teamId) {
    try {
      return _teams.firstWhere((team) => team.id == teamId);
    } catch (e) {
      return null;
    }
  }

  // Get user role in team
  String? getUserRoleInTeam(String teamId) {
    try {
      final userTeamRole =
          _userTeamRoles.firstWhere((role) => role.team?.id == teamId);
      return userTeamRole.role;
    } catch (e) {
      return null;
    }
  }

  // Check if user is coach
  bool isUserCoach(String teamId) {
    // Konsisten dengan casing role di seluruh aplikasi ('Coach' / 'Athlete')
    return getUserRoleInTeam(teamId)?.toLowerCase() == 'coach';
  }

  // Check if user is athlete
  bool isUserAthlete(String teamId) {
    return getUserRoleInTeam(teamId)?.toLowerCase() == 'athlete';
  }

  // Get team members
  Future<List<UserTeamRole>> getTeamMembers(String teamId) async {
    try {
      final members = await _teamService.getTeamMembers(teamId);
      _teamMembers = members;
      notifyListeners();
      return members;
    } catch (e) {
      _errorMessage = 'Failed to get team members: $e';
      notifyListeners();
      return [];
    }
  }

  // Load team members
  Future<void> loadTeamMembers(String teamId) async {
    try {
      _teamMembers = await _teamService.getTeamMembers(teamId);
      notifyListeners();
    } catch (e) {
      _errorMessage = 'Failed to load team members: $e';
      notifyListeners();
    }
  }

  // Generate invite code
  Future<String?> generateInviteCode(String teamId) async {
    try {
      return await _teamService.generateInviteCode(teamId);
    } catch (e) {
      _errorMessage = 'Failed to generate invite code: $e';
      notifyListeners();
      return null;
    }
  }

  // Load training logs for team
  Future<void> loadTrainingLogs(String teamId) async {
    try {
      // This method might be used by UI, implement as needed
      // For now, just a placeholder
    } catch (e) {
      _errorMessage = 'Failed to load training logs: $e';
      notifyListeners();
    }
  }

  // Update member status
  Future<bool> updateMemberStatus(
      {required String teamId,
      required String userId,
      required String status,
      String? approvedBy}) async {
    try {
      final ok = await _teamService.updateMemberStatus(
          teamId: teamId,
          userId: userId,
          status: status,
          approvedBy: approvedBy);
      if (ok) {
        // Refresh members to reflect latest status
        await loadTeamMembers(teamId);
        _errorMessage = null;
        notifyListeners();
        return true;
      } else {
        // Keep existing list but set error message for UI
        _errorMessage = 'Gagal menyetujui/menolak anggota';
        // Still refresh to pick up any server-side changes that might have succeeded
        try {
          await loadTeamMembers(teamId);
        } catch (_) {}
        notifyListeners();
        return false;
      }
    } catch (e) {
      _errorMessage = 'Failed to update member status: $e';
      notifyListeners();
      return false;
    }
  }

  // Remove member
  Future<bool> removeMember(
      {required String teamId, required String userId}) async {
    try {
      return await _teamService.removeMember(teamId: teamId, userId: userId);
    } catch (e) {
      _errorMessage = 'Failed to remove member: $e';
      notifyListeners();
      return false;
    }
  }

  // Change member role
  Future<bool> changeMemberRole(
      {required String teamId,
      required String userId,
      required String newRole}) async {
    try {
      return await _teamService.changeMemberRole(
          teamId: teamId, userId: userId, newRole: newRole);
    } catch (e) {
      _errorMessage = 'Failed to change member role: $e';
      notifyListeners();
      return false;
    }
  }

  // Check if user is coach in team
  Future<bool> isCoachInTeam(
      {required String teamId, required String userId}) async {
    try {
      return await _teamService.isCoachInTeam(teamId: teamId, userId: userId);
    } catch (e) {
      return false;
    }
  }

  // Get team by code
  Future<Team?> getTeamByCode(String teamCode) async {
    try {
      return await _teamService.getTeamByCode(teamCode);
    } catch (e) {
      _errorMessage = 'Failed to get team by code: $e';
      notifyListeners();
      return null;
    }
  }

  // Join team by code
  Future<bool> joinTeamByCode(String teamCode) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return false;

    try {
      final success = await _teamService.joinTeamByCode(
        teamCode,
        user.uid,
      );
      if (success) {
        await loadUserTeams();
        return true;
      }
      return false;
    } catch (e) {
      _errorMessage = 'Failed to join team by code: $e';
      notifyListeners();
      return false;
    }
  }

  // Backward-compatible wrapper used by some UI components
  // Simply delegates to joinTeamByCode(teamCode)
  Future<bool> joinTeam(String teamCode) async {
    return await joinTeamByCode(teamCode);
  }

  // Clear teams
  void clearTeams() {
    _teams.clear();
    _userTeamRoles.clear();
    _teamMembers.clear();
    notifyListeners();
  }

  // Refresh teams
  Future<void> refreshTeams() async {
    await loadUserTeams();
  }

  // Remove team from local list
  void removeTeam(String teamId) {
    _teams.removeWhere((team) => team.id == teamId);
    _userTeamRoles.removeWhere((role) => role.team?.id == teamId);
    _teamMembers.removeWhere((member) => member.team?.id == teamId);
    notifyListeners();
  }

  @override
  void dispose() {
    _userTeamsSub?.cancel();
    super.dispose();
  }
}
