import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:flutter/foundation.dart';
import 'package:trainix_app/models/team.dart';
import 'package:trainix_app/models/user_team_role.dart';
import 'package:trainix_app/services/firestore_service.dart';
import 'package:trainix_app/services/user_service.dart';

class TeamService {
  final FirestoreService _firestoreService;
  final String _teamCollection = 'teams';
  final _db = FirebaseFirestore.instance;
  final _auth = FirebaseAuth.instance;

  TeamService(this._firestoreService);

  // Helper: normalize incoming Map to canonical snake_case fields
  Map<String, dynamic> _toCanonical(Map<String, dynamic> data) {
    final currentUser = _auth.currentUser;
    final uid = currentUser?.uid ?? '';
    final now = FieldValue.serverTimestamp();

    final canonical = <String, dynamic>{
      'name': data['name'],
      'description': data['description'],
      'coach_id': data['coach_id'] ?? data['coachId'] ?? uid,
      'coach_name': data['coach_name'] ?? data['coachName'],
      'coach_photo_url': data['coach_photo_url'] ?? data['coachPhotoUrl'],
      'team_photo_url': data['team_photo_url'] ?? data['teamPhotoUrl'],
      'team_code': data['team_code'] ??
          data['invite_code'] ??
          data['inviteCode'] ??
          data['teamCode'],
      'is_active': data['is_active'] ?? data['isActive'] ?? true,
      'max_members': data['max_members'] ?? data['maxMembers'] ?? 50,
      'categories': data['categories'] ?? [],
      'location': data['location'],
      'metadata': data['metadata'],
      'cabor': data['cabor'],
      'kontingen': data['kontingen'],
      'event': data['event'],
      'tgl_mulai': data['tgl_mulai'] ?? data['tglMulai'],
      'tgl_selesai': data['tgl_selesai'] ?? data['tglSelesai'],
      'config': data['config'] ??
          {
            'targetDays': 6,
            'weights': {
              'consistency': 0.6,
              'intensity': 0.4,
            },
            'allowRecovery': true,
          },
    };

    // Handle audit fields for create operation
    if (!data.containsKey('created_at') && !data.containsKey('createdAt')) {
      canonical['created_at'] = now;
      canonical['created_by'] = uid;
      canonical['updated_at'] = now;
      canonical['updated_by'] = uid;
    }
    // Handle audit fields for update operation
    else {
      canonical['updated_at'] = now;
      canonical['updated_by'] = uid;
    }

    // Remove nulls to avoid writing null fields unintentionally
    canonical.removeWhere((key, value) => value == null);
    return canonical;
  }

  // Legacy generator removed. Use _generateUniqueTeamCode() which ensures uniqueness via Firestore lookup.

  Future<bool> _teamCodeExists(String code) async {
    final snap = await _db
        .collection(_teamCollection)
        .where('team_code', isEqualTo: code)
        .limit(1)
        .get();
    return snap.size > 0;
  }

  // Generate a team code and ensure uniqueness by checking Firestore
  // Attempts up to 40 times to avoid rare collisions
  Future<String> _generateUniqueTeamCode() async {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    final random = Random();
    for (int attempt = 0; attempt < 40; attempt++) {
      final result = StringBuffer();
      for (var i = 0; i < 6; i++) {
        result.write(chars[random.nextInt(chars.length)]);
      }
      final code = result.toString();
      final exists = await _teamCodeExists(code);
      if (!exists) return code;
    }
    // Fallback terakhir bila terjadi tabrakan terus-menerus (sangat kecil kemungkinannya)
    final fallback = StringBuffer();
    for (var i = 0; i < 6; i++) {
      fallback.write(chars[random.nextInt(chars.length)]);
    }
    return fallback.toString();
  }

  // Create team
  Future<String?> createTeam(Team team, String userId) async {
    try {
      final currentUser = _auth.currentUser;
      if (currentUser == null) {
        debugPrint('[FS][team.create] currentUser null');
        return null;
      }

      // Convert Team to Map
      final data = team.toJson();

      // Pastikan created_by ada
      if (!data.containsKey('created_by') && !data.containsKey('createdBy')) {
        data['created_by'] = userId;
      }

      // Buat/validasi kode tim unik (6 uppercase alfanumerik)
      String teamCode;
      if (team.teamCode != null && team.teamCode!.isNotEmpty) {
        // Gunakan nilai sebagaimana disuplai untuk validasi; jangan ubah ke uppercase agar tes bisa mendeteksi format salah
        final provided = team.teamCode!;
        final isValid = RegExp(r'^[A-Z0-9]{6}$').hasMatch(provided);
        if (!isValid) {
          debugPrint(
              '[FS][team.create] invalid team_code provided: ${team.teamCode}');
          return null; // explicit failure for invalid provided code
        }
        final exists = await _teamCodeExists(provided);
        if (exists) {
          debugPrint(
              '[FS][team.create] duplicate team_code provided: $provided');
          return null; // explicit failure for duplicate provided code
        }
        teamCode = provided;
      } else {
        teamCode = await _generateUniqueTeamCode();
      }
      // Tulis hanya field kanonik
      data['team_code'] = teamCode;

      // Pastikan coach_id ada
      if (!data.containsKey('coach_id') && !data.containsKey('coachId')) {
        data['coach_id'] = userId;
      }

      // Pastikan coach_name ada
      if (!data.containsKey('coach_name') && !data.containsKey('coachName')) {
        data['coach_name'] = currentUser.displayName ?? 'Coach';
      }

      // Konversi ke format canonical (snake_case)
      final teamData = _toCanonical(data);

      // Tambahkan member_count untuk memudahkan UI
      teamData['member_count'] = 1;
      // Tetapkan default join_policy bila tidak disuplai
      if (!teamData.containsKey('join_policy')) {
        teamData['join_policy'] = 'ask_to_join';
      }

      // Gunakan transaction untuk memastikan konsistensi
      final teamRef = _db.collection(_teamCollection).doc();
      final teamId = teamRef.id;

      // Buat dokumen tim
      await teamRef.set(teamData);

      try {
        // Buat owner membership
        await _createOwnerMembership(teamId, userId);
      } catch (membershipError) {
        debugPrint(
            '[TeamService] Error creating membership, but team was created: $membershipError');
        // Tidak perlu rethrow, tim sudah terbuat
      }

      debugPrint(
          '[FS][team.create] Team created: $teamId with code: $teamCode');
      return teamId;
    } catch (e) {
      debugPrint('[TeamService] Error creating team: $e');
      return null;
    }
  }

  // Membuat owner membership untuk tim
  Future<void> _createOwnerMembership(String teamId, String userId) async {
    try {
      if (teamId.isEmpty || userId.isEmpty) {
        debugPrint('[FS][team.membership] ERROR: Invalid teamId or userId');
        return;
      }

      // Ambil user_name dari koleksi users untuk disimpan di dokumen member
      final String? userName = await _resolveUserName(userId);

      final memberRef = _db
          .collection(_teamCollection)
          .doc(teamId)
          .collection('members')
          .doc(userId);

      final memberData = {
        'user_id': userId,
        'team_id': teamId,
        'role': 'coach',
        'is_owner': true,
        'status': 'approved',
        'is_active': true,
        'joined_at': FieldValue.serverTimestamp(),
        'created_at': FieldValue.serverTimestamp(),
        'updated_at': FieldValue.serverTimestamp(),
        'created_by': userId,
        'updated_by': userId,
        if (userName != null && userName.isNotEmpty) 'user_name': userName,
      };

      await memberRef.set(memberData);
      debugPrint(
          '[FS][team.membership] Owner membership created: teamId=$teamId, userId=$userId');
    } catch (e) {
      // Tangkap error tapi jangan rethrow untuk mencegalkan kegagalan pembuatan tim
      debugPrint('[FS][team.membership] Error creating owner membership: $e');
      // Coba lagi dengan metode alternatif
      try {
        final memberRef = _db
            .collection(_teamCollection)
            .doc(teamId)
            .collection('members')
            .doc(userId);

        final memberData = {
          'user_id': userId,
          'team_id': teamId,
          'role': 'coach',
          'is_owner': true,
          'status': 'approved',
          'is_active': true,
          'joined_at': FieldValue.serverTimestamp(),
          'created_at': FieldValue.serverTimestamp(),
          'updated_at': FieldValue.serverTimestamp(),
          'created_by': userId,
          'updated_by': userId,
        };

        await _db.runTransaction((transaction) async {
          transaction.set(memberRef, memberData);
        });
        debugPrint(
            '[FS][team.membership] Owner membership created with transaction: teamId=$teamId, userId=$userId');
      } catch (retryError) {
        debugPrint(
            '[FS][team.membership] Failed retry for owner membership: $retryError');
      }
    }
  }

  // Get team by ID
  Future<Team?> getTeam(String teamId) async {
    try {
      if (teamId.isEmpty) {
        debugPrint('[TeamService] getTeam: teamId empty');
        return null;
      }

      final doc = await _db.collection(_teamCollection).doc(teamId).get();
      if (!doc.exists) return null;

      final data = doc.data()!;
      data['id'] = doc.id;
      return Team.fromJson(data);
    } catch (e) {
      debugPrint('[TeamService] Error getting team: $e');
      return null;
    }
  }

  // Update team
  Future<bool> updateTeam(String teamId, Map<String, dynamic> data) async {
    try {
      if (teamId.isEmpty) {
        debugPrint('[TeamService] updateTeam: teamId empty');
        return false;
      }

      final teamData = _toCanonical(data);
      await _db.collection(_teamCollection).doc(teamId).update(teamData);
      return true;
    } catch (e) {
      debugPrint('[TeamService] Error updating team: $e');
      return false;
    }
  }

  // Delete team
  Future<bool> deleteTeam(String teamId) async {
    try {
      if (teamId.isEmpty) {
        debugPrint('[TeamService] deleteTeam: teamId empty');
        return false;
      }

      await _db.collection(_teamCollection).doc(teamId).delete();
      return true;
    } catch (e) {
      debugPrint('[TeamService] Error deleting team: $e');
      return false;
    }
  }

  // Get user teams (as stream)
  Stream<List<UserTeamRole>> getUserTeams(String userId) {
    try {
      if (userId.isEmpty) {
        debugPrint('[FS][team.getUserTeams] userId empty');
        return Stream.value([]);
      }

      // Filter only the current user's membership docs and only active + approved ones
      return _db
          .collectionGroup('members')
          .where('user_id', isEqualTo: userId)
          .where('is_active', isEqualTo: true)
          .where('status', isEqualTo: 'approved')
          .snapshots()
          .asyncMap((snapshot) async {
        List<UserTeamRole> userTeamRoles = [];

        for (var doc in snapshot.docs) {
          try {
            // Extract teamId from reference path
            final segments = doc.reference.path.split('/');
            if (segments.length < 3) continue;

            final teamId = segments[1];
            final teamDoc =
                await _db.collection(_teamCollection).doc(teamId).get();

            if (!teamDoc.exists) continue;

            final teamData = teamDoc.data()!;
            teamData['id'] = teamDoc.id;

            final team = Team.fromJson(teamData);
            final memberData = doc.data();
            memberData['id'] = doc.id;
            memberData['team'] =
                teamData; // Menyimpan data tim sebagai Map, bukan objek Team

            userTeamRoles.add(UserTeamRole.fromJson(memberData));
          } catch (e) {
            debugPrint('[TeamService] Error processing team member: $e');
            // Continue to next doc even if one fails
            continue;
          }
        }

        return userTeamRoles;
      });
    } catch (e) {
      debugPrint('[TeamService] Error getting user teams: $e');
      return Stream.value([]);
    }
  }

  // Get team members
  Future<List<UserTeamRole>> getTeamMembers(String teamId) async {
    try {
      if (teamId.isEmpty) {
        debugPrint('[TeamService] getTeamMembers: teamId empty');
        return [];
      }

      final snapshot = await _db
          .collection(_teamCollection)
          .doc(teamId)
          .collection('members')
          .get();

      final team = await getTeam(teamId);
      if (team == null) return [];

      return snapshot.docs.map((doc) {
        final data = doc.data();
        data['id'] = doc.id;
        data['team'] = team;
        return UserTeamRole.fromJson(data);
      }).toList();
    } catch (e) {
      debugPrint('[TeamService] Error getting team members: $e');
      return [];
    }
  }

  // Generate invite code
  Future<String?> generateInviteCode(String teamId) async {
    try {
      if (teamId.isEmpty) {
        debugPrint('[TeamService] generateInviteCode: teamId empty');
        return null;
      }

      // Cek aturan imutabilitas: hanya boleh set jika belum punya team_code
      final teamDoc = await _db.collection(_teamCollection).doc(teamId).get();
      if (!teamDoc.exists) {
        debugPrint('[TeamService] generateInviteCode: team not found');
        return null;
      }
      final currentCode = teamDoc.data()?['team_code'];
      if (currentCode != null && (currentCode as String).isNotEmpty) {
        debugPrint(
            '[TeamService] generateInviteCode: team_code already set and immutable');
        return null;
      }

      final code = await _generateUniqueTeamCode();
      await _db.collection(_teamCollection).doc(teamId).update({
        'team_code': code,
        'updated_at': FieldValue.serverTimestamp(),
        'updated_by': _auth.currentUser?.uid ?? '',
      });

      return code;
    } catch (e) {
      debugPrint('[TeamService] Error generating invite code: $e');
      return null;
    }
  }

  // Join team with code
  Future<bool> joinTeam(
      {required String teamCode,
      required String userId,
      String role = 'athlete'}) async {
    try {
      if (teamCode.isEmpty || userId.isEmpty) {
        debugPrint('[TeamService] joinTeam: teamCode or userId empty');
        return false;
      }

      // Find team by code
      final teamsRef = _db.collection(_teamCollection);
      var snapshot =
          await teamsRef.where('team_code', isEqualTo: teamCode).limit(1).get();
      if (snapshot.docs.isEmpty) {
        // Fallback legacy field untuk dokumen lama
        snapshot = await teamsRef
            .where('invite_code', isEqualTo: teamCode)
            .limit(1)
            .get();
      }

      if (snapshot.docs.isEmpty) {
        debugPrint('[TeamService] joinTeam: team not found for code $teamCode');
        return false;
      }

      final teamDoc = snapshot.docs.first;
      final teamId = teamDoc.id;
      final joinPolicy =
          (teamDoc.data()['join_policy'] ?? 'ask_to_join') as String;

      final memberRef = _db
          .collection(_teamCollection)
          .doc(teamId)
          .collection('members')
          .doc(userId);

      // Check if already a member
      final memberDoc = await memberRef.get();
      if (memberDoc.exists) {
        debugPrint('[TeamService] joinTeam: already a member of team $teamId');
        return true;
      }

      // Tentukan status berdasarkan join_policy
      String status;
      if (joinPolicy == 'open') {
        status = 'approved';
      } else if (joinPolicy == 'ask_to_join') {
        status = 'pending';
      } else {
        // 'closed' atau nilai lain -> tolak
        debugPrint(
            '[TeamService] joinTeam: join_policy closed, cannot join team $teamId');
        return false;
      }

      // Add as member
      final String? userName = await _resolveUserName(userId);
      await memberRef.set({
        'user_id': userId,
        'team_id': teamId,
        'role': role,
        'joined_at': FieldValue.serverTimestamp(),
        'created_at': FieldValue.serverTimestamp(),
        'updated_at': FieldValue.serverTimestamp(),
        'created_by': userId,
        'updated_by': userId,
        'is_active': true,
        'status': status,
        if (userName != null && userName.isNotEmpty) 'user_name': userName,
      });

      return true;
    } catch (e) {
      debugPrint('[TeamService] Error joining team: $e');
      return false;
    }
  }

  // Helper: Ambil username dari koleksi users, fallback ke name jika username kosong
  Future<String?> _resolveUserName(String uid) async {
    try {
      final userService = UserService(FirestoreService());
      final profile = await userService.getUserProfile(uid);
      if (profile != null) {
        if (profile.username != null && profile.username!.isNotEmpty) {
          return profile.username;
        }
        if (profile.name.isNotEmpty) {
          return profile.name;
        }
      }
      return null;
    } catch (e) {
      debugPrint('[TeamService] _resolveUserName error: $e');
      return null;
    }
  }

  // Join team by invite code (alias for joinTeam)
  Future<bool> joinTeamByInviteCode(
      {required String inviteCode,
      required String userId,
      String role = 'athlete'}) async {
    return joinTeam(teamCode: inviteCode, userId: userId, role: role);
  }

  // Join team by code (alias for joinTeam)
  Future<bool> joinTeamByCode(String teamCode, String userId,
      {String role = 'athlete'}) async {
    return joinTeam(teamCode: teamCode, userId: userId, role: role);
  }

  // Leave team
  Future<bool> leaveTeam(String userId, String teamId) async {
    try {
      if (teamId.isEmpty || userId.isEmpty) {
        debugPrint('[TeamService] leaveTeam: teamId or userId empty');
        return false;
      }

      final memberRef = _db
          .collection(_teamCollection)
          .doc(teamId)
          .collection('members')
          .doc(userId);

      // Check if is a member
      final memberDoc = await memberRef.get();
      if (!memberDoc.exists) {
        debugPrint('[TeamService] leaveTeam: not a member of team $teamId');
        return false;
      }
      // Prefer callable to perform server-side self-leave (deletes membership safely)
      try {
        final functions = FirebaseFunctions.instanceFor(region: 'asia-southeast1');
        final callable = functions.httpsCallable('leaveTeam');
        final payload = {
          'teamId': teamId,
        };
        debugPrint('[TeamService] Calling leaveTeam with payload=$payload');
        final result = await callable.call(payload);
        final data = result.data;
        debugPrint('[TeamService] leaveTeam callable result => $data');
        final ok = (data is Map)
            ? ((data['ok'] == true) || (data['status'] == 'ok'))
            : false;
        if (ok) {
          return true;
        }
        debugPrint('[TeamService] leaveTeam callable returned non-ok, attempting client delete...');
      } catch (e) {
        debugPrint('[TeamService] leaveTeam callable ERROR: $e. Attempting client delete...');
      }

      // Fallback: client-side delete (allowed by rules for non-owner self)
      await memberRef.delete();
      return true;
    } catch (e) {
      debugPrint('[TeamService] Error leaving team: $e');
      return false;
    }
  }

  // Update member status
  Future<bool> updateMemberStatus(
      {required String teamId,
      required String userId,
      required String status,
      String? approvedBy}) async {
    try {
      if (teamId.isEmpty || userId.isEmpty) {
        debugPrint('[TeamService] updateMemberStatus: teamId or userId empty');
        return false;
      }

      final memberRef = _db
          .collection(_teamCollection)
          .doc(teamId)
          .collection('members')
          .doc(userId);

      // Check if is a member
      final memberDoc = await memberRef.get();
      if (!memberDoc.exists) {
        debugPrint(
            '[TeamService] updateMemberStatus: not a member of team $teamId');
        return false;
      }

      // Normalize and validate status according to Firestore rules
      final actorUid = _auth.currentUser?.uid ?? '';
      // Fetch actor membership for debug and client-side guard
      try {
        final actorDocSnap = await _db
            .collection(_teamCollection)
            .doc(teamId)
            .collection('members')
            .doc(actorUid)
            .get();
        final actorData = actorDocSnap.data();
        debugPrint('[TeamService] Actor membership => exists=${actorDocSnap.exists} role=${actorData?['role']} is_owner=${actorData?['is_owner']} status=${actorData?['status']} is_active=${actorData?['is_active']}');
        // Client-side guard: must be approved coach/owner
        final isApproved = actorData?['status']?.toString().toLowerCase() == 'approved';
        final role = actorData?['role']?.toString();
        final isOwner = actorData?['is_owner'] == true;
        final isCoachRole = role == 'coach' || role == 'Coach' || role == 'COACH';
        if (!actorDocSnap.exists || !isApproved || !(isCoachRole || isOwner)) {
          // Do NOT hard-fail here; log and continue to try via direct write or callable fallback.
          debugPrint('[TeamService] updateMemberStatus: WARN actor not allowed by client-side guard (must be approved coach/owner). Proceeding to attempt write and callable fallback.');
        }
      } catch (e) {
        debugPrint('[TeamService] Warning: failed to read actor membership for guard: $e');
      }
      final normalizedStatus = status.trim().toLowerCase();
      const allowedStatuses = {'pending', 'approved', 'rejected'};
      if (!allowedStatuses.contains(normalizedStatus)) {
        debugPrint(
            '[TeamService] updateMemberStatus: invalid status "$status" (normalized="$normalizedStatus"). Allowed: $allowedStatuses');
        return false;
      }

      // Only allowed fields to change during approve/reject
      // - status (pending|approved|rejected)
      // - is_active (true iff approved)
      // - updated_at (server timestamp)
      // - updated_by (actor uid)
      // - approved_by (actor uid) when status != pending
      final isActive = normalizedStatus == 'approved';
      final updateData = <String, dynamic>{
        'status': normalizedStatus,
        'is_active': isActive,
        'updated_at': FieldValue.serverTimestamp(),
        'updated_by': actorUid,
      };

      // Force approved_by to actor for approved/rejected actions
      if (normalizedStatus != 'pending') {
        updateData['approved_by'] = actorUid;
      }

      // Extra debug to help diagnose PERMISSION_DENIED
      debugPrint('[TeamService] updateMemberStatus payload => teamId=$teamId userId=$userId actorUid=$actorUid status=$normalizedStatus is_active=$isActive approved_by=${updateData['approved_by'] ?? '(null)'}');

      try {
        await memberRef.update(updateData);
        // Verify by re-reading the target doc to ensure the status actually changed
        try {
          final verifySnap = await memberRef.get();
          final verifyStatus = verifySnap.data()?['status']?.toString().toLowerCase();
          if (verifyStatus == normalizedStatus) {
            return true;
          }
          debugPrint('[TeamService] Direct update completed but verify status="$verifyStatus" != "$normalizedStatus". Proceeding to callable fallback.');
        } catch (vErr) {
          debugPrint('[TeamService] Warning: failed verifying direct update result: $vErr. Proceeding to callable fallback.');
        }
        // If direct update didn’t reflect the desired status, attempt callable fallback.
        if (normalizedStatus == 'approved' || normalizedStatus == 'rejected') {
          try {
            final functions = FirebaseFunctions.instanceFor(region: 'asia-southeast1');
            final callable = functions.httpsCallable('approveOrRejectMembership');
            final action = normalizedStatus == 'approved' ? 'approve' : 'reject';
            final payload = {
              'teamId': teamId,
              'memberId': userId,
              'action': action,
            };
            debugPrint('[TeamService] Calling approveOrRejectMembership (fallback after direct update) with payload=$payload');
            final result = await callable.call(payload);
            final data = result.data;
            debugPrint('[TeamService] Callable result => $data');
            // Accept broader success shapes: {status:'ok'}, {ok:true}, 'ok', true
            bool ok = false;
            if (data is Map) {
              ok = (data['ok'] == true) || (data['status']?.toString().toLowerCase() == 'ok');
            } else if (data is String) {
              ok = data.toLowerCase() == 'ok';
            } else if (data is bool) {
              ok = data == true;
            }
            if (ok) {
              return true;
            }
            // If response shape was unexpected, verify target doc status directly
            try {
              final verifySnap2 = await memberRef.get();
              final verifyStatus2 = verifySnap2.data()?['status']?.toString().toLowerCase();
              debugPrint('[TeamService] Callable verify status => $verifyStatus2');
              if (verifyStatus2 == normalizedStatus) {
                return true;
              }
            } catch (vErr2) {
              debugPrint('[TeamService] Warning: failed verifying callable result: $vErr2');
            }
            debugPrint('[TeamService] Callable approveOrRejectMembership returned non-ok response: $data');
            return false;
          } catch (ce) {
            debugPrint('[TeamService] Callable approveOrRejectMembership ERROR: $ce');
            return false;
          }
        } else {
          // For pending transitions, no callable fallback; return false.
          return false;
        }
      } on FirebaseException catch (fe) {
        // If Firestore rules block direct write, attempt callable Cloud Function fallback for approve/reject.
        debugPrint('[TeamService] updateMemberStatus: direct write failed code=${fe.code} message=${fe.message}. Trying callable fallback...');
        if (normalizedStatus == 'approved' || normalizedStatus == 'rejected') {
          try {
            final functions = FirebaseFunctions.instanceFor(region: 'asia-southeast1');
            final callable = functions.httpsCallable('approveOrRejectMembership');
            final action = normalizedStatus == 'approved' ? 'approve' : 'reject';
            final payload = {
              'teamId': teamId,
              'memberId': userId,
              'action': action,
            };
            debugPrint('[TeamService] Calling approveOrRejectMembership with payload=$payload');
            final result = await callable.call(payload);
            final data = result.data;
            debugPrint('[TeamService] Callable result => $data');
            // Accept broader success shapes: {status:'ok'}, {ok:true}, 'ok', true
            bool ok = false;
            if (data is Map) {
              ok = (data['ok'] == true) || (data['status']?.toString().toLowerCase() == 'ok');
            } else if (data is String) {
              ok = data.toLowerCase() == 'ok';
            } else if (data is bool) {
              ok = data == true;
            }

            if (ok) {
              return true;
            }

            // If response shape was unexpected, verify target doc status directly
            try {
              final verifySnap = await memberRef.get();
              final verifyStatus = verifySnap.data()?['status']?.toString().toLowerCase();
              debugPrint('[TeamService] Callable verify status => $verifyStatus');
              if (verifyStatus == normalizedStatus) {
                return true;
              }
            } catch (vErr) {
              debugPrint('[TeamService] Warning: failed verifying callable result: $vErr');
            }

            debugPrint('[TeamService] Callable approveOrRejectMembership returned non-ok response: $data');
            return false;
          } catch (ce) {
            debugPrint('[TeamService] Callable approveOrRejectMembership ERROR: $ce');
            return false;
          }
        } else {
          // For pending transitions, no callable fallback; return false.
          return false;
        }
      }
    } catch (e) {
      final actorUid = _auth.currentUser?.uid;
      debugPrint('[TeamService] updateMemberStatus EXCEPTION actorUid=$actorUid teamId=$teamId targetUserId=$userId error=$e');
      return false;
    }
  }

  // Callable-first API to approve or reject a pending athlete
  // Usage: approveOrRejectMembership(teamId: '...', targetUid: '...', action: 'approve'|'reject')
  Future<bool> approveOrRejectMembership({
    required String teamId,
    required String targetUid,
    required String action,
  }) async {
    try {
      if (teamId.isEmpty || targetUid.isEmpty) {
        debugPrint('[TeamService] approveOrRejectMembership: teamId/targetUid empty');
        return false;
      }
      final normalized = action.trim().toLowerCase();
      if (normalized != 'approve' && normalized != 'reject') {
        debugPrint('[TeamService] approveOrRejectMembership: invalid action="$action"');
        return false;
      }

      final functions = FirebaseFunctions.instanceFor(region: 'asia-southeast1');
      final callable = functions.httpsCallable('approveOrRejectMembership');
      final payload = {
        'teamId': teamId,
        'memberId': targetUid,
        'action': normalized,
      };
      debugPrint('[TeamService] Calling approveOrRejectMembership with payload=$payload');
      final result = await callable.call(payload);
      final data = result.data;
      debugPrint('[TeamService] approveOrRejectMembership result => $data');
      // Accept {status:'ok'}, {ok:true}, 'ok', true
      bool ok = false;
      if (data is Map) {
        ok = (data['ok'] == true) || (data['status']?.toString().toLowerCase() == 'ok');
      } else if (data is String) {
        ok = data.toLowerCase() == 'ok';
      } else if (data is bool) {
        ok = data == true;
      }
      if (ok) return true;

      // Verify by reading target doc status
      try {
        final snap = await _db
            .collection(_teamCollection)
            .doc(teamId)
            .collection('members')
            .doc(targetUid)
            .get();
        final verifyStatus = snap.data()?['status']?.toString().toLowerCase();
        debugPrint('[TeamService] approveOrRejectMembership verify status => $verifyStatus');
        if (verifyStatus == (action == 'approve' ? 'approved' : 'rejected')) {
          return true;
        }
      } catch (vErr) {
        debugPrint('[TeamService] approveOrRejectMembership verify ERROR: $vErr');
      }
      return false;
    } on FirebaseFunctionsException catch (e) {
      debugPrint('[TeamService] approveOrRejectMembership FirebaseFunctionsException code=${e.code} message=${e.message}');
      return false;
    } catch (e) {
      debugPrint('[TeamService] approveOrRejectMembership ERROR: $e');
      return false;
    }
  }

  Future<bool> approveMember({required String teamId, required String targetUid}) async {
    return approveOrRejectMembership(teamId: teamId, targetUid: targetUid, action: 'approve');
  }

  Future<bool> rejectMember({required String teamId, required String targetUid}) async {
    return approveOrRejectMembership(teamId: teamId, targetUid: targetUid, action: 'reject');
  }

  // Change member role
  Future<bool> changeMemberRole(
      {required String teamId,
      required String userId,
      required String newRole}) async {
    try {
      if (teamId.isEmpty || userId.isEmpty || newRole.isEmpty) {
        debugPrint('[TeamService] changeMemberRole: invalid parameters');
        return false;
      }

      await _db
          .collection(_teamCollection)
          .doc(teamId)
          .collection('members')
          .doc(userId)
          .update({
        'role': newRole,
        'updated_at': FieldValue.serverTimestamp(),
        'updated_by': _auth.currentUser?.uid ?? '',
      });

      return true;
    } catch (e) {
      debugPrint('[TeamService] Error changing member role: $e');
      return false;
    }
  }

  // Remove member from team
  Future<bool> removeMember(
      {required String teamId, required String userId}) async {
    try {
      if (teamId.isEmpty || userId.isEmpty) {
        debugPrint('[TeamService] removeMember: teamId or userId empty');
        return false;
      }

      await _db
          .collection(_teamCollection)
          .doc(teamId)
          .collection('members')
          .doc(userId)
          .delete();

      return true;
    } catch (e) {
      debugPrint('[TeamService] Error removing member: $e');
      return false;
    }
  }

  // Check if user is coach in team
  Future<bool> isCoachInTeam(
      {required String teamId, required String userId}) async {
    try {
      if (teamId.isEmpty || userId.isEmpty) {
        debugPrint('[TeamService] isCoachInTeam: teamId or userId empty');
        return false;
      }

      final doc = await _db
          .collection(_teamCollection)
          .doc(teamId)
          .collection('members')
          .doc(userId)
          .get();

      if (!doc.exists) return false;

      final role = doc.data()?['role'];
      // Terima kapital/lowercase agar kompatibel dengan data lama/baru
      return role == 'Coach' ||
          role == 'Owner' ||
          role == 'coach' ||
          role == 'owner';
    } catch (e) {
      debugPrint('[TeamService] Error checking coach status: $e');
      return false;
    }
  }

  // Get team by code
  Future<Team?> getTeamByCode(String teamCode) async {
    try {
      if (teamCode.isEmpty) {
        debugPrint('[TeamService] getTeamByCode: teamCode empty');
        return null;
      }

      final teamsRef = _db.collection(_teamCollection);
      var snapshot =
          await teamsRef.where('team_code', isEqualTo: teamCode).limit(1).get();
      if (snapshot.docs.isEmpty) {
        // Fallback legacy field for dokumen lama
        snapshot = await teamsRef
            .where('invite_code', isEqualTo: teamCode)
            .limit(1)
            .get();
      }

      if (snapshot.docs.isEmpty) return null;

      final doc = snapshot.docs.first;
      final data = doc.data();
      data['id'] = doc.id;

      return Team.fromJson(data);
    } catch (e) {
      debugPrint('[TeamService] Error getting team by code: $e');
      return null;
    }
  }
}
