
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:trainix_app/models/training_log.dart';
import 'package:trainix_app/services/firestore_service.dart';

class TrainingLogService {
  final FirestoreService _firestoreService = FirestoreService();
  // Canonical subcollection name per schema
  final String _collection = 'training_logs';
  final _db = FirebaseFirestore.instance;
  final _auth = FirebaseAuth.instance;

  // Helper: normalize incoming Map to canonical snake_case fields
  Map<String, dynamic> _toCanonical(Map<String, dynamic> data, {String? teamId}) {
    final currentUser = _auth.currentUser;
    final uid = currentUser?.uid ?? '';
    final now = FieldValue.serverTimestamp();
    
    final canonical = <String, dynamic>{
      'athlete_id': data['athlete_id'] ?? data['athleteId'],
      'team_id': data['team_id'] ?? data['teamId'] ?? teamId,
      'program_id': data['program_id'] ?? data['programId'],
      'category': data['category'],
      'preset': data['preset'],
      'data': data['data'],
      'date': data['date'],
      'score': data['score'],
      'notes': data['notes'],
      'is_completed': data['is_completed'] ?? data['isCompleted'] ?? false,
      'coach_feedback': data['coach_feedback'] ?? data['coachFeedback'],
      'metadata': data['metadata'],
      'input_by': data['input_by'] ?? data['inputBy'] ?? uid,
      'user_role': data['user_role'] ?? data['userRole'],
      'hrr_band': data['hrr_band'] ?? data['hrrBand'],
    };

    // Handle audit fields for create operation
    if (!data.containsKey('created_at') && !data.containsKey('createdAt')) {
      canonical['created_at'] = now;
      canonical['created_by'] = uid;
      canonical['updated_at'] = now;
      canonical['updated_by'] = uid;
    } 
    // Handle audit fields for update operation
    else {
      canonical['updated_at'] = now;
      canonical['updated_by'] = uid;
      
      // Preserve original creation data
      if (data.containsKey('created_at')) {
        canonical['created_at'] = data['created_at'];
      } else if (data.containsKey('createdAt')) {
        canonical['created_at'] = data['createdAt'];
      }
      
      if (data.containsKey('created_by')) {
        canonical['created_by'] = data['created_by'];
      } else if (data.containsKey('createdBy')) {
        canonical['created_by'] = data['createdBy'];
      }
    }

    return canonical;
  }

  // Create training log
  Future<String> createTrainingLog(TrainingLog trainingLog) async {
    try {
      final teamId = trainingLog.teamId;
      
      // Convert to canonical format with audit fields
      final data = _toCanonical(trainingLog.toJson(), teamId: teamId);
      
      final ref = await _db
          .collection('teams')
          .doc(teamId)
          .collection(_collection)
          .add(data);
      return ref.id;
    } catch (e) {
      throw Exception('Failed to create training log: $e');
    }
  }

  // Get training log by ID
  Future<TrainingLog?> getTrainingLog(String id) async {
    try {
      final snap = await _db
          .collectionGroup(_collection)
          .where(FieldPath.documentId, isEqualTo: id)
          .get();
      if (snap.docs.isEmpty) return null;
      final doc = snap.docs.first;
      final data = doc.data();
      data['id'] = doc.id;
      return TrainingLog.fromJson(data);
    } catch (e) {
      throw Exception('Failed to get training log: $e');
    }
  }

  // Update training log
  Future<void> updateTrainingLog(String id, TrainingLog trainingLog) async {
    try {
      // Convert to canonical format with audit fields
      final data = _toCanonical(trainingLog.toJson(), teamId: trainingLog.teamId);
      
      await _db
          .collection('teams')
          .doc(trainingLog.teamId)
          .collection(_collection)
          .doc(id)
          .set(data, SetOptions(merge: true));
    } catch (e) {
      throw Exception('Failed to update training log: $e');
    }
  }

  // Delete training log
  Future<void> deleteTrainingLog(String id) async {
    try {
      // Locate doc by id via collectionGroup to find team path
      final snap = await _db
          .collectionGroup(_collection)
          .where(FieldPath.documentId, isEqualTo: id)
          .get();
      if (snap.docs.isEmpty) return;
      final doc = snap.docs.first;
      final teamId = doc.data()['team_id'] ?? doc.data()['teamId'];
      await _db.collection('teams').doc(teamId).collection(_collection).doc(id).delete();
    } catch (e) {
      throw Exception('Failed to delete training log: $e');
    }
  }

  // Get training logs by program - REFACTORED TO STREAM
  Stream<List<TrainingLog>> getProgramTrainingLogs(String programId) {
    return _db
        .collectionGroup(_collection)
        .where('program_id', isEqualTo: programId)
        .snapshots()
        .map((snapshot) => snapshot.docs.map((doc) {
          Map<String, dynamic> data = doc.data();
          data['id'] = doc.id;
          return TrainingLog.fromJson(data);
        }).toList());
  }

  // Get training logs by athlete - REFACTORED TO STREAM
  Stream<List<TrainingLog>> getAthleteTrainingLogs(String athleteId) {
    return _db
        .collectionGroup(_collection)
        .where('athlete_id', isEqualTo: athleteId)
        .snapshots()
        .map((snapshot) => snapshot.docs.map((doc) {
          Map<String, dynamic> data = doc.data();
          data['id'] = doc.id;
          return TrainingLog.fromJson(data);
        }).toList());
  }

  // Get training logs by team - REFACTORED TO STREAM
  Stream<List<TrainingLog>> getTeamTrainingLogs(String teamId) {
    return _db
        .collection('teams')
        .doc(teamId)
        .collection(_collection)
        .snapshots()
        .map((snapshot) => snapshot.docs.map((doc) {
          Map<String, dynamic> data = doc.data();
          data['id'] = doc.id;
          return TrainingLog.fromJson(data);
        }).toList());
  }

  // Get training logs by week (date range) - REFACTORED TO STREAM
  Stream<List<TrainingLog>> getWeekTrainingLogs(DateTime startDate, DateTime endDate) {
    return _db
        .collectionGroup(_collection)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) {
              Map<String, dynamic> data = doc.data();
              data['id'] = doc.id;
              return TrainingLog.fromJson(data);
            })
            .where((log) => 
              log.date.toDate().isAfter(startDate.subtract(const Duration(days: 1))) &&
              log.date.toDate().isBefore(endDate.add(const Duration(days: 1)))
            )
            .toList());
  }

  // Get training logs by date range for specific athlete - REFACTORED TO STREAM
  Stream<List<TrainingLog>> getAthleteTrainingLogsByDateRange(
    String athleteId, 
    DateTime startDate, 
    DateTime endDate
  ) {
    return _db
        .collectionGroup(_collection)
        .where('athlete_id', isEqualTo: athleteId)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) {
              Map<String, dynamic> data = doc.data();
              data['id'] = doc.id;
              return TrainingLog.fromJson(data);
            })
            .where((log) => 
              log.date.toDate().isAfter(startDate.subtract(const Duration(days: 1))) &&
              log.date.toDate().isBefore(endDate.add(const Duration(days: 1)))
            )
            .toList());
  }

  // Stream training logs for real-time updates
  Stream<List<TrainingLog>> streamProgramTrainingLogs(String programId) {
    return _db
        .collectionGroup(_collection)
        .where('program_id', isEqualTo: programId)
        .snapshots()
        .map((snapshot) => snapshot.docs.map((doc) {
          Map<String, dynamic> data = doc.data();
          data['id'] = doc.id;
          return TrainingLog.fromJson(data);
        }).toList());
  }

  // Stream athlete training logs for real-time updates
  Stream<List<TrainingLog>> streamAthleteTrainingLogs(String athleteId) {
    return _db
        .collectionGroup(_collection)
        .where('athlete_id', isEqualTo: athleteId)
        .snapshots()
        .map((snapshot) => snapshot.docs.map((doc) {
          Map<String, dynamic> data = doc.data();
          data['id'] = doc.id;
          return TrainingLog.fromJson(data);
        }).toList());
  }
}