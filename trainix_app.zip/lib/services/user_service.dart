import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:trainix_app/models/user_profile.dart';
import 'package:trainix_app/services/firestore_service.dart';
import 'package:trainix_app/services/encryption_service.dart';

class UserService {
  final FirestoreService _firestoreService;
  final EncryptionService _encryptionService =
      EncryptionService(); // Add instance
  final _db = FirebaseFirestore.instance;
  final _auth = FirebaseAuth.instance;

  UserService(this._firestoreService);

  /// Memastikan profil pengguna ada di Firestore dengan field snake_case
  /// Jika sudah ada, akan di-merge dengan data yang baru
  Future<bool> ensureUserProfile({bool merge = true}) async {
    try {
      final User? currentUser = _auth.currentUser;
      if (currentUser == null) {
        debugPrint('[FS][user.ensure] currentUser null');
        return false;
      }

      final String uid = currentUser.uid;
      final now = FieldValue.serverTimestamp();
      
      // Periksa apakah dokumen sudah ada
      final docSnapshot = await _db.collection('users').doc(uid).get();
      
      if (!docSnapshot.exists) {
        // Buat profil baru dengan semua field yang diperlukan
        final Map<String, dynamic> newUserData = {
          'id': uid,
          'name': currentUser.displayName ?? 'User',
          'email': currentUser.email ?? '',
          'photo_url': currentUser.photoURL,
          'created_at': now,
          'updated_at': now,
          'created_by': uid,
          'updated_by': uid,
          'is_active': true,
          'last_login_at': now,
          // Tambahkan field yang mungkin dibutuhkan oleh aplikasi
          'username': currentUser.email?.split('@')[0] ?? '',
          'is_email_verified': currentUser.emailVerified,
        };
        
        debugPrint('[FS][user.ensure] User profile tidak ditemukan, membuat baru untuk $uid');
        try {
          await _db.collection('users').doc(uid).set(newUserData);
          debugPrint('[FS][user.ensure] Berhasil membuat profil pengguna baru untuk $uid');
        } catch (e) {
          debugPrint('[FS][user.ensure] Error saat membuat profil baru: $e');
          // Coba lagi dengan set yang lebih sederhana jika ada masalah izin
          try {
            await _db.collection('users').doc(uid).set({
              'id': uid,
              'name': currentUser.displayName ?? 'User',
              'email': currentUser.email ?? '',
              'created_at': now,
            });
            debugPrint('[FS][user.ensure] Berhasil membuat profil minimal untuk $uid');
          } catch (e2) {
            debugPrint('[FS][user.ensure] Error kedua saat membuat profil: $e2');
            return false;
          }
        }
      } else {
        // Update data yang sudah ada
        final Map<String, dynamic> updateData = {
          'updated_at': now,
          'updated_by': uid,
          'last_login_at': now,
        };
        
        // Tambahkan field yang mungkin belum ada di profil lama
        if (currentUser.displayName != null && currentUser.displayName!.isNotEmpty) {
          updateData['name'] = currentUser.displayName;
        }
        
        if (currentUser.email != null && currentUser.email!.isNotEmpty) {
          updateData['email'] = currentUser.email;
        }
        
        if (currentUser.photoURL != null) {
          updateData['photo_url'] = currentUser.photoURL;
        }
        
        if (!docSnapshot.data()!.containsKey('is_active')) {
          updateData['is_active'] = true;
        }
        
        debugPrint('[FS][user.ensure] Memperbarui profil pengguna yang sudah ada untuk $uid');
        try {
          await _db.collection('users').doc(uid).set(
                updateData,
                SetOptions(merge: true),
              );
          debugPrint('[FS][user.ensure] Berhasil memperbarui profil pengguna untuk $uid');
        } catch (e) {
          debugPrint('[FS][user.ensure] Error saat memperbarui profil: $e');
          return false;
        }
      }
          
      // Verifikasi dokumen telah dibuat
      try {
        final verifySnapshot = await _db.collection('users').doc(uid).get();
        if (!verifySnapshot.exists) {
          debugPrint('[UserService] PERINGATAN: Gagal membuat profil pengguna setelah percobaan');
          return false;
        } else {
          debugPrint('[UserService] Profil pengguna berhasil dibuat/diperbarui untuk $uid');
          return true;
        }
      } catch (e) {
        debugPrint('[UserService] Error saat verifikasi profil: $e');
        // Asumsikan berhasil jika tidak bisa memverifikasi karena masalah izin
        return true;
      }
    } catch (e) {
      debugPrint('[UserService] ensureUserProfile error: $e');
      return false;
    }
  }

  Future<void> updateFCMToken(String uid, String token) async {
    try {
      await _db.collection('users').doc(uid).update({
        'fcmToken': token,
        'fcmUpdatedAt': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      // Jika dokumen user belum ada, buat dengan merge agar tidak mengganggu struktur terenkripsi nanti
      await _db
          .collection('users')
          .doc(uid)
          .set({
            'fcmToken': token,
            'fcmUpdatedAt': FieldValue.serverTimestamp(),
          }, SetOptions(merge: true));
    }
  }

  Future<UserProfile?> getUserProfile(String uid) async {
    try {
      final doc = await _firestoreService.getDocument('users', uid);
      if (doc != null) {
        final decryptedData = _encryptionService.decryptUserProfile(doc);
        if (decryptedData != null) {
          return UserProfile.fromJson({
            'uid': uid,
            ...decryptedData,
          });
        }
      }
      return null;
    } catch (e) {
      print('Error getting user profile: $e');
      return null;
    }
  }

  Future<bool> updateUserProfile(UserProfile profile) async {
    try {
      final encryptedData =
          _encryptionService.encryptUserProfile(profile.toJson());

      if (encryptedData != null) {
        // Gunakan set agar dokumen dibuat jika belum ada
        await _firestoreService.setDocument('users', profile.uid, encryptedData);
        return true;
      }
      return false;
    } catch (e) {
      print('Error updating user profile: $e');
      return false;
    }
  }

  Future<List<UserProfile>> searchUsers(String query) async {
    try {
      // Simple search implementation
      final docs = await _firestoreService.getCollection('users');
      List<UserProfile> users = [];

      for (var doc in docs) {
        final decryptedData = _encryptionService
            .decryptUserProfile(doc.data() as Map<String, dynamic>);
        if (decryptedData != null) {
          final profile = UserProfile.fromJson({
            'uid': doc.id,
            ...decryptedData,
          });

          if (profile.name.toLowerCase().contains(query.toLowerCase()) ||
              profile.email.toLowerCase().contains(query.toLowerCase())) {
            users.add(profile);
          }
        }
      }

      return users;
    } catch (e) {
      print('Error searching users: $e');
      return [];
    }
  }

  Future<List<UserProfile>> getUsersByIds(List<String> userIds) async {
    try {
      List<UserProfile> users = [];

      for (String uid in userIds) {
        final doc = await _firestoreService.getDocument('users', uid);
        if (doc != null) {
          final decryptedData = _encryptionService.decryptUserProfile(doc);
          if (decryptedData != null) {
            users.add(UserProfile.fromJson({
              'uid': uid,
              ...decryptedData,
            }));
          }
        }
      }

      return users;
    } catch (e) {
      print('Error getting users by IDs: $e');
      return [];
    }
  }
}
