import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/program.dart';
import 'firestore_service.dart';

class ProgramService {
  final FirestoreService _firestoreService;
  final FirebaseFirestore _db;
  final FirebaseAuth _auth;

  // Constructor with optional FirestoreService
  ProgramService([FirestoreService? firestoreService]) 
    : _firestoreService = firestoreService ?? FirestoreService(),
      _db = FirebaseFirestore.instance,
      _auth = FirebaseAuth.instance;

  // Helper: normalize incoming Map to canonical snake_case fields
  Map<String, dynamic> _toCanonical(Map<String, dynamic> data, {String? teamId}) {
    final currentUser = _auth.currentUser;
    final uid = currentUser?.uid ?? '';
    final now = FieldValue.serverTimestamp();
    
    final canonical = <String, dynamic>{
      'name': data['name'],
      'team_id': data['team_id'] ?? data['teamId'] ?? teamId,
      'week_anchor': data['week_anchor'] ?? data['weekAnchor'],
      'template': data['template'],
      'categories': data['categories'],
      'target_days': data['target_days'] ?? data['targetDays'],
    };

    // Handle audit fields for create operation
    if (!data.containsKey('created_at') && !data.containsKey('createdAt')) {
      canonical['created_at'] = now;
      canonical['created_by'] = uid;
      canonical['updated_at'] = now;
      canonical['updated_by'] = uid;
    } 
    // Handle audit fields for update operation
    else {
      canonical['updated_at'] = now;
      canonical['updated_by'] = uid;
      
      // Preserve original creation data
      if (data.containsKey('created_at')) {
        canonical['created_at'] = data['created_at'];
      } else if (data.containsKey('createdAt')) {
        canonical['created_at'] = data['createdAt'];
      }
      
      if (data.containsKey('created_by')) {
        canonical['created_by'] = data['created_by'];
      } else if (data.containsKey('createdBy')) {
        canonical['created_by'] = data['createdBy'];
      }
    }

    return canonical;
  }

  // Unified getProgram method - handles both single and team-scoped queries
  Future<Program?> getProgram(String programId, [String? teamId]) async {
    try {
      print('Getting program: $programId');
      
      if (teamId != null) {
        // Team-scoped query for compatibility
        final doc = await _db.collection('teams').doc(teamId).collection('programs').doc(programId).get();
        return doc.exists ? Program.fromFirestore(doc) : null;
      } else {
        // Direct program query
        final doc = await _firestoreService.getDocument('programs', programId);
        if (doc != null) {
          return Program.fromJson({'id': programId, ...doc});
        }
        return null;
      }
    } catch (e) {
      print('Error getting program: $e');
      return null;
    }
  }

  Future<List<Program>> fetchPrograms(String teamId) async {
    final qs = await _db.collection('teams').doc(teamId).collection('programs').get();
    return qs.docs.map((d) => Program.fromFirestore(d)).toList();
  }

  Stream<List<Program>> getTeamPrograms(String teamId) {
    return _db
        .collection('teams')
        .doc(teamId)
        .collection('programs')
        .orderBy('week_anchor')
        .snapshots()
        .map((snap) => snap.docs.map((d) => Program.fromFirestore(d)).toList());
  }

  Stream<List<Program>> getProgramsByWeek(String teamId, Timestamp weekStart) {
    return _db
        .collection('teams')
        .doc(teamId)
        .collection('programs')
        .where('week_anchor', isEqualTo: weekStart)
        .snapshots()
        .map((snap) => snap.docs.map((d) => Program.fromFirestore(d)).toList());
  }

  // Add getPrograms method with named parameters
  Future<List<Program>> getPrograms({
    required String userId,
    required bool isCoach,
  }) async {
    try {
      if (isCoach) {
        // Coach can see all programs for their teams
        return await _db
            .collection('programs')
            .where('coachId', isEqualTo: userId)
            .get()
            .then((snap) => snap.docs.map((d) => Program.fromFirestore(d)).toList());
      } else {
        // Athletes see programs assigned to them
        return await _db
            .collection('programs')
            .where('athleteIds', arrayContains: userId)
            .get()
            .then((snap) => snap.docs.map((d) => Program.fromFirestore(d)).toList());
      }
    } catch (e) {
      print('Error getting programs: $e');
      return [];
    }
  }

  // Fix createProgram to return String?
  Future<String?> createProgram(Program program) async {
    try {
      print('Creating program: ${program.name}');
      
      // Convert to canonical format with audit fields
      final data = _toCanonical(program.toMap(), teamId: program.teamId);
      
      final docRef = await _db
          .collection('teams')
          .doc(program.teamId)
          .collection('programs')
          .add(data);
      return docRef.id;
    } catch (e) {
      print('Error creating program: $e');
      return null;
    }
  }

  Future<bool> updateProgram(String programId, Map<String, dynamic> data) async {
    try {
      print('Updating program: $programId');
      // Note: Requires teamId in data
      final teamId = (data['team_id'] ?? data['teamId']) as String?;
      if (teamId == null || teamId.isEmpty) {
        throw Exception('teamId is required to update program');
      }
      
      // Convert to canonical format with audit fields
      final canonicalData = _toCanonical(data, teamId: teamId);
      
      await _db
          .collection('teams')
          .doc(teamId)
          .collection('programs')
          .doc(programId)
          .set(canonicalData, SetOptions(merge: true));
      return true;
    } catch (e) {
      print('Error updating program: $e');
      return false;
    }
  }

  Future<bool> deleteProgram(String programId) async {
    try {
      print('Deleting program: $programId');
      // Locate via collectionGroup to find team path
      final snap = await _db
          .collectionGroup('programs')
          .where(FieldPath.documentId, isEqualTo: programId)
          .get();
      if (snap.docs.isEmpty) return false;
      final doc = snap.docs.first;
      final teamId = doc.data()['team_id'] ?? doc.data()['teamId'];
      await _db.collection('teams').doc(teamId).collection('programs').doc(programId).delete();
      return true;
    } catch (e) {
      print('Error deleting program: $e');
      return false;
    }
  }

  bool isSameWeek(DateTime date1, DateTime date2) {
    final startOfWeek1 = date1.subtract(Duration(days: date1.weekday - 1));
    final startOfWeek2 = date2.subtract(Duration(days: date2.weekday - 1));
    return startOfWeek1.year == startOfWeek2.year &&
           startOfWeek1.month == startOfWeek2.month &&
           startOfWeek1.day == startOfWeek2.day;
  }
}