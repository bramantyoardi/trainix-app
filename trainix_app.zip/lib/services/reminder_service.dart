import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:trainix_app/models/reminder.dart';

class ReminderService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final String _teamsCollection = 'teams';
  final String _remindersSubcollection = 'reminders';

  // Helper: normalize incoming Map to canonical snake_case fields
  Map<String, dynamic> _toCanonical(Map<String, dynamic> data, {String? teamId}) {
    final canonical = <String, dynamic>{
      'title': data['title'],
      'description': data['description'],
      // Accept multiple field names for backward-compat
      'date_time': data['date_time'] ?? data['dateTime'] ?? data['scheduledAt'],
      'target_date': data['target_date'] ?? data['targetDate'],
      'team_id': data['team_id'] ?? data['teamId'] ?? teamId,
      'athlete_id': data['athlete_id'] ?? data['athleteId'],
      'status': data['status'],
      'is_completed': data['is_completed'] ?? data['isCompleted'],
      'created_by': data['created_by'] ?? data['createdBy'],
      'updated_by': data['updated_by'] ?? data['updatedBy'],
      'created_at': data['created_at'] ?? data['createdAt'],
      'updated_at': data['updated_at'] ?? data['updatedAt'],
    };

    // Remove nulls to avoid writing null fields unintentionally
    canonical.removeWhere((key, value) => value == null);
    return canonical;
  }

  // Get single reminder within a team
  Future<Reminder?> getReminder({required String teamId, required String reminderId}) async {
    try {
      final doc = await _db
          .collection(_teamsCollection)
          .doc(teamId)
          .collection(_remindersSubcollection)
          .doc(reminderId)
          .get();
      if (!doc.exists) return null;
      final data = doc.data()!;
      data['id'] = doc.id;
      // Ensure team_id present for model
      data['team_id'] = data['team_id'] ?? teamId;
      return Reminder.fromJson(data);
    } catch (e) {
      print('Error getting reminder: $e');
      return null;
    }
  }

  // Create a new reminder in a team
  Future<String?> createReminder(Map<String, dynamic> data, {String? teamId}) async {
    try {
      // Validate teamId
      final String? resolvedTeamId = data['team_id'] ?? data['teamId'] ?? teamId;
      if (resolvedTeamId == null || resolvedTeamId.isEmpty) {
        throw Exception('ID Tim tidak boleh kosong. Silakan pilih tim terlebih dahulu.');
      }

      // Normalize data to canonical format
      final reminderData = _toCanonical(data, teamId: resolvedTeamId);

      // Ensure required fields
      if (reminderData['title'] == null || reminderData['title'].isEmpty) {
        throw ArgumentError('Title is required');
      }

      // Set metadata if not provided
      final now = Timestamp.now();
      final String? userId = FirebaseAuth.instance.currentUser?.uid;
      
      reminderData['created_at'] ??= now;
      reminderData['updated_at'] = now;
      reminderData['created_by'] ??= userId;
      reminderData['updated_by'] = userId;
      reminderData['is_completed'] ??= false;
      reminderData['status'] ??= 'pending';

      // Convert DateTime to Timestamp if needed
      if (reminderData['date_time'] is DateTime) {
        reminderData['date_time'] = Timestamp.fromDate(reminderData['date_time']);
      }
      if (reminderData['target_date'] is DateTime) {
        reminderData['target_date'] = Timestamp.fromDate(reminderData['target_date']);
      }

      // Save to Firestore
      final docRef = await _db
          .collection(_teamsCollection)
          .doc(resolvedTeamId)
          .collection(_remindersSubcollection)
          .add(reminderData);
      
      debugPrint('[FS][reminder.create] Created reminder ${docRef.id} in team $resolvedTeamId');
      return docRef.id;
    } catch (e) {
      if (e is ArgumentError) {
        debugPrint('[FS][reminder.create] Validation error: ${e.message}');
        rethrow;
      }
      debugPrint('[FS][reminder.create] Error creating reminder: $e');
      return null;
    }
  }

  // Update reminder status
  Future<bool> updateReminderStatus({
    required String teamId,
    required String reminderId,
    required String status,
  }) async {
    try {
      await _db
          .collection(_teamsCollection)
          .doc(teamId)
          .collection(_remindersSubcollection)
          .doc(reminderId)
          .update({
        'status': status,
        'is_completed': status == 'completed',
        'updated_at': Timestamp.now(),
        'updated_by': FirebaseAuth.instance.currentUser?.uid,
      });
      debugPrint('[FS][reminder.updateStatus] Updated reminder $reminderId status to $status');
      return true;
    } catch (e) {
      debugPrint('[FS][reminder.updateStatus] Error: $e');
      return false;
    }
  }

  // Update an existing reminder
  Future<bool> updateReminder({
    required String teamId,
    required String reminderId,
    required Map<String, dynamic> data,
  }) async {
    try {
      if (teamId.isEmpty) {
        throw ArgumentError('Team ID is required');
      }
      if (reminderId.isEmpty) {
        throw ArgumentError('Reminder ID is required');
      }

      // Normalize data to canonical format
      final reminderData = _toCanonical(data, teamId: teamId);

      // Set metadata
      final now = Timestamp.now();
      final String? userId = FirebaseAuth.instance.currentUser?.uid;
      reminderData['updated_at'] = now;
      reminderData['updated_by'] = userId;

      // Convert DateTime to Timestamp if needed
      if (reminderData['date_time'] is DateTime) {
        reminderData['date_time'] = Timestamp.fromDate(reminderData['date_time']);
      }
      if (reminderData['target_date'] is DateTime) {
        reminderData['target_date'] = Timestamp.fromDate(reminderData['target_date']);
      }

      await _db
          .collection(_teamsCollection)
          .doc(teamId)
          .collection(_remindersSubcollection)
          .doc(reminderId)
          .update(reminderData);
      
      debugPrint('[FS][reminder.update] Updated reminder $reminderId in team $teamId');
      return true;
    } catch (e) {
      String errorMessage;
      if (e is FirebaseException) {
        errorMessage = 'Firebase Error [${e.code}]: ${e.message}';
        debugPrint('[FS][reminder.update] $errorMessage');
      } else {
        errorMessage = 'Error updating reminder: $e';
        debugPrint('[FS][reminder.update] $errorMessage');
      }
      return false;
    }
  }

  // Delete reminder
  Future<bool> deleteReminder({required String teamId, required String reminderId}) async {
    try {
      await _db
          .collection(_teamsCollection)
          .doc(teamId)
          .collection(_remindersSubcollection)
          .doc(reminderId)
          .delete();
      return true;
    } catch (e) {
      String errorMessage;
      if (e is FirebaseException) {
        errorMessage = 'Firebase Error [${e.code}]: ${e.message}';
        print('Debug ReminderService: $errorMessage');
      } else {
        errorMessage = 'Error deleting reminder: $e';
        print('Debug ReminderService: $errorMessage');
      }
      throw errorMessage;
    }
  }

  // Stream reminders for a team
  Stream<List<Reminder>> getTeamReminders(String teamId) {
    return _db
        .collection(_teamsCollection)
        .doc(teamId)
        .collection(_remindersSubcollection)
        .snapshots()
        .map((snapshot) => snapshot.docs.map((doc) {
              final data = doc.data();
              data['id'] = doc.id;
              data['team_id'] = data['team_id'] ?? teamId;
              return Reminder.fromJson(data);
            }).toList());
  }

  // Stream reminders for an athlete across all teams (collectionGroup)
  Stream<List<Reminder>> getAthleteReminders(String athleteId) {
    return _db
        .collectionGroup(_remindersSubcollection)
        .where('athlete_id', isEqualTo: athleteId)
        .snapshots()
        .map((snapshot) => snapshot.docs.map((doc) {
              final data = doc.data();
              data['id'] = doc.id;
              // Extract teamId from reference path
              final segments = doc.reference.path.split('/');
              final teamId = segments.length >= 3 ? segments[1] : null;
              if (teamId != null) {
                data['team_id'] = data['team_id'] ?? teamId;
              }
              return Reminder.fromJson(data);
            }).toList());
  }

  // Stream reminders by status for an athlete across all teams
  Stream<List<Reminder>> getRemindersByStatus(String athleteId, String status) {
    return _db
        .collectionGroup(_remindersSubcollection)
        .where('athlete_id', isEqualTo: athleteId)
        .where('status', isEqualTo: status)
        .snapshots()
        .map((snapshot) => snapshot.docs.map((doc) {
              final data = doc.data();
              data['id'] = doc.id;
              // Extract teamId from reference path
              final segments = doc.reference.path.split('/');
              final teamId = segments.length >= 3 ? segments[1] : null;
              if (teamId != null) {
                data['team_id'] = data['team_id'] ?? teamId;
              }
              return Reminder.fromJson(data);
            }).toList());
  }
}