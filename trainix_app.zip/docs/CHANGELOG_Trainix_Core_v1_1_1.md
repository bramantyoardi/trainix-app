# CHANGELOG — Trainix Core v1.1.1

Release date: 2025-10-19

This release formalizes the reminders data model and enforces the canonical Firestore paths and field casing throughout services, providers, and UI.

## Summary
- Canonical path: `teams/{teamId}/reminders/{reminderId}` is now the only supported path for reminders.
- Canonical fields (snake_case) enforced in service writes/updates: `title`, `description`, `date_time`, `target_date`, `team_id`, `athlete_id`, `status`, `is_completed`, `created_at/by`, `updated_at/by`.
- Backward compatibility: reads accept dual-casing (`dateTime`, `scheduledAt`, `targetDate`, `teamId`, `athleteId`, `isCompleted`, `createdAt`, `updatedAt`) and normalize to snake_case internally.
- Provider & UI updated: all reminder operations require `teamId` and call the refactored service APIs.
- CollectionGroup queries added for athlete-scoped reminder streams.
- Documentation version bumped to v1.1.1.

## Code Changes
- services/reminder_service.dart
  - Refactored to use `teams/{teamId}/reminders` subcollections for create, update, delete, and streaming.
  - Added `_toCanonical` helper to normalize field names and ensure audit fields.
  - Implemented `getTeamReminders`, `getAthleteReminders`, and `getRemindersByStatus` using collectionGroup.
  - Fixed named parameter usage when calling `_toCanonical`.
- providers/reminder_provider.dart
  - Method signatures updated to include `teamId` for all write operations.
  - Local state updates aligned with new service results.
- ui/components/reminders_section.dart
  - Now passes `teamId` to `updateReminderStatus` when marking as completed.
- ui/training/reminder_list_page.dart
  - Now passes `teamId` to `updateReminderStatus`.
- ui/training/create_reminder_page.dart
  - Now passes `teamId` to `createReminder` and `updateReminder`.

## Documentation Updates
- docs/firestore_schema.md → header updated to v1.1.1; section 2.d `reminders` already reflects canonical path and fields.
- docs/firestore_rules_summary.yaml → version updated to v1.1.1; notes reaffirm athlete_id targeting and dual-casing acceptance during transitions.
- docs/trainix_core_rules.yaml → version updated to v1.1.1.

## Migration Notes
- If any legacy reminders exist outside `teams/{teamId}/reminders`, migrate them into the team subcollection and set `team_id` accordingly.
- Ensure UI passes the correct `teamId` context into providers for all operations.
- Verify Firestore indexes:
  - teams/training_logs: `athlete_id`, `date`
  - teams/leaderboards: `team_id`, `week`
  - teams/members: `status`, `role`, `user_id`
  - security_logs: `userId`, `timestamp`
  - Optional: consider index on `teams/{teamId}/reminders` for `athlete_id` & `status` if queries become slow.

## Testing Checklist
- Static analysis: `dart analyze lib --no-fatal-warnings` should pass.
- Manual smoke test (dev):
  - Create reminder as Coach for a selected athlete; confirm document saved under `teams/{teamId}/reminders` with snake_case fields.
  - Create reminder as Athlete for self; confirm fields and access.
  - Mark reminder as completed through both Reminders section and Reminder list page.
  - Verify athlete-scoped streams list reminders across teams.

## Notes
- No direct visual/UI design changes are introduced; functionality is scoped to correct team paths.
- Future work: lint clean-up (reduce info/warnings), optional index additions for reminders.