# Trainix Casing & Path Cheatsheet (v1.2.0 Final)

> Region: **asia-southeast1**
> Firebase Project: **trainix-app-mobile**

---

## **A. Kebijakan (Policy Final)**

| Jenis                                                                                                                    | Konvensi                                               | Catatan                                               |
| ------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------ | ----------------------------------------------------- |
| **Core Collections** (`teams/*` dan subkoleksi)                                                                          | `snake_case`                                           | Termasuk path dan field; audit wajib.                 |
| **Utility / Root Collections** (`users`, `training_intensities`, `notifications`, `team_notifications`, `security_logs`) | `camelCase`                                            | Data global atau user-scope; audit disarankan.        |
| **Audit Fields**                                                                                                         | `created_at`, `created_by`, `updated_at`, `updated_by` | Diisi otomatis (serverTimestamp, current UID).        |
| **Leaderboards**                                                                                                         | Subkoleksi `teams`                                     | Ditulis oleh Cloud Function, tidak bisa diubah klien. |

---

## **B. Struktur Koleksi Kanonik**

```
/users/{userId}                          (camelCase fields)
teams/{teamId}                            (snake_case fields)
  ├─ members/{uid}                        (snake_case, docId = UID)
  ├─ programs/{programId}                 (snake_case)
  ├─ trainingLogs/{logId}                 (snake_case)
  ├─ reminders/{reminderId}               (snake_case)
  └─ leaderboards/{leaderboardId}         (snake_case, server-managed)
/training_intensities/{intensityId}      (camelCase fields)
/notifications/{notificationId}          (camelCase fields)
/team_notifications/{notificationId}     (camelCase fields)
/security_logs/{logId}                   (camelCase fields)
```

---

## **C. Contoh Field Penting**

* **Core (snake_case)**: `team_id`, `athlete_id`, `week_anchor`, `target_days`, `is_active`, `is_owner`, `status`, `date_time`, `total`
* **Audit (snake_case)**: `created_at == updated_at` (saat create), `created_by == updated_by == request.auth.uid`
* **Utility (camelCase)**: `teamId`, `athleteId`, `recordedAt`, `userId`, `readAt`

---

## **D. Flutter Layer (camelCase di kode)**

* Model / variabel: `teamId`, `athleteId`, `createdAt`, `isOwner`
* `fromMap()`: membaca `snake_case`
* `toMap()`: menulis `snake_case` (khusus core)
* Audit diset di **service layer**, bukan dari UI.

---

## **E. Query & Index (Firestore)**

| Koleksi               | Bidang Indeks                   | Keterangan                                    |
| --------------------- | ------------------------------- | --------------------------------------------- |
| `teams/training_logs` | `team_id`, `athlete_id`, `date` | Untuk leaderboard mingguan dan progres atlet. |
| `teams/leaderboards`  | `team_id`, `week`               | Untuk query multi-tim (collectionGroup).      |
| `teams/members`       | `status`, `role`, `user_id`     | Untuk filtering anggota tim.                  |
| `security_logs`       | `userId`, `timestamp`           | Untuk logging keamanan.                       |

**Query contoh:**

```dart
FirebaseFirestore.instance
  .collectionGroup('leaderboards')
  .where('team_id', whereIn: activeTeamIds)
  .orderBy('week', descending: true);
```

---

## **F. DO / DON'T**

| ✅ DO                                                              | ❌ DON'T                                      |
| ----------------------------------------------------------------- | -------------------------------------------- |
| Gunakan `snake_case` untuk semua path dan field di bawah `teams/` | Menulis field `camelCase` di core collection |
| Gunakan mapping otomatis di service (`_toCanonical`)              | Mengirim audit field dari UI                 |
| Audit diisi oleh serverTimestamp + current UID                    | Mengubah `created_*` saat update             |
| Pastikan semua write memuat `team_id`                             | Menyimpan leaderboard di root koleksi        |

---

## **G. Audit Tier (Wajib vs Disarankan)**

| Tier                     | Koleksi                                                                                 | Audit                                                  | Casing       |
| ------------------------ | --------------------------------------------------------------------------------------- | ------------------------------------------------------ | ------------ |
| **A (Wajib Audit)**      | `teams`, `members`, `programs`, `trainingLogs`, `reminders`, `leaderboards`             | `created_at`, `updated_at`, `created_by`, `updated_by` | `snake_case` |
| **B (Disarankan Audit)** | `training_intensities`, `notifications`, `team_notifications`, `users`, `security_logs` | Minimal `createdAt/By`, `updatedAt/By` jika ada edit   | `camelCase`  |

---

## **H. Fix Scope & QA Definition of Done**

* Tambahkan helper rules `auditCreateOK()` dan `auditUpdateOK()`.
* Setiap create → `created_by/updated_by = currentUid`, `created_at/updated_at = serverTimestamp()`.
* Setiap update → `updated_by = currentUid`, `updated_at = serverTimestamp()`.
* Cloud Function menulis audit otomatis pada `members` & `leaderboards`.
* Tidak ada field `camelCase` di dokumen core.
* Leaderboard tidak bisa diubah klien; diperbarui otomatis dari `trainingLogs`.
* Validasi QA: semua operasi CRUD lolos rules, tidak ada error audit, dan struktur path sesuai schema.
