# Trainix Casing & Path Cheatsheet (v1.3.0 Final)

> Region: **asia-southeast1**
> Firebase Project: **trainix-app-mobile**
> **New in v1.3.0**: Join Policy Management & Pending Members System

---

## **A. Kebijakan (Policy Final)**

| Jenis                                                                                                                    | Konvensi                                               | Catatan                                               |
| ------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------ | ----------------------------------------------------- |
| **Core Collections** (`teams/*` dan subkoleksi)                                                                          | `snake_case`                                           | Termasuk path dan field; audit wajib.                 |
| **Utility / Root Collections** (`users`, `training_intensities`, `notifications`, `team_notifications`, `security_logs`) | `camelCase`                                            | Data global atau user-scope; audit disarankan.        |
| **Audit Fields**                                                                                                         | `created_at`, `created_by`, `updated_at`, `updated_by` | Diisi otomatis (serverTimestamp, current UID).        |
| **Leaderboards**                                                                                                         | Subkoleksi `teams`                                     | Ditulis oleh Cloud Function, tidak bisa diubah klien. |
| **Join Policy** *(v1.3.0)*                                                                                              | `open`, `ask_to_join`, `closed`                        | Hanya Owner yang dapat mengubah kebijakan.            |

---

## **B. Struktur Koleksi Kanonik**

```
/users/{userId}                          (camelCase fields)
teams/{teamId}                            (snake_case fields)
  ├─ members/{uid}                        (snake_case, docId = UID)
  ├─ pending_members/{uid}                (snake_case, NEW in v1.3.0)
  ├─ programs/{programId}                 (snake_case)
  ├─ trainingLogs/{logId}                 (snake_case)
  ├─ reminders/{reminderId}               (snake_case)
  └─ leaderboards/{leaderboardId}         (snake_case, server-managed)
/training_intensities/{intensityId}      (camelCase fields)
/notifications/{notificationId}          (camelCase fields)
/team_notifications/{notificationId}     (camelCase fields)
/security_logs/{logId}                   (camelCase fields)
```

---

## **C. Contoh Field Penting**

### Core Fields (snake_case)
* **Existing**: `team_id`, `athlete_id`, `week_anchor`, `target_days`, `is_active`, `is_owner`, `status`, `date_time`, `total`
* **New in v1.3.0**: `join_policy`, `member_count`, `pending_count`, `coach_count`, `requested_at`, `reviewed_by`, `reviewed_at`

### Audit Fields (snake_case)
* `created_at == updated_at` (saat create), `created_by == updated_by == request.auth.uid`

### Utility Fields (camelCase)
* `teamId`, `athleteId`, `recordedAt`, `userId`, `readAt`

---

## **D. Join Policy Management (v1.3.0)**

### Join Policy Types
| Policy        | Behavior                                    | Access Control        |
| ------------- | ------------------------------------------- | --------------------- |
| `open`        | Anggota dapat bergabung langsung            | Public join           |
| `ask_to_join` | Memerlukan persetujuan Coach/Owner          | Approval required     |
| `closed`      | Hanya undangan dari Coach/Owner             | Invitation only       |

### Pending Members Workflow
```
1. User requests to join (ask_to_join policy)
2. Document created in pending_members/{uid}
3. Coach/Owner reviews request
4. Approval → move to members/, delete from pending_members/
5. Rejection → delete from pending_members/
```

### Count Synchronization
* `member_count`: Auto-sync dari jumlah members aktif
* `pending_count`: Auto-sync dari jumlah pending members
* `coach_count`: Auto-sync dari jumlah members dengan role Coach

---

## **E. Flutter Layer (camelCase di kode)**

### Model Properties
* **Existing**: `teamId`, `athleteId`, `createdAt`, `isOwner`
* **New in v1.3.0**: `joinPolicy`, `memberCount`, `pendingCount`, `coachCount`, `requestedAt`, `reviewedBy`

### Mapping Rules
* `fromMap()`: membaca `snake_case` dari Firestore
* `toMap()`: menulis `snake_case` (khusus core collections)
* Audit diset di **service layer**, bukan dari UI
* Join policy validation di service layer

---

## **F. Query & Index (Firestore)**

| Koleksi                  | Bidang Indeks                   | Keterangan                                    |
| ------------------------ | ------------------------------- | --------------------------------------------- |
| `teams/training_logs`    | `team_id`, `athlete_id`, `date` | Untuk leaderboard mingguan dan progres atlet. |
| `teams/leaderboards`     | `team_id`, `week`               | Untuk query multi-tim (collectionGroup).      |
| `teams/members`          | `status`, `role`, `user_id`     | Untuk filtering anggota tim.                  |
| `teams/pending_members`  | `status`, `requested_at`        | **NEW**: Untuk pending member management.     |
| `security_logs`          | `userId`, `timestamp`           | Untuk logging keamanan.                       |

**Query contoh (v1.3.0):**

```dart
// Get pending members for approval
FirebaseFirestore.instance
  .collection('teams/$teamId/pending_members')
  .where('status', isEqualTo: 'pending')
  .orderBy('requested_at', descending: true);

// Check team join policy
FirebaseFirestore.instance
  .collection('teams')
  .where('join_policy', isEqualTo: 'open')
  .where('member_count', isLessThan: maxMembers);
```

---

## **G. DO / DON'T (Updated for v1.3.0)**

| ✅ DO                                                              | ❌ DON'T                                      |
| ----------------------------------------------------------------- | -------------------------------------------- |
| Gunakan `snake_case` untuk semua path dan field di bawah `teams/` | Menulis field `camelCase` di core collection |
| Gunakan mapping otomatis di service (`_toCanonical`)              | Mengirim audit field dari UI                 |
| Audit diisi oleh serverTimestamp + current UID                    | Mengubah `created_*` saat update             |
| Pastikan semua write memuat `team_id`                             | Menyimpan leaderboard di root koleksi        |
| **Validate join policy sebelum member operations**                | **Mengubah join_policy tanpa Owner role**    |
| **Sync count fields saat membership changes**                     | **Manual update count fields dari UI**       |

---

## **H. Audit Tier (Wajib vs Disarankan)**

| Tier                     | Koleksi                                                                                 | Audit                                                  | Casing       |
| ------------------------ | --------------------------------------------------------------------------------------- | ------------------------------------------------------ | ------------ |
| **A (Wajib Audit)**      | `teams`, `members`, `pending_members`, `programs`, `trainingLogs`, `reminders`, `leaderboards` | `created_at`, `updated_at`, `created_by`, `updated_by` | `snake_case` |
| **B (Disarankan Audit)** | `training_intensities`, `notifications`, `team_notifications`, `users`, `security_logs` | Minimal `createdAt/By`, `updatedAt/By` jika ada edit   | `camelCase`  |

---

## **I. Join Policy Security Rules (v1.3.0)**

### Permission Matrix
| Operation                    | Role Required    | Additional Validation                |
| ---------------------------- | ---------------- | ------------------------------------ |
| Change `join_policy`         | Owner only       | Cannot change if pending members exist |
| Approve pending member       | Coach or Owner   | Must validate pending status         |
| Join team (open policy)     | Any user         | Auto-add to members                  |
| Request to join (ask policy) | Any user         | Create pending_members document      |
| Invite member (closed)       | Coach or Owner   | Direct add to members                |

### Validation Rules
```javascript
// Only owner can change join policy
allow update: if isOwner(resource.data.team_id) && 
              onlyChanging(['join_policy']) && 
              request.auth != null;

// Pending members can be created by requester
allow create: if request.auth.uid == resource.id && 
              validPendingMemberData();

// Coach/Owner can approve/reject pending members
allow update, delete: if (isCoach(resource.data.team_id) || 
                         isOwner(resource.data.team_id)) && 
                        request.auth != null;
```

---

## **J. Fix Scope & QA Definition of Done (v1.3.0)**

### Core Requirements
* Tambahkan helper rules `auditCreateOK()` dan `auditUpdateOK()`
* Setiap create → `created_by/updated_by = currentUid`, `created_at/updated_at = serverTimestamp()`
* Setiap update → `updated_by = currentUid`, `updated_at = serverTimestamp()`
* Cloud Function menulis audit otomatis pada `members` & `leaderboards`

### v1.3.0 Specific
* **Join Policy Validation**: Semua join operations respect policy settings
* **Count Synchronization**: Member counts update automatically on membership changes
* **Pending Member Workflow**: Complete approval/rejection flow works correctly
* **Owner Protection**: Only owners can change join policy
* **Security Rules**: All new rules pass validation and testing

### QA Checklist
* [ ] Semua operasi CRUD lolos rules tanpa error audit
* [ ] Struktur path sesuai schema v1.3.0
* [ ] Join policy enforcement works correctly
* [ ] Pending member approval/rejection flow complete
* [ ] Count fields sync automatically
* [ ] Owner-only join policy changes enforced
* [ ] No field `camelCase` di dokumen core
* [ ] Leaderboard tidak bisa diubah klien; diperbarui otomatis dari `trainingLogs`