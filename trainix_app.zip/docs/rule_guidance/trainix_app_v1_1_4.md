# Trainix App Spec v1.1.4 (Android-only)

Dokumen ini adalah penerus yang konsisten dari v1.1.3 dengan fokus platform Android saja. Semua kebijakan inti dipertahankan dan disinkronisasi dengan v1.1.3 sebagai source of truth.

## Product Brief
- Nama Aplikasi: Trainix
- Platform: Android (Flutter)
- Target User: Atlet & Pelatih
- Masalah: Pencatatan intensitas manual rawan error dan tidak real-time
- Solusi: Manajemen latihan berbasis Firestore (multi-team, role, intensitas dengan penanda inputBy)
- Status: Sinkronisasi spesifikasi dengan v1.1.3 + perapian minor

---

## Prinsip Kebijakan Akses (Android-only)
- TrainingLog/Intensitas: HANYA dapat dibuat dan diedit oleh Coach. Atlet read-only.
- Program Latihan: HANYA Coach yang dapat membuat/mengedit. Atlet read-only.
- Reminder: Atlet boleh membuat reminder pribadi; Coach boleh membuat reminder untuk atlet.

---

## Roadmap & Backlog (disinkronkan dari v1.1.3)
| ID | Fitur | Status |
|----|-------|--------|
| 1 | Auth (Register/Login, Reset, Email Verification) | ✅ Done |
| 2 | Manajemen Pengguna (User Profile) | ✅ Done |
| 3 | Teams (Create/Join/Leave, Role Management, Approval) | ✅ Done |
| 4 | Program Latihan (CRUD by Coach) | ✅ Done |
| 5 | Intensitas (HRR; input oleh Coach) | ✅ Done |
| 6 | Leaderboard | ✅ Done |
| 7 | Reminder | ✅ Done |
| 8 | Multi-role per Team | ✅ Done |
| 17 | Route Management (main.dart) | ⚠️ In Progress (perlu QA rute eksplisit) |

Catatan: Item “Athlete Self Input” dihapus. Kebijakan tetap Coach-only untuk TrainingLog.

---

## Skema Firestore (mengikuti v1.1.3 sebagai source of truth)
### Koleksi: users
{
  id: string,
  fullName: string,
  email: string (unik),
  role: "Athlete" | "Coach",
  profileImageUrl?: string,
  bio?: string,
  joinDate: Timestamp,
  preferences: Map<string, dynamic>
}

### Koleksi: user_team_roles
{
  id: string,
  userId: string,
  teamId: string,
  role: "Athlete" | "Coach",
  joinedAt: Timestamp,
  isActive: boolean
}

### Koleksi: training_programs
{
  id: string,
  teamId: string,
  date: Timestamp,
  description: string,
  categories: List,
  createdBy: string
}

### Koleksi: training_intensities
{
  id: string,
  programId: string,
  athleteId: string,
  score: double,
  date: Timestamp,
  inputBy: string // CoachID yang melakukan input
}

### Koleksi: reminders
{
  id: string,
  title: string,
  description: string,
  targetDate: Timestamp,
  isCompleted: boolean,
  createdBy: string,
  assignedTo?: string
}

### Koleksi: leaderboard_entries
{
  id: string,
  athleteId: string,
  teamId: string,
  totalScore: double,
  rank: int,
  lastUpdated: Timestamp
}

### Aturan Kebijakan Data (Penegasan)
- Field `inputBy` tetap menandai identitas Coach yang menginput intensitas.
- Atlet tidak memiliki izin membuat/mengedit `training_intensities`. Akses mereka read-only.
- Rules Firestore harus memastikan role “Coach” untuk operasi write pada program dan intensitas.

---

## Tech Stack & Struktur Direktori (dirapikan)
- Tech: Flutter, Firebase Auth & Firestore, Provider
- Struktur Direktori:
  - `lib/models/` (User, Team, Program, Intensity, Reminder, Leaderboard)
  - `lib/services/` (auth_service.dart, firestore_service.dart, etc.)
  - `lib/providers/` (auth_provider.dart, team_provider.dart, program_provider.dart, intensity_provider.dart, reminder_provider.dart, user_provider.dart)
  - `lib/ui/` (authentication/, components/, team_management/, training/, user_management/)
  - `lib/extensions/` (utility extensions)
  - `lib/utils/` (HRRCalculator, helpers)

### Catatan Provider
- AuthProvider: mengelola status login, email verification, logout.
- TeamProvider: CRUD tim, join via kode, approval anggota.
- ProgramProvider: CRUD program harian/mingguan oleh Coach.
- IntensityProvider: input dan perhitungan intensitas (HRR) oleh Coach.
- ReminderProvider: reminder pribadi (Athlete) dan untuk atlet (Coach).
- UserProvider: profil pengguna dan preferensi.

---

## Rute Eksplisit di main.dart (spesifikasi)
Daftar rute yang disarankan untuk konsistensi navigasi (sesuaikan dengan kelas aktual di project):
- `/` → AuthWrapper (redirect ke `/home` jika sudah login)
- `/login` → LoginRegisterCombinedPage
- `/home` → HomePage
- `/teams` → TeamsPage
- `/team/create` → CreateTeamPage
- `/team/join` → JoinTeamPage
- `/training/dashboard` → TrainingDashboardPage
- `/training/program` → ProgramPage
- `/leaderboard` → LeaderboardPage
- `/reminder` → ReminderListPage
- `/reminder/create` → ReminderCreatePage
- `/profile` → ProfilePage
- `/profile/edit` → EditProfilePage
- `/change-password` → ChangePasswordPage
- `/settings` → SettingsPage

Guard Navigasi:
- AuthWrapper memastikan user terautentikasi. Jika belum → `/login`.
- Akses halaman CRUD Program/Intensitas dibatasi role `Coach`.

---

## Konfigurasi DEV Android & Emulator
- Gunakan flag `USE_EMULATOR` ketika pengembangan lokal Android.
- Host untuk emulator Android: `10.0.2.2` (bukan `localhost`).
- Port default: Firestore `8080`, Auth `9099`.
- Contoh (Windows PowerShell):
  - `setx USE_EMULATOR true`
  - Jalankan app: `flutter run -d emulator-5554`
- Implementasi saat ini mengaktifkan emulator pada mode debug. Flag `USE_EMULATOR` direkomendasikan sebagai kontrol eksplisit di masa depan.

---

## QA Checklist (Android-only)
- Auth: Login/Register/Reset, verifikasi email, logout kembali ke Auth.
- Teams: Create/Join via kode, approval/reject oleh Coach Owner.
- Program: CRUD oleh Coach; Atlet view-only.
- Intensitas: Input HRR oleh Coach; Atlet view-only; field `inputBy` wajib terisi (CoachID).
- Leaderboard: menampilkan skor konsistensi, intensitas, dan total; badge eligible.
- Reminder: Atlet dapat membuat/menandai selesai; Coach dapat membuat untuk atlet.
- Navigasi: Route di main.dart sesuai spesifikasi dan guard berjalan.
- Firestore Rules: write program/intensitas hanya untuk role Coach.
- DEV Android: koneksi emulator ke `10.0.2.2`; tidak ada instruksi ke `localhost`.
- Tidak ada rujukan Web/Chrome dalam dokumen.

---

## Catatan Sinkronisasi v1.3 → v1.4
- Platform dipersempit ke Android saja.
- Kebijakan `TrainingLog` ditegaskan Coach-only; menghapus opsi Athlete self input.
- Menambahkan penegasan penamaan field `inputBy` (CoachID).
- Merapikan struktur direktori dan daftar provider.
- Menambahkan rute eksplisit yang perlu di-hardening di main.dart.
- Menambahkan QA checklist untuk validasi konsistensi.

Dokumen ini tidak menambah fitur baru di luar cakupan v1.1.3. Fokus pada sinkronisasi dan perapian spesifikasi.
