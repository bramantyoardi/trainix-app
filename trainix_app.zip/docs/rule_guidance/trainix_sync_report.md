# Trainix FULL RECOVERY & QA — Android-only v1.1.4 (Sinkron v1.1.3)

Tanggal: 2025-10-16

Ringkasan eksekusi untuk normalisasi lingkungan pengembangan Trainix ke Android-only dengan fokus keamanan data, konsistensi rute, konfigurasi emulator, dan kebersihan repository.

## 1) Scope & Target
- Platform: Android-only (AVD)
- Emulator Firebase: Firestore (8080), Auth (9099)
- Host Android: 10.0.2.2 (akses dari AVD ke host). Untuk proses test di host, fallback: 127.0.0.1
- Spesifikasi: v1.1.4 (disinkronkan dgn v1.1.3), tanpa cakupan Web/Chrome

## 2) Basic Validation (Lingkungan)
- Flutter & Dart: diverifikasi via `flutter doctor -v`
- Android SDK: 34.0.0; Android emulator aktif: `emulator-5554`
- VS Code & Android Studio terdeteksi
- Catatan: sebagian lisensi Android belum diterima (perlu `flutter doctor --android-licenses`)

## 3) Firestore Security Rules
- File: `firestore.rules` (baru/ditulis ulang)
- Prinsip akses:
  - Coach-only write untuk `teams/{teamId}/programs` dan `teams/{teamId}/trainingLogs`
  - Athlete hanya read untuk `trainingLogs` miliknya; tidak bisa write
  - Leaderboards: anggota tim dapat read; write coach-only
  - Reminders: athlete dapat membuat/ubah punyanya sendiri; coach dapat membuat untuk anggota tim
- Helper checks disiapkan di rules (role, status, membership) sesuai struktur koleksi bertingkat `teams/{teamId}`

## 4) Emulator & Konfigurasi
- `firebase.json` ditambahkan:
  - firestore: port 8080, host 127.0.0.1, rules: `firestore.rules`
  - auth: port 9099, host 127.0.0.1
- `lib/main.dart`:
  - Flag `USE_EMULATOR` (dart-define) untuk mengaktifkan koneksi emulator hanya saat DEV
  - Fungsi `_setupFirebaseForAndroidDev()` mengarah ke host `10.0.2.2`
- `.vscode/launch.json`:
  - Nama konfigurasi: “Run Trainix on Android Emulator”
  - Menambahkan `toolArgs`: `--dart-define USE_EMULATOR=true`

## 5) Route Audit & Sinkronisasi
File: `lib/main.dart`
- Rute inti (sesuai dokumen v1.1.4; Android-only):
  - `/home` → MainScreen
  - `/teams` → TeamsPage
  - `/team/create` → CreateTeamPage
  - `/team/join` → JoinTeamPage
  - `/training/dashboard` → TrainingDashboardPage
  - `/training/program` → ProgramListPage
  - `/leaderboard` → LeaderboardPage
  - `/reminder` → ReminderListPage
  - `/reminder/create` → CreateReminderPage
  - `/profile` → ProfilePage
  - `/profile/edit` → EditProfilePage
  - `/change-password` → ChangePasswordPage
  - `/settings` → SettingsPage
  - Auth routes: `/login`, `/register`, `/forgot-password`, `/email-verification` (args aman default)
- Pembersihan: menghapus impor/route halaman legal yang tidak tersedia

## 6) Code Sweep
- Menghapus referensi Web/Chrome dari jalur eksekusi Android DEV (tidak menyentuh folder `web/` bawaan)
- Mengganti penggunaan `localhost` menjadi host yang benar:
  - `main.dart` → 10.0.2.2 untuk AVD
  - Test (host) → 127.0.0.1 dengan fallback logika

## 7) Test & QA
- Uji emulator disiapkan di `test/firestore_rules_test.dart` (8 skenario):
  1) Coach write `programs` (✅ di rules)
  2) Athlete write `programs` (❌ di rules)
  3) Coach write `trainingLogs` (✅ di rules)
  4) Athlete write `trainingLogs` (❌ di rules)
  5) Athlete read own `trainingLogs`, deny others (✅/❌)
  6) Team member read `leaderboards` (✅)
  7) Non-member read `leaderboards` (❌)
  8) Coach write `leaderboards` (✅), athlete write denied (❌)
  9) Athlete create own `reminders` + deny edit milik orang lain (✅/❌)
  10) Coach create reminder untuk anggota tim (✅)
- Konfigurasi host pada test:
  - `Platform.isAndroid ? '10.0.2.2' : '127.0.0.1'`
- Hasil aktual eksekusi lokal:
  - `firebase emulators:start --only firestore,auth` → gagal dengan pesan “No emulators to start, run firebase init emulators to get started.”
  - `flutter test test/firestore_rules_test.dart` → gagal di tahap `Firebase.initializeApp()` dengan `PlatformException(channel-error, Unable to establish connection on channel.)`
    - Penyebab: lingkungan `flutter test` tidak memiliki registrasi plugin native sehingga inisialisasi core via platform channel gagal.

### Rekomendasi Perbaikan Test (Akan buat task lanjutan)
1) Buat `.firebaserc` dan lakukan `firebase init emulators` untuk menetapkan project default (mis. `trainix-dev`):
   ```json
   {
     "projects": { "default": "trainix-dev" }
   }
   ```
2) Jalankan ulang emulators: `firebase emulators:start --only firestore,auth`
3) Ubah pendekatan testing menjadi Integration Test di Android emulator agar plugin Firebase berfungsi penuh:
   - Tambahkan dev-dependency `integration_test`
   - Buat file `integration_test/firestore_rules_e2e_test.dart` yang memanggil skenario di atas
   - Jalankan: `flutter test integration_test` atau `flutter drive -d emulator-5554 --target integration_test/firestore_rules_e2e_test.dart`

Catatan: Mock-based testing (firebase_auth_mocks / fake_cloud_firestore) tidak cocok untuk memvalidasi Security Rules karena tidak berbicara ke emulator.

## 8) Patch Log (Perubahan File)
- Ditambahkan/diubah:
  - `firestore.rules` → implementasi Coach-only + rules untuk reminders & leaderboards
  - `firebase.json` → konfigurasi emulator Firestore/Auth + rules path
  - `lib/main.dart` → flag `USE_EMULATOR`, fungsi `_setupFirebaseForAndroidDev`, sinkronisasi rute, pengamanan argumen email-verification
  - `.vscode/launch.json` → rename & `--dart-define USE_EMULATOR=true`
  - `test/firestore_rules_test.dart` → update host fallback 10.0.2.2/127.0.0.1, penyesuaian path koleksi (`teams/*`), dan penambahan skenario uji (leaderboards & reminders, athlete read-own)

## 9) Status Todo
- Basic Validation: ✅ selesai
- Create/overwrite `firestore.rules`: ✅ selesai
- Update & tambah ≥6 uji emulator: ✅ selesai (8 skenario)
- Audit & sinkronisasi route `lib/main.dart`: ✅ selesai
- Jalankan emulators & `flutter test` + laporkan: ❌ (terblokir konfigurasi emulator + batasan platform channel di unit test)
- Code sweep Web/Chrome/localhost + konfigurasi emulator di `main.dart`: ✅ selesai
- `.vscode/launch.json` default emulator + dart-define: ✅ selesai
- Laporan akhir (`rule_guidance/trainix_sync_report.md`): ✅ dibuat

## 10) Next Steps (Actionable)
1) Inisialisasi proyek Firebase lokal:
   - `firebase login`
   - `firebase init emulators` (pilih Firestore & Auth, set ports 8080/9099, default project `trainix-dev`)
   - Buat `.firebaserc` dengan project default
2) Jalankan emulators dan uji Integration Test di Android emulator:
   - `firebase emulators:start --only firestore,auth`
   - `flutter test integration_test` atau `flutter drive -d emulator-5554`
3) Terima lisensi Android yang belum lengkap: `flutter doctor --android-licenses`
4) Opsional: tambah skrip `run_android.ps1` untuk menjalankan app dengan dart-define emulator secara konsisten.

## 11) Catatan Keamanan
- Rules sudah menegakkan Coach-only write untuk data sensitif (programs, trainingLogs)
- Read athlete dibatasi ke data miliknya sendiri
- Logic membership & role diverifikasi via subkoleksi `teams/{teamId}/members/{uid}`

Selesai.

---

Ringkasan Hasil Pengujian Firestore Rules (Integration Test — Android Emulator)

- Programs: Coach write ✅, Athlete write ❌ → Status: ❌ (emulator belum berjalan)
- TrainingLogs: Coach write ✅, Athlete write ❌ → Status: ❌ (emulator belum berjalan)
- TrainingLogs: Athlete read own ✅, read others ❌ → Status: ❌ (emulator belum berjalan)
- Leaderboards: Member read ✅, non-member read ❌; Coach write ✅, Athlete write ❌ → Status: ❌ (emulator belum berjalan)
- Reminders: Athlete create/edit own ✅, edit others ❌; Coach create for athlete ✅ → Status: ❌ (emulator belum berjalan)

Catatan: Setelah `firebase init emulators` dan `firebase emulators:start` berhasil dijalankan, skrip `scripts/run_e2e_android.ps1` dapat digunakan untuk mengeksekusi pengujian di AVD dan memperbarui status menjadi ✅/❌ sesuai hasil aktual.

---

12) MODE: DEMO EMULATOR AUTO-SETUP — Trainix (Android-only)

- File yang ditimpa/ditulis ulang (root):
  - `.firebaserc`:
    {
      "projects": { "default": "demo-trainix" }
    }
  - `firebase.json`:
    {
      "firestore": { "rules": "firestore.rules" },
      "emulators": {
        "firestore": { "port": 8080, "host": "127.0.0.1" },
        "auth":      { "port": 9099, "host": "127.0.0.1" }
      }
    }

- Validasi `firestore.rules`:
  - Tersedia dan menegakkan kebijakan terbaru: Android-only, Coach-only write pada koleksi sensitif (`teams/{teamId}/programs`, `teams/{teamId}/trainingLogs`), athlete hanya read miliknya, leaderboards read anggota tim, reminders: athlete boleh membuat/ubah miliknya; coach boleh membuat untuk anggota.

- Start Emulator (tanpa login, demo project):
  - Perintah dieksekusi: `firebase emulators:start --config firebase.json --only firestore,auth --project demo-trainix`
  - Hasil: ❌ Gagal
  - Log ringkas:
    - "No emulators to start, run firebase init emulators to get started."
    - Emulator melakukan shutdown otomatis.
  - Catatan port/host yang dikonfigurasi: Firestore 8080 @ 127.0.0.1, Auth 9099 @ 127.0.0.1

- Status AVD & Tes Integrasi Android:
  - AVD terdeteksi aktif: `emulator-5554`
  - Perintah uji: `flutter drive -d emulator-5554 --driver test_driver/integration_test.dart --target integration_test/firestore_rules_e2e_test.dart`
  - Hasil: ❌ Gagal
  - Log ringkas: `FirebaseAuthException(network-request-failed)` — indikasi host emulator belum aktif sehingga koneksi ke `10.0.2.2:9099/8080` tidak tersedia.

- Versi Tools:
  - firebase-tools: 14.20.0
  - Flutter: 3.16.2
  - Dart: 3.2.2

- Kebijakan & Konfirmasi Konfigurasi:
  - Koneksi AVD → Host menggunakan `10.0.2.2` (bukan `localhost` dari app/Chrome/Web). Kode telah menggunakan `10.0.2.2` untuk Android.
  - Manifest cleartext HTTP hanya aktif di build debug: `android/app/src/debug/AndroidManifest.xml` (bukan release/production).
  - Dilarang menulis ke project produksi dalam proses pengujian ini; hanya mode demo lokal dengan emulator Firestore/Auth pada port 8080/9099.

- Rangkuman Status Skenario (✅/❌ — sementara):
  - Programs: ❌
  - TrainingLogs: ❌
  - Leaderboards: ❌
  - Reminders: ❌
  - Alasan umum: Emulator Firebase belum berhasil berjalan di host.

- Instruksi Lanjutan (non-interaktif, sesuai kebijakan):
  1) Coba jalankan kembali emulator dengan memastikan konfigurasi terbaca:
     - `firebase emulators:start --config firebase.json --only firestore,auth --project demo-trainix`
  2) Jika masih muncul pesan "No emulators to start", lakukan `firebase init emulators` (interaktif) pada mesin Anda untuk mengikat emulator Firestore/Auth ke proyek `demo-trainix`, lalu ulangi langkah (1).
  3) Setelah emulator aktif, jalankan kembali tes integrasi Android di AVD:
     - `flutter drive -d emulator-5554 --driver test_driver/integration_test.dart --target integration_test/firestore_rules_e2e_test.dart`
  4) Kirim sinyal/konfirmasi agar laporan ini diperbarui menjadi ✅/❌ per skenario beserta log emulator (Firestore/Auth) dan versi tools.