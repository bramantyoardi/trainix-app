# Panduan Eksekusi Batch Trainix v1.2.0 (Bahasa Indonesia)

> Region: **asia-southeast1**
> Firebase Project: **trainix-app-mobile**
> Mode Eksekusi: **Batch A & C = Max Mode**, sisanya normal.

---

## ⚙️ Batch A — Penetapan Kanonik & Sinkronisasi Dokumen (**Gunakan Max Mode**)

### 🎯 Tujuan

Menetapkan versi final dokumen Trainix Core v1.2.0 dan memastikan semua file dokumentasi sinkron dengan skema Firestore kanonik (snake_case / camelCase) serta audit field policy.

### 🧩 Langkah Eksekusi (untuk Trae AI)

```
Kamu sedang memperbarui proyek Trainix ke versi kanonik v1.2.0.
Fokus: sinkronisasi penuh dokumentasi inti (rules, schema, changelog, cheatsheet).

1️⃣ Struktur file di /src/docs/ :
 ├── trainix_core_rules.yaml
 ├── firestore_schema.md
 ├── firestore_rules_summary.yaml
 ├── CHANGELOG_Trainix_Core_v1_1_1.md
 ├── README_TRAINIX_CORE.md
 └── trainix_casing_cheatsheet_v1.2.0_final.md (unggah file markdown & pdf)

2️⃣ Pastikan seluruh file memiliki versi v1.2.0 di header, dan:
   - Format dan isi sesuai hasil final Trainix Core v1.2.0
   - Skema Firestore kanonik (core: snake_case, utilitas: camelCase)
   - Audit field policy tercantum dalam schema & rules_summary
   - trainix_core_rules.yaml berisi prinsip roles, HRR, leaderboard, environment aktif (trainix-app-mobile)

3️⃣ Tambahkan tautan cheatsheet di README_TRAINIX_CORE.md:
   📄 Trainix Casing & Path Cheatsheet (v1.2.0)
   Lihat di: /src/docs/trainix_casing_cheatsheet_v1.2.0_final.md

4️⃣ Validasi lintas dokumen:
   - File dependencies sesuai (schema → rules_summary → firestore.rules)
   - YAML & Markdown valid tanpa error
   - Semua heading (##, ###) konsisten

5️⃣ Commit & push:
   git add src/docs
   git commit -m "docs: sinkronisasi Trainix Core v1.2.0 + cheatsheet final"
   git push
```

---

## 🧱 Batch B — Penyesuaian Firestore Rules dan Indeks

### 🎯 Tujuan

Menyamakan aturan keamanan Firestore dengan struktur v1.2.0 serta menambahkan audit helper function.

### 🧩 Langkah Eksekusi

```
1️⃣ Tambahkan helper:
function auditCreateOK(d) {
  return d.created_by == request.auth.uid &&
         d.updated_by == request.auth.uid &&
         d.created_at == d.updated_at;
}
function auditUpdateOK(before, after) {
  return after.updated_by == request.auth.uid &&
         after.created_by == before.created_by &&
         after.created_at == before.created_at &&
         after.updated_at == request.time;
}

2️⃣ Terapkan pada semua core collection:
 - teams/{teamId}
 - teams/{teamId}/members/{memberId}
 - teams/{teamId}/programs/{programId}
 - teams/{teamId}/trainingLogs/{logId}
 - teams/{teamId}/reminders/{reminderId}
 - teams/{teamId}/leaderboards/{leaderboardId}

3️⃣ Tambahkan indeks:
 - teams/training_logs: team_id, athlete_id, date
 - teams/leaderboards: team_id, week
 - teams/members: status, role, user_id
 - security_logs: userId, timestamp

4️⃣ Atur timezone & policy:
 - timezone = "Asia/Makassar"
 - owner_representation = "Coach + is_owner:true"

5️⃣ Deploy:
 firebase deploy --only firestore:rules,firestore:indexes --project trainix-app-mobile
```

---

## 🔄 Batch C — Refaktor Layanan Flutter (**Gunakan Max Mode**)

### 🎯 Tujuan

Menormalkan semua layanan & provider agar hanya menulis field **snake_case** dan audit otomatis server-side.

### 🧩 Langkah Eksekusi

```
1️⃣ Service yang diperbarui:
 - ReminderService
 - ProgramService
 - TrainingLogService
 - TeamService

2️⃣ Tambahkan helper _toCanonical(Map<String, dynamic> data):
   - Konversi camelCase → snake_case
   - create(): created_by/updated_by=currentUser.uid, created_at/updated_at=FieldValue.serverTimestamp() (harus sama)
   - update(): updated_by=currentUser.uid, updated_at=FieldValue.serverTimestamp(), jangan ubah created_*
   - pastikan semua menulis team_id

3️⃣ Provider Layer:
   - Semua method CRUD memanggil service canonical
   - Hapus pengiriman audit dari UI
   - Tambahkan param teamId eksplisit di reminder/program/trainingLog

4️⃣ UI Layer:
   - Hanya kirim field bisnis (title, description, target_date, dll)
   - Reminder & TrainingLog otomatis menyertakan teamId & athleteId

5️⃣ Leaderboard:
   - Pastikan read-only (hapus manual write)
   - CF aggregator menulis audit otomatis

6️⃣ Pengujian:
   - Buat reminder Coach & Athlete
   - Buat training log oleh Coach
   - Pastikan Firestore berisi audit field lengkap
   - Tidak ada camelCase di dokumen core
```

---

## 🔐 Batch D — Cloud Functions & Trigger Audit

### 🎯 Tujuan

Menambahkan audit field lengkap untuk setiap dokumen yang ditulis Cloud Functions.

### 🧩 Langkah Eksekusi

```
1️⃣ File: functions/index.js
   Region: asia-southeast1

2️⃣ Fungsi: onTeamCreatedCreateOwnerMembership
   - created_by/updated_by = context.auth.uid
   - created_at/updated_at = FieldValue.serverTimestamp()
   - Role = Coach, Status = approved, is_active = true, is_owner = true

3️⃣ Fungsi: onTrainingLogWriteAggregateLeaderboard
   - Tambahkan audit lengkap ke leaderboard:
        team_id, athlete_id, week, scores, total,
        created_by, updated_by, created_at, updated_at
   - Gunakan FieldValue.serverTimestamp()
   - created_by boleh 'system' jika otomatis

4️⃣ Deploy:
   firebase deploy --only functions:onTeamCreatedCreateOwnerMembership,onTrainingLogWriteAggregateLeaderboard --project trainix-app-mobile
```

---

## ✅ Batch E — Validasi & QA Akhir

### 🎯 Tujuan

Memastikan semua struktur, audit field, rules, dan CF berjalan sempurna sesuai standar Trainix v1.2.0.

### 🧩 Langkah Validasi QA

```
1️⃣ Struktur Firestore:
   - Semua path sesuai: teams/{teamId}/(members|programs|trainingLogs|reminders|leaderboards)
   - Tidak ada field camelCase di core
   - Audit field lengkap di semua dokumen core

2️⃣ Rules:
   - Coach dapat create/update semua core
   - Athlete hanya dapat read
   - Leaderboard client write ditolak

3️⃣ Cloud Function:
   - Membership owner otomatis saat create team
   - Leaderboard auto-update saat trainingLogs ditambah

4️⃣ UI:
   - Reminder dapat dibuat oleh Coach & Athlete
   - TrainingLog hanya dapat dibuat Coach
   - Tidak ada error “Failed to create reminder”

5️⃣ Hasil akhir:
   Jika semua berhasil → tulis laporan “QA v1.2.0 ✅ Passed”.
   Jika gagal → tampilkan error Firestore/Rules/CF secara rinci.
```

---

## 🧭 Rangkuman Eksekusi

| Tahap | Batch | Mode         | Tujuan                             | Status       |
| ----- | ----- | ------------ | ---------------------------------- | ------------ |
| 1     | A + C | **Max Mode** | Sinkronisasi docs + refaktor besar | 🌟 Prioritas |
| 2     | B     | Normal       | Rules & Index                      | ✅            |
| 3     | D     | Normal       | Cloud Function Audit               | ✅            |
| 4     | E     | Normal       | QA Final                           | ✅            |
