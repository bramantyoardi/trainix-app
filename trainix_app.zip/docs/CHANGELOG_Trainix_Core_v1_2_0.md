# CHANGELOG — Trainix Core v1.2.0

Release date: 2025-11-15

Versi ini menetapkan standar kanonik untuk seluruh koleksi Trainix, dengan fokus pada konsistensi casing (snake_case untuk koleksi inti, camelCase untuk utilitas) dan audit field yang lengkap di seluruh dokumen.

## Ringkasan
- Kebijakan casing kanonik: `snake_case` untuk semua koleksi di bawah `teams/` (termasuk subkoleksi), `camelCase` untuk koleksi utilitas root.
- Audit field wajib untuk semua koleksi inti: `created_at`, `created_by`, `updated_at`, `updated_by`.
- Helper function untuk validasi audit: `auditCreateOK()` dan `auditUpdateOK()` di Firestore Rules.
- Refaktor service layer untuk menggunakan `_toCanonical()` yang menjamin konsistensi field dan audit.
- Leaderboard dikelola sepenuhnya oleh Cloud Function; penulisan langsung dari klien ditolak.
- Dokumentasi lengkap dalam format cheatsheet untuk referensi cepat.

## Perubahan Kode
- services/*.dart
  - Refaktor `ReminderService`, `ProgramService`, `TrainingLogService`, `TeamService` untuk menggunakan `_toCanonical()`.
  - Memastikan semua operasi create/update menyertakan audit field yang tepat.
  - Menghapus penulisan manual audit field dari UI layer.
  - Menambahkan parameter `teamId` eksplisit di semua operasi CRUD.
- providers/*.dart
  - Memperbarui method signature untuk menyertakan `teamId` di semua operasi write.
  - Memastikan state lokal selaras dengan hasil service.
- firestore.rules
  - Menambahkan helper function `auditCreateOK()` dan `auditUpdateOK()`.
  - Menerapkan validasi audit field di semua koleksi inti.
  - Menolak penulisan langsung ke leaderboard dari klien.
- functions/index.js
  - Memastikan Cloud Function menulis audit field lengkap saat membuat membership owner dan leaderboard.

## Pembaruan Dokumentasi
- docs/firestore_schema.md → header diperbarui ke v1.2.0; menegaskan kebijakan casing dan audit field.
- docs/firestore_rules_summary.yaml → versi diperbarui ke v1.2.0; menambahkan helper audit.
- docs/trainix_core_rules.yaml → versi diperbarui ke v1.2.0.
- docs/cheatsheet_v1_2_0.md → dokumen baru yang berisi ringkasan kebijakan casing dan audit.

## Catatan Migrasi
- Pastikan semua service layer menggunakan `_toCanonical()` untuk normalisasi field.
- Verifikasi bahwa semua operasi CRUD menyertakan `teamId` yang tepat.
- Pastikan UI tidak lagi mengirim audit field secara manual.
- Verifikasi indeks Firestore:
  - teams/training_logs: `team_id`, `athlete_id`, `date`
  - teams/leaderboards: `team_id`, `week`
  - teams/members: `status`, `role`, `user_id`
  - security_logs: `userId`, `timestamp`

## Checklist Pengujian
- Analisis statis: `dart analyze lib --no-fatal-warnings` harus lolos.
- Pengujian manual:
  - Buat reminder sebagai Coach untuk atlet tertentu; konfirmasi dokumen disimpan dengan field snake_case dan audit lengkap.
  - Buat training log sebagai Coach; verifikasi audit field dan casing.
  - Verifikasi bahwa leaderboard diperbarui otomatis melalui Cloud Function.
  - Pastikan semua query dan stream berfungsi dengan benar.

## Catatan
- Tidak ada perubahan visual/UI yang diperkenalkan; fungsionalitas difokuskan pada konsistensi data.
- Pekerjaan selanjutnya: pembersihan lint (mengurangi info/peringatan), penambahan indeks opsional.