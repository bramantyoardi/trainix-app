Param(
  [string]$DeviceId = "emulator-5554"
)

Write-Host "[Trainix] Menjalankan aplikasi di Android emulator: $DeviceId (Production Firebase)" -ForegroundColor Cyan
flutter pub get
flutter run -d $DeviceId