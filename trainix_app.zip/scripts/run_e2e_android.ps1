Param(
  [string]$DeviceId = "emulator-5554",
  [string]$ProjectId = "trainix-dev"
)

Write-Host "[Trainix] Menjalankan Integration Test (Android emulator)" -ForegroundColor Cyan
Write-Host "Pastikan Firebase Emulators sudah berjalan di terminal terpisah:" -ForegroundColor Yellow
Write-Host "  firebase emulators:start --only firestore,auth --project $ProjectId" -ForegroundColor Yellow

flutter drive -d $DeviceId --driver test_driver/integration_test.dart --target integration_test/firestore_rules_e2e_test.dart