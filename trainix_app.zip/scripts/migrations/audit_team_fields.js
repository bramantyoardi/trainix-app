const admin = require('firebase-admin');

function initAdmin() {
  const projectId = process.env.GOOGLE_CLOUD_PROJECT || process.env.GCLOUD_PROJECT;
  if (!admin.apps.length) {
    admin.initializeApp({ projectId });
  }
  return admin.firestore();
}

async function auditTeams() {
  const db = initAdmin();
  const targetIds = [
    '2jqFFvx2GgP48Kd9Fj6x',
    'VhONIwGSdfWiznxxYkxv',
    '0d8KA4CAgcfNIaUyxjEN',
    '5hoUmaeigDOjSn7xubZU',
    'uOQLlnFEHOfuDLVaaHLO',
    'to2NGoX8zU7a4rQdCMmq',
  ];

  console.log('[AUDIT] Checking specific team docs for legacy invite fields and team_code presence...');
  for (const id of targetIds) {
    const snap = await db.collection('teams').doc(id).get();
    if (!snap.exists) {
      console.log(`[MISS] Team ${id} not found`);
      continue;
    }
    const data = snap.data() || {};
    const hasInviteCode = 'invite_code' in data || 'inviteCode' in data;
    const teamCode = data['team_code'];
    console.log(`[TEAM ${id}] invite_code/inviteCode present? ${hasInviteCode} | team_code: ${teamCode || '(none)'}`);
  }

  console.log('[AUDIT] Sampling first 10 teams to check fields...');
  const qs = await db.collection('teams').limit(10).get();
  for (const doc of qs.docs) {
    const d = doc.data() || {};
    const hasInviteCode = 'invite_code' in d || 'inviteCode' in d;
    console.log(`[SAMPLE ${doc.id}] invite_code/inviteCode: ${hasInviteCode} | team_code: ${d['team_code'] || '(none)'}`);
  }
  console.log('[AUDIT] Done.');
}

auditTeams().catch(e => {
  console.error('[AUDIT] Error:', e);
  process.exitCode = 1;
});