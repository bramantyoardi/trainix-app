/**
 * Cleanup Legacy Fields: invite_code/inviteCode (v1_2_0)
 * - Safe, managed batch deletions to avoid DB locks
 * - Logs operations to migration_logs with timestamp, processed count, status, and metadata
 * - Rollback-ready: each item log stores old values for restoration
 * - Pre-run validation to ensure safety conditions
 * - Supports controlled schedule via CLI args
 *
 * Usage:
 *   node scripts/migrations/cleanup_invite_code_v1_2_0.js --batchSize=50 --sleepMs=1000 --maxBatches=10
 *
 * Env:
 *   GOOGLE_APPLICATION_CREDENTIALS (recommended) or default credentials
 */

const admin = require('firebase-admin');
const { FieldValue } = require('firebase-admin/firestore');

function parseArgs() {
  const args = Object.fromEntries(
    process.argv.slice(2).map((arg) => {
      const [k, v] = arg.replace(/^--/, '').split('=');
      return [k, v ?? true];
    })
  );
  return {
    batchSize: Number(args.batchSize || 50),
    sleepMs: Number(args.sleepMs || 1000),
    maxBatches: Number(args.maxBatches || 999),
    dryRun: args.dryRun === 'true' || args.dryRun === true,
  };
}

function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

async function initAdmin() {
  if (!admin.apps.length) {
    try {
      admin.initializeApp();
      console.log('[INIT] Firebase Admin initialized');
    } catch (e) {
      console.error('[INIT] Failed to initialize Admin SDK:', e);
      process.exit(1);
    }
  }
  return admin.firestore();
}

async function preValidation(db) {
  // Check existence of docs with legacy fields
  let hasInviteCode = false;
  try {
    const q1 = await db.collection('teams').where('invite_code', '!=', null).orderBy('invite_code').limit(1).get();
    hasInviteCode = !q1.empty;
  } catch (e) {
    console.warn('[VALIDATION] invite_code check failed (may require index):', e.message);
  }
  let hasInviteCodeCamel = false;
  try {
    const q2 = await db.collection('teams').where('inviteCode', '!=', null).orderBy('inviteCode').limit(1).get();
    hasInviteCodeCamel = !q2.empty;
  } catch (e) {
    console.warn('[VALIDATION] inviteCode check failed (may require index):', e.message);
  }

  if (!hasInviteCode && !hasInviteCodeCamel) {
    console.log('[VALIDATION] No legacy invite fields found. Abort cleanup.');
    return false;
  }

  // Optional: warn if any team lacks team_code
  try {
    const missingTeamCode = await db.collection('teams').where('team_code', '==', null).limit(1).get();
    if (!missingTeamCode.empty) {
      console.warn('[VALIDATION] Found teams with missing team_code. Cleanup should be postponed until migration completes.');
      // You can choose to abort here depending on policy
    }
  } catch (e) {
    console.warn('[VALIDATION] team_code presence check failed:', e.message);
  }

  return true;
}

async function fetchBatch(db, batchSize) {
  const ids = new Set();

  try {
    const s1 = await db.collection('teams').where('invite_code', '!=', null).orderBy('invite_code').limit(batchSize).get();
    s1.docs.forEach((d) => ids.add(d.id));
  } catch (e) {
    console.warn('[FETCH] invite_code query failed:', e.message);
  }

  try {
    const s2 = await db.collection('teams').where('inviteCode', '!=', null).orderBy('inviteCode').limit(batchSize).get();
    s2.docs.forEach((d) => ids.add(d.id));
  } catch (e) {
    console.warn('[FETCH] inviteCode query failed:', e.message);
  }

  return Array.from(ids);
}

async function logSummary(db, summary) {
  const doc = {
    operation: 'cleanup_invite_code_v1_2_0',
    type: 'summary',
    timestamp: FieldValue.serverTimestamp(),
    ...summary,
  };
  await db.collection('migration_logs').add(doc);
}

async function logItem(db, batchId, teamId, oldInviteCode, oldInviteCodeCamel, status, errorMessage) {
  const doc = {
    operation: 'cleanup_invite_code_v1_2_0',
    type: 'item',
    batch_id: batchId,
    team_id: teamId,
    old_invite_code: oldInviteCode ?? null,
    old_inviteCode: oldInviteCodeCamel ?? null,
    status,
    error: errorMessage || null,
    timestamp: FieldValue.serverTimestamp(),
    metadata: {
      action: 'delete fields invite_code/inviteCode',
    },
  };
  await db.collection('migration_logs').add(doc);
}

async function cleanupBatch(db, batchId, ids, dryRun = false) {
  let success = 0;
  let failure = 0;

  for (const id of ids) {
    try {
      const docRef = db.collection('teams').doc(id);
      const snap = await docRef.get();
      const data = snap.data() || {};
      const oldInviteCode = data.invite_code;
      const oldInviteCodeCamel = data.inviteCode;

      if (dryRun) {
        console.log(`[DRY] Would delete invite_code fields for team ${id}`);
        await logItem(db, batchId, id, oldInviteCode, oldInviteCodeCamel, 'dry-run', null);
        success++;
        continue;
      }

      const update = {
        invite_code: FieldValue.delete(),
        inviteCode: FieldValue.delete(),
        migration_v1_2_0_invite_cleanup: true,
        updated_at: FieldValue.serverTimestamp(),
        updated_by: 'migration-script',
      };

      await docRef.update(update);
      await logItem(db, batchId, id, oldInviteCode, oldInviteCodeCamel, 'success', null);
      success++;
    } catch (e) {
      console.error(`[ERROR] Failed cleanup for team ${id}:`, e.message);
      await logItem(db, batchId, id, null, null, 'failed', e.message);
      failure++;
    }
  }

  return { success, failure };
}

(async function run() {
  const { batchSize, sleepMs, maxBatches, dryRun } = parseArgs();
  const db = await initAdmin();

  const ok = await preValidation(db);
  if (!ok) return;

  console.log(`[RUN] Starting cleanup with batchSize=${batchSize}, sleepMs=${sleepMs}, maxBatches=${maxBatches}, dryRun=${dryRun}`);

  let totalProcessed = 0;
  let totalSuccess = 0;
  let totalFailure = 0;

  for (let i = 0; i < maxBatches; i++) {
    const batchId = `cleanup_${Date.now()}_${i}`;
    const ids = await fetchBatch(db, batchSize);
    if (!ids.length) {
      console.log('[RUN] No more documents to process. Stopping.');
      break;
    }

    console.log(`[RUN] Batch ${i + 1}: processing ${ids.length} teams ...`);
    const { success, failure } = await cleanupBatch(db, batchId, ids, dryRun);
    totalProcessed += ids.length;
    totalSuccess += success;
    totalFailure += failure;

    await logSummary(db, { batch_id: batchId, processed_count: ids.length, success_count: success, failure_count: failure, status: 'completed' });

    if (i < maxBatches - 1) {
      console.log(`[RUN] Sleeping ${sleepMs}ms before next batch ...`);
      await sleep(sleepMs);
    }
  }

  await logSummary(db, { processed_count: totalProcessed, success_count: totalSuccess, failure_count: totalFailure, status: 'run_completed' });
  console.log(`[RUN] Completed. Total processed=${totalProcessed}, success=${totalSuccess}, failure=${totalFailure}`);
})();