'use strict';
/**
 * Normalize single owner per team.
 * - Iterate all teams
 * - Read members with is_owner == true
 * - Pick a single owner (heuristic: team.created_by, else earliest joined_at/date_joined)
 * - Set others to is_owner:false
 * - Write summary logs to migration_logs
 *
 * Usage (Emulator):
 *   set FIRESTORE_EMULATOR_HOST=localhost:8080 && node scripts/migrations/normalize_single_owner.js
 * Production: ensure proper credentials, run with caution.
 */

const admin = require('firebase-admin');

// Initialize Admin SDK once
try {
  admin.app();
} catch (e) {
  admin.initializeApp();
}

const db = admin.firestore();

function toTs(val) {
  if (!val) return null;
  if (val.toDate) return val;
  try { return admin.firestore.Timestamp.fromDate(new Date(val)); } catch { return null; }
}

async function chooseOwner(teamDoc, ownerCandidates) {
  const data = teamDoc.data() || {};
  const createdBy = data.created_by || data.createdBy || null;
  if (createdBy && ownerCandidates.find(c => c.id === createdBy)) {
    return createdBy;
  }
  // earliest joined_at/date_joined
  let earliest = null;
  let chosen = null;
  for (const c of ownerCandidates) {
    const d = c.data || {};
    const ts = d.joined_at || d.date_joined || d.created_at;
    const millis = ts && ts.toMillis ? ts.toMillis() : (ts ? new Date(ts).getTime() : Number.POSITIVE_INFINITY);
    if (earliest === null || millis < earliest) {
      earliest = millis;
      chosen = c.id;
    }
  }
  return chosen || (ownerCandidates.length ? ownerCandidates[0].id : null);
}

async function run() {
  console.log('[MIG] Start normalize_single_owner');
  const teamsSnap = await db.collection('teams').get();
  let processed = 0;
  let updatedMembers = 0;
  for (const teamDoc of teamsSnap.docs) {
    const teamId = teamDoc.id;
    const membersSnap = await db.collection('teams').doc(teamId).collection('members')
      .where('is_owner', '==', true)
      .get();
    const owners = membersSnap.docs.map(d => ({ id: d.id, data: d.data() }));
    if (owners.length <= 1) {
      processed++;
      continue; // already normalized
    }
    const chosenOwner = await chooseOwner(teamDoc, owners);
    const batch = db.batch();
    const demoted = [];
    for (const o of owners) {
      if (o.id === chosenOwner) continue;
      const ref = db.collection('teams').doc(teamId).collection('members').doc(o.id);
      batch.update(ref, {
        is_owner: false,
        updated_at: admin.firestore.FieldValue.serverTimestamp(),
        updated_by: 'migration:normalize_single_owner',
      });
      demoted.push(o.id);
    }
    await batch.commit();
    updatedMembers += demoted.length;
    await db.collection('migration_logs').add({
      type: 'normalize_single_owner',
      team_id: teamId,
      chosen_owner: chosenOwner,
      demoted_owners: demoted,
      count_demoted: demoted.length,
      created_at: admin.firestore.FieldValue.serverTimestamp(),
      created_by: 'migration:normalize_single_owner',
    });
    console.log(`[MIG] team=${teamId} chosen_owner=${chosenOwner} demoted=${demoted.join(',')}`);
    processed++;
  }
  console.log(`[MIG] Completed. teams=${processed}, demoted_members=${updatedMembers}`);
}

run().catch(err => {
  console.error('[MIG] Failed:', err);
  process.exit(1);
});