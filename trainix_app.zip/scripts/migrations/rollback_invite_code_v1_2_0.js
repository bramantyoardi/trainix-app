/**
 * Rollback for Cleanup Legacy Fields: invite_code/inviteCode (v1_2_0)
 * - Restores invite_code/inviteCode using per-item logs in migration_logs
 *
 * Usage:
 *   node scripts/migrations/rollback_invite_code_v1_2_0.js --batchId=<batch_id> [--dryRun=true]
 *   or rollback the whole run:
 *   node scripts/migrations/rollback_invite_code_v1_2_0.js --all=true
 */

const admin = require('firebase-admin');
const { FieldValue } = require('firebase-admin/firestore');

function parseArgs() {
  const args = Object.fromEntries(
    process.argv.slice(2).map((arg) => {
      const [k, v] = arg.replace(/^--/, '').split('=');
      return [k, v ?? true];
    })
  );
  return {
    batchId: args.batchId || null,
    all: args.all === 'true' || args.all === true,
    dryRun: args.dryRun === 'true' || args.dryRun === true,
  };
}

async function initAdmin() {
  if (!admin.apps.length) {
    try {
      admin.initializeApp();
      console.log('[INIT] Firebase Admin initialized');
    } catch (e) {
      console.error('[INIT] Failed to initialize Admin SDK:', e);
      process.exit(1);
    }
  }
  return admin.firestore();
}

async function fetchLogs(db, batchId, all) {
  let q = db.collection('migration_logs').where('operation', '==', 'cleanup_invite_code_v1_2_0').where('type', '==', 'item').where('status', '==', 'success');
  if (batchId && !all) {
    q = q.where('batch_id', '==', batchId);
  }
  const snap = await q.limit(500).get();
  return snap.docs.map((d) => ({ id: d.id, ...d.data() }));
}

async function rollbackItem(db, log, dryRun = false) {
  const teamId = log.team_id;
  const oldInviteCode = log.old_invite_code;
  const oldInviteCodeCamel = log.old_inviteCode;

  if (!teamId) return { ok: false, error: 'missing team_id in log' };

  if (dryRun) {
    console.log(`[DRY] Would restore invite fields for team ${teamId}`);
    return { ok: true };
  }

  const update = {};
  if (oldInviteCode != null) update['invite_code'] = oldInviteCode;
  if (oldInviteCodeCamel != null) update['inviteCode'] = oldInviteCodeCamel;
  update['updated_at'] = FieldValue.serverTimestamp();
  update['updated_by'] = 'rollback-script';
  update['migration_v1_2_0_invite_cleanup_rollback'] = true;

  await db.collection('teams').doc(teamId).update(update);
  return { ok: true };
}

(async function run() {
  const { batchId, all, dryRun } = parseArgs();
  const db = await initAdmin();

  if (!batchId && !all) {
    console.error('[RUN] Provide --batchId=<id> to rollback specific batch, or --all=true to rollback all.');
    process.exit(1);
  }

  const logs = await fetchLogs(db, batchId, all);
  console.log(`[RUN] Found ${logs.length} item logs to rollback`);

  let success = 0;
  let failure = 0;

  for (const log of logs) {
    try {
      const { ok, error } = await rollbackItem(db, log, dryRun);
      if (ok) success++; else { failure++; console.error('[ROLLBACK] failed:', error); }
    } catch (e) {
      failure++;
      console.error('[ROLLBACK] error:', e.message);
    }
  }

  await db.collection('migration_logs').add({
    operation: 'rollback_invite_code_v1_2_0',
    timestamp: FieldValue.serverTimestamp(),
    status: 'completed',
    batch_id: batchId || null,
    processed_count: logs.length,
    success_count: success,
    failure_count: failure,
  });

  console.log(`[RUN] Rollback completed. success=${success}, failure=${failure}`);
})();