# Cleanup Legacy Fields: invite_code/inviteCode (v1_2_0)

This folder provides safe, managed scripts to remove legacy fields `invite_code` and `inviteCode` from Firestore `teams` collection.

Components:
- cleanup_invite_code_v1_2_0.js: Performs controlled batch deletions with logging, validation, and optional dry-run.
- rollback_invite_code_v1_2_0.js: Restores deleted fields based on item logs for emergency rollback.

Prerequisites:
- Node.js 16+
- Firebase Admin credentials configured (GOOGLE_APPLICATION_CREDENTIALS or default application credentials)

Usage Examples:
1) Dry-run to verify impacted documents:
   node scripts/migrations/cleanup_invite_code_v1_2_0.js --dryRun=true --batchSize=50 --sleepMs=1000 --maxBatches=2

2) Execute controlled cleanup in batches (recommended during low-traffic windows):
   node scripts/migrations/cleanup_invite_code_v1_2_0.js --batchSize=50 --sleepMs=1000 --maxBatches=20

3) Rollback a specific batch:
   node scripts/migrations/rollback_invite_code_v1_2_0.js --batchId=<batch_id>

4) Rollback entire run:
   node scripts/migrations/rollback_invite_code_v1_2_0.js --all=true

What gets logged:
- migration_logs (collection) receives both summary and per-item entries:
  - Summary: operation, timestamp, processed_count, success_count, failure_count, status, batch_id
  - Item: operation, timestamp, team_id, old_invite_code, old_inviteCode, status, error, batch_id, metadata

Operational Recommendations:
- Schedule batches during off-peak hours (e.g., 01:00 local time)
- Use small batchSize (e.g., 25–50) with sleepMs (e.g., 750–1500ms) to avoid lock/contention
- Always run dry-run first and review migration_logs
- Ensure team_code migration completed and rules updated before cleanup
- After completion, consider removing invite-related UI/flows and run E2E tests