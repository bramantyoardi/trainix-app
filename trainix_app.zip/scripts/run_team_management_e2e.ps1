Param(
  [string]$DeviceId = "emulator-5554",
  [string]$ProjectId = "trainix-dev"
)

Write-Host "[Trainix v1.3] Menjalankan Team Management E2E Test" -ForegroundColor Cyan
Write-Host "Pastikan Firebase Emulators sudah berjalan di terminal terpisah:" -ForegroundColor Yellow
Write-Host "  firebase emulators:start --project $ProjectId" -ForegroundColor Yellow
Write-Host ""

# Cek apakah emulator aktif
Write-Host "Memeriksa status emulator..." -ForegroundColor Green
flutter devices

Write-Host ""
Write-Host "Menjalankan Team Management E2E Test..." -ForegroundColor Green

flutter drive -d $DeviceId --driver test_driver/integration_test.dart --target integration_test/team_management_e2e_test.dart --dart-define=USE_FIREBASE_EMULATOR=true --dart-define=EMU_FIRESTORE_PORT=8082 --dart-define=EMU_AUTH_PORT=9098