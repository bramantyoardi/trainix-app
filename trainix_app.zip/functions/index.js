const { initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');
const { getAuth } = require('firebase-admin/auth');
const functions = require('firebase-functions');

// Initialize Admin SDK (bypasses Firestore security rules)
initializeApp();

/**
 * Menghasilkan kode unik dengan panjang tertentu (A-Z0-9)
 * @param {number} length - Panjang kode yang diinginkan (default: 6)
 * @returns {string} Kode unik dengan karakter A-Z0-9
 */
function genCode(length = 6) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

// When a team is created, automatically create the owner membership and generate team code (idempotent + structured logs)
exports.onTeamCreatedCreateOwnerMembership = functions
  .region('asia-southeast1')
  .runWith({ timeoutSeconds: 60, memory: '128MB' })
  .firestore
  .document('teams/{teamId}')
  .onCreate(async (snap, context) => {
    const teamId = context.params.teamId;
    const data = snap.data() || {};

    // Accept both camelCase and snake_case for backward compatibility
    const uid = data.created_by || data.createdBy || data.coachId;

    if (!uid) {
      functions.logger.warn(`[team:${teamId}] created_by/createdBy kosong, skip create owner membership`, { teamId, hasCreatedBy: !!data.created_by, hasCreatedByCamel: !!data.createdBy, hasCoachId: !!data.coachId });
      return null;
    }

    try {
      const db = getFirestore();
      const teamRef = snap.ref;
      const memberRef = teamRef.collection('members').doc(uid);

      // Check existing to avoid DUP writes under retry
      const existing = await memberRef.get();
      if (existing.exists) {
        functions.logger.info(`[CF] Owner membership already exists`, { teamId, uid });
        // Continue to check and update team code if needed
      }

      const now = FieldValue.serverTimestamp();
      const code = genCode(6); // Generate 6-character code (A-Z0-9)

      // Use transaction to ensure atomic operations
      await db.runTransaction(async (tx) => {
        // Check if member already exists
        const snapMember = await tx.get(memberRef);
        
        // Create member document if it doesn't exist
        if (!snapMember.exists) {
          tx.set(memberRef, {
            // Identification (snake_case canonical)
            user_id: uid,
            // Role & Status
            role: 'coach',
            status: 'approved',
            is_active: true,
            // Owner flag
            is_owner: true,
            // Timestamps
            joined_at: now,
            date_joined: now,
            // Approver (self-approved for initial owner)
            approved_by: uid,
            // Audit fields (snake_case canonical)
            created_by: uid,
            updated_by: uid,
            created_at: now,
            updated_at: now,
          });
        }
        
        // Update team code if it doesn't exist
        if (!data.code) {
          tx.update(teamRef, { code });
          functions.logger.info(`[CF] Team code generated`, { teamId, code });
        }
      });

      functions.logger.info(`[CF] Owner membership and team code process completed`, { teamId, uid });
      return null;
    } catch (err) {
      functions.logger.error(`[CF] Error creating owner membership`, { teamId, error: err?.message || err });
      return null;
    }
  });

// ─────────────────────────────────────────────────────────────────────────────
// 🏆 Leaderboard Aggregator: on training_logs write
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Compute week label like "YYYY-WNN".
 * Follows the client-side logic (days since start of year / 7, ceil), using log date.
 */
function computeWeekLabel(dateObj) {
  const year = dateObj.getFullYear();
  const startOfYear = new Date(year, 0, 1);
  const daysSinceStart = Math.floor((dateObj - startOfYear) / (1000 * 60 * 60 * 24));
  const weekNumber = Math.ceil(daysSinceStart / 7);
  return `${year}-W${weekNumber}`;
}

/**
 * Get start/end of the computed week (based on simple 7-day buckets from Jan 1).
 */
function getWeekRange(dateObj) {
  const startOfYear = new Date(dateObj.getFullYear(), 0, 1);
  const daysSinceStart = Math.floor((dateObj - startOfYear) / (1000 * 60 * 60 * 24));
  const bucketIndex = Math.floor(daysSinceStart / 7); // 0-based bucket
  const startDayOffset = bucketIndex * 7;
  const start = new Date(startOfYear.getTime() + startDayOffset * 24 * 60 * 60 * 1000);
  const end = new Date(start.getTime() + 6 * 24 * 60 * 60 * 1000);
  return { start, end };
}

exports.onTrainingLogWriteAggregateLeaderboard = functions
  .region('asia-southeast1')
  .runWith({ timeoutSeconds: 90, memory: '256MB' })
  .firestore
  .document('teams/{teamId}/training_logs/{logId}')
  .onWrite(async (change, context) => {
    const teamId = context.params.teamId;
    const before = change.before.exists ? change.before.data() : null;
    const after = change.after.exists ? change.after.data() : null;

    // Choose one of before/after to read athlete/date
    const refData = after || before || {};
    const athleteId = refData.athlete_id || refData.athleteId;
    const date = refData.date || refData.date_time || refData.dateTime;

    if (!athleteId || !date) {
      functions.logger.warn(`[CF] Skip agg: missing athleteId/date`, { teamId, athleteIdPresent: !!athleteId, datePresent: !!date });
      return null;
    }

    try {
      const db = getFirestore();

      // Convert Timestamp to JS Date
      const dateObj = date.toDate ? date.toDate() : new Date(date);
      const week = computeWeekLabel(dateObj);
      const { start, end } = getWeekRange(dateObj);

      // Query logs for this athlete in this week
      const logsSnap = await db
        .collection('teams').doc(teamId)
        .collection('training_logs')
        .where('athlete_id', '==', athleteId)
        .where('date', '>=', start)
        .where('date', '<=', end)
        .get();

      const count = logsSnap.size;
      let totalScore = 0;
      logsSnap.forEach(doc => {
        const d = doc.data();
        const score = d.score;
        if (typeof score === 'number') totalScore += score;
        else if (typeof score === 'string') totalScore += parseFloat(score) || 0;
      });
      const average = count > 0 ? (totalScore / count) : 0;
      const consistency = count * 2.0;
      const intensity = average;
      const total = consistency + intensity;

      // Optional: enrich athlete_name/photo from users/{uid}
      let athleteName = null;
      let athletePhotoUrl = null;
      try {
        const userSnap = await db.collection('users').doc(athleteId).get();
        if (userSnap.exists) {
          const u = userSnap.data() || {};
          athleteName = u.name || u.username || null;
          athletePhotoUrl = u.photoUrl || u.profileImageUrl || null;
        }
      } catch (e) {
        // Non-fatal
      }

      const leaderboardRef = db
        .collection('teams').doc(teamId)
        .collection('leaderboards').doc(`${athleteId}_${week}`);

      await db.runTransaction(async (tx) => {
        const current = await tx.get(leaderboardRef);
        const now = FieldValue.serverTimestamp();
        const payload = {
          team_id: teamId,
          week,
          athlete_id: athleteId,
          scores: { consistency, intensity, total },
          total,
          eligible: count > 0,
          last_updated: now,
          athlete_name: athleteName,
          athlete_photo_url: athletePhotoUrl,
          updated_at: now,
          updated_by: 'system',
        };
        if (!current.exists) {
          payload.created_at = now;
          payload.created_by = 'system';
        }
        tx.set(leaderboardRef, payload, { merge: true });
      });

      functions.logger.info(`[CF] Leaderboard aggregated`, { teamId, athleteId, week, count, total });
      return null;
    } catch (err) {
      functions.logger.error(`[CF] Error aggregating leaderboard`, { teamId, error: err?.message || err });
      return null;
    }
  });

// ─────────────────────────────────────────────────────────────────────────────
// 👥 Members Counters Sync: on members create/update/delete
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Recompute member_count, pending_count, coach_count for a team.
 */
async function recomputeMemberCounters(db, teamId) {
  const membersSnap = await db.collection('teams').doc(teamId).collection('members').get();
  let memberCount = 0; // approved + active
  let pendingCount = 0; // status == pending
  let coachCount = 0; // role == Coach/coach and approved + active
  membersSnap.forEach(doc => {
    const d = doc.data() || {};
    const status = d.status;
    const role = d.role;
    const isActive = d.is_active === true || d.isActive === true;
    if (status === 'pending') pendingCount++;
    if (status === 'approved' && isActive) {
      memberCount++;
      if (role === 'Coach' || role === 'coach') coachCount++;
    }
  });
  await db.collection('teams').doc(teamId).set({
    member_count: memberCount,
    pending_count: pendingCount,
    coach_count: coachCount,
    updated_at: getFirestore().FieldValue ? getFirestore().FieldValue.serverTimestamp() : undefined,
    updated_by: 'system',
  }, { merge: true });
}

exports.onMembersWriteSyncCounters = functions
  .region('asia-southeast1')
  .runWith({ timeoutSeconds: 60, memory: '128MB' })
  .firestore
  .document('teams/{teamId}/members/{uid}')
  .onWrite(async (change, context) => {
    const teamId = context.params.teamId;
    try {
      const db = getFirestore();
      await recomputeMemberCounters(db, teamId);
      functions.logger.info(`[CF] Counters synced`, { teamId });
    } catch (err) {
      functions.logger.error(`[CF] Error syncing counters`, { teamId, error: err?.message || err });
    }
    return null;
  });

// ─────────────────────────────────────────────────────────────────────────────
// 🔥 Admin Utility: Wipe all Firebase Auth users (Production)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * WARNING: Destructive operation. Deletes ALL Firebase Auth users in the project.
 * Region: asia-southeast1
 * Protect this endpoint if needed (e.g., allow only specific admin IP or token).
 */
exports.wipeAllAuthUsers = functions
  .region('asia-southeast1')
  .runWith({ timeoutSeconds: 540, memory: '256MB' })
  .https.onRequest(async (req, res) => {
    try {
      const auth = getAuth();
      let nextPageToken = undefined;
      let totalDeleted = 0;

      while (true) {
        const result = await auth.listUsers(1000, nextPageToken);
        const uids = result.users.map((u) => u.uid);

        if (uids.length > 0) {
          await Promise.all(uids.map((uid) => auth.deleteUser(uid)));
          totalDeleted += uids.length;
          functions.logger.info(`[Auth Wipe] Deleted batch`, { count: uids.length });
        }

        if (result.pageToken) {
          nextPageToken = result.pageToken;
        } else {
          break;
        }
      }

      functions.logger.info(`[Auth Wipe] Completed`, { totalDeleted });
      res.status(200).json({ status: 'ok', deleted: totalDeleted });
    } catch (err) {
      functions.logger.error(`[Auth Wipe] Error`, { error: err?.message || err });
      res.status(500).json({ status: 'error', message: err?.message || String(err) });
    }
  });

// ─────────────────────────────────────────────────────────────────────────────
// 🔧 Admin Utility: Backfill join_policy yang hilang/invalid di koleksi teams
// ─────────────────────────────────────────────────────────────────────────────

exports.backfillJoinPolicy = functions
  .region('asia-southeast1')
  .runWith({ timeoutSeconds: 540, memory: '256MB' })
  .https.onRequest(async (req, res) => {
    try {
      const db = getFirestore();
      const snap = await db.collection('teams').get();
      let updated = 0;
      const batchSize = 500;
      let batch = db.batch();
      let ops = 0;
  
      snap.forEach(doc => {
        const data = doc.data() || {};
        const jp = data.join_policy || data.joinPolicy || null;
        if (!jp || !['open','ask_to_join','closed'].includes(jp)) {
          batch.set(doc.ref, { join_policy: 'ask_to_join', updated_at: FieldValue.serverTimestamp(), updated_by: 'system' }, { merge: true });
          updated++;
          ops++;
          if (ops >= batchSize) {
            batch.commit();
            batch = db.batch();
            ops = 0;
          }
        }
      });
      if (ops > 0) await batch.commit();
      functions.logger.info('[Backfill] Completed', { updated });
      res.status(200).json({ status: 'ok', updated });
    } catch (err) {
      functions.logger.error('[Backfill] Error', { error: err?.message || err });
      res.status(500).json({ status: 'error', message: err?.message || String(err) });
    }
  });

// ─────────────────────────────────────────────────────────────────────────────
// 🔔 Membership Management (Callable)
//   - approveOrRejectMembership
//   - requestJoinTeam
//   - leaveTeam
// These endpoints enforce server-side checks and can be used by clients
// instead of direct Firestore writes, to reduce PERMISSION_DENIED friction.
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Approve or reject a membership (target user) within a team.
 * data: { teamId: string, memberId: string, action: 'approve'|'reject' }
 */
exports.approveOrRejectMembership = functions
  .region('asia-southeast1')
  .runWith({ timeoutSeconds: 60, memory: '128MB' })
  .https.onCall(async (data, context) => {
    const actorUid = context?.auth?.uid;
    if (!actorUid) {
      throw new functions.https.HttpsError('unauthenticated', 'Login diperlukan');
    }
    const teamId = String(data?.teamId || '').trim();
    const memberId = String(data?.memberId || '').trim();
    const action = String(data?.action || '').trim().toLowerCase();
    if (!teamId || !memberId || !['approve','reject'].includes(action)) {
      throw new functions.https.HttpsError('invalid-argument', 'Argumen tidak valid');
    }

    try {
      const db = getFirestore();
      const teamRef = db.collection('teams').doc(teamId);
      const actorRef = teamRef.collection('members').doc(actorUid);
      const targetRef = teamRef.collection('members').doc(memberId);

      const [actorSnap, targetSnap] = await Promise.all([actorRef.get(), targetRef.get()]);
      if (!actorSnap.exists) {
        throw new functions.https.HttpsError('permission-denied', 'Aktor bukan anggota tim');
      }
      const actor = actorSnap.data() || {};
      const isApproved = actor.status === 'approved';
      const isActive = actor.is_active === true || actor.isActive === true || !('is_active' in actor);
      const isCoach = (actor.role === 'coach' || actor.role === 'Coach' || actor.role === 'COACH');
      const isOwner = actor.is_owner === true;
      if (!(isApproved && isActive && (isCoach || isOwner))) {
        throw new functions.https.HttpsError('permission-denied', 'Aktor tidak berhak menyetujui/menolak');
      }

      if (!targetSnap.exists) {
        throw new functions.https.HttpsError('not-found', 'Target membership tidak ditemukan');
      }
      const target = targetSnap.data() || {};
      if (target.is_owner === true) {
        throw new functions.https.HttpsError('failed-precondition', 'Tidak dapat mengubah status owner');
      }

      const now = FieldValue.serverTimestamp();
      const payload = {
        status: action === 'approve' ? 'approved' : 'rejected',
        is_active: action === 'approve',
        approved_by: actorUid,
        updated_at: now,
        updated_by: actorUid,
      };

      await targetRef.set(payload, { merge: true });
      functions.logger.info('[Callable] approveOrRejectMembership', { teamId, actorUid, memberId, action });
      return { status: 'ok' };
    } catch (err) {
      functions.logger.error('[Callable] approveOrRejectMembership error', { error: err?.message || err, teamId, memberId, actorUid });
      throw new functions.https.HttpsError('internal', err?.message || String(err));
    }
  });

/**
 * Request to join a team for the current user.
 * If team join_policy is 'open' → directly approved membership.
 * If 'ask_to_join' → create pending membership.
 * data: { teamId: string }
 */
exports.requestJoinTeam = functions
  .region('asia-southeast1')
  .runWith({ timeoutSeconds: 60, memory: '128MB' })
  .https.onCall(async (data, context) => {
    const uid = context?.auth?.uid;
    if (!uid) {
      throw new functions.https.HttpsError('unauthenticated', 'Login diperlukan');
    }
    const teamId = String(data?.teamId || '').trim();
    if (!teamId) {
      throw new functions.https.HttpsError('invalid-argument', 'Argumen tidak valid');
    }
    try {
      const db = getFirestore();
      const teamRef = db.collection('teams').doc(teamId);
      const teamSnap = await teamRef.get();
      if (!teamSnap.exists) {
        throw new functions.https.HttpsError('not-found', 'Tim tidak ditemukan');
      }
      const team = teamSnap.data() || {};
      const jp = team.join_policy || team.joinPolicy || 'ask_to_join';
      const memberRef = teamRef.collection('members').doc(uid);
      const now = FieldValue.serverTimestamp();
      if (jp === 'open') {
        await memberRef.set({
          user_id: uid,
          status: 'approved',
          is_active: true,
          role: 'athlete',
          approved_by: uid,
          joined_at: now,
          updated_at: now,
          updated_by: uid,
        }, { merge: true });
      } else {
        await memberRef.set({
          user_id: uid,
          status: 'pending',
          is_active: false,
          role: 'athlete',
          requested_at: now,
          updated_at: now,
          updated_by: uid,
        }, { merge: true });
      }
      functions.logger.info('[Callable] requestJoinTeam', { teamId, uid, jp });
      return { status: 'ok', join_policy: jp };
    } catch (err) {
      functions.logger.error('[Callable] requestJoinTeam error', { error: err?.message || err, teamId, uid });
      throw new functions.https.HttpsError('internal', err?.message || String(err));
    }
  });

/**
 * Leave team for current user (cannot leave if owner).
 * data: { teamId: string }
 */
exports.leaveTeam = functions
  .region('asia-southeast1')
  .runWith({ timeoutSeconds: 60, memory: '128MB' })
  .https.onCall(async (data, context) => {
    const uid = context?.auth?.uid;
    if (!uid) {
      throw new functions.https.HttpsError('unauthenticated', 'Login diperlukan');
    }
    const teamId = String(data?.teamId || '').trim();
    if (!teamId) {
      throw new functions.https.HttpsError('invalid-argument', 'Argumen tidak valid');
    }
    try {
      const db = getFirestore();
      const memberRef = db.collection('teams').doc(teamId).collection('members').doc(uid);
      const snap = await memberRef.get();
      if (!snap.exists) {
        throw new functions.https.HttpsError('not-found', 'Membership tidak ditemukan');
      }
      const d = snap.data() || {};
      if (d.is_owner === true) {
        throw new functions.https.HttpsError('failed-precondition', 'Owner tidak dapat keluar dari tim');
      }
      await memberRef.delete();
      functions.logger.info('[Callable] leaveTeam', { teamId, uid });
      return { status: 'ok' };
    } catch (err) {
      functions.logger.error('[Callable] leaveTeam error', { error: err?.message || err, teamId, uid });
      throw new functions.https.HttpsError('internal', err?.message || String(err));
    }
  });