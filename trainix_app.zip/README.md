# Trainix App

Aplikasi mobile untuk manajemen training dan fitness yang dibangun dengan Flutter dan Firebase.

## 📱 Tentang Aplikasi

Trainix adalah aplikasi Android yang dirancang untuk membantu pengguna dalam mengelola aktivitas training dan fitness mereka. 
Aplikasi ini menyediakan fitur-fitur lengkap untuk tracking workout, manajemen tim, leaderboard, dan notifikasi.

## ✨ Fitur Utama

- 🔐 **Autentikasi Pengguna** - Login, register, verifikasi email, forgot password
- 👥 **Manajemen Tim** - Buat dan kelola tim training dengan kebijakan bergabung (open, ask_to_join, closed)
- 🏃‍♂️ **Training Log** - Catat dan track aktivitas training
- 📈 **Manajemen Intensitas Latihan (HRR)** - Perhitungan berbasis metode Tanaka & Karvonen (HRmax & HRR)
- 📊 **Leaderboard** - Sistem ranking dan kompetisi mingguan
- 🔔 **Push Notifications** - (Fitur rencana pengembangan; belum aktif pada versi 1.3.0)
- 📈 **Program Training** - Kelola program latihan mingguan
- 🔒 **Security & Role-based Access** - Hanya Coach dan Owner (`is_owner:true`) yang dapat membuat atau memperbarui data latihan
- 🚪 **Join Policy Management** - Kontrol cara anggota bergabung ke tim (terbuka, persetujuan, tertutup)

## 🛠️ Teknologi yang Digunakan (Android-only)

- Flutter (Android)
- Firebase (Auth, Cloud Firestore, Storage, Messaging)
- Provider (state management)
- Material Design (UI/UX)

## 📦 Dependencies

### Core Dependencies
- `firebase_core: ^2.15.1`
- `firebase_auth: ^4.9.0`
- `cloud_firestore: ^4.9.1`
- `firebase_storage: ^11.2.6`
- `firebase_messaging: ^14.6.7`
- `provider: ^6.0.5`

### UI & Utils
- `google_sign_in: ^6.1.4`
- `image_picker: ^1.0.2`
- `flutter_local_notifications: ^15.1.0+1`
- `permission_handler: ^10.4.3`
- `intl: ^0.18.1`
- `crypto: ^3.0.3`

### Development
- `flutter_test`
- `flutter_lints: ^2.0.0`
- `fake_cloud_firestore: ^2.4.1+1`
- `firebase_auth_mocks: ^0.13.0`

## 🚀 Cara Menjalankan

1. **Clone repository**
   ```bash
   git clone https://github.com/bramantyoardi_/trainix_app.git
   cd trainix_app
   ```

2. **Install dependencies**
   ```bash
   flutter pub get
   ```

3. **Setup Firebase (Android)**
   - Buat project baru di [Firebase Console](https://console.firebase.google.com/)
   - Tambahkan aplikasi Android
   - Download `google-services.json` (Android) dan letakkan di `android/app/`

4. **Jalankan aplikasi**
   ```bash
   flutter run
   ```

## 📁 Struktur Project

```
lib/
├── extensions/          # Extension methods
├── models/             # Data models
├── providers/          # State management (Provider)
├── services/           # Business logic services
├── ui/                # User interface
│   ├── authentication/ # Auth screens
│   ├── components/     # Reusable components
│   ├── team/          # Team management
│   ├── training/      # Training screens
│   └── user_management/ # User management
└── utils/             # Utility functions

docs/
├── trainix_core_rules.yaml          # Aturan inti & kebijakan logika aplikasi
├── firestore_schema.md              # Blueprint struktur koleksi Firestore
├── firestore_rules_summary.yaml     # Ringkasan izin akses Firestore
├── README_TRAINIX_CORE.md           # Narasi & korelasi antar file

firestore.rules                      # File Security Rules utama (aktif untuk Firebase)
firebase.json                        # Konfigurasi Firebase Project
pubspec.yaml                         # Dependensi Flutter
README.md                            # Dokumentasi utama proyek
```

## 🔧 Konfigurasi

### Firebase Setup
1. Aktifkan Authentication dengan Email/Password dan Google Sign-In
2. Setup Firestore Database dengan rules yang sesuai (role-based; write program, training logs, dan intensitas hanya Coach & Owner; leaderboard diupdate via Cloud Function/Admin SDK)
3. Konfigurasi Firebase Storage untuk upload gambar
4. Setup Firebase Messaging untuk push notifications (out-of-scope v1.1.0)

### Mode Produksi
- Aplikasi di-set untuk langsung terhubung ke Firebase produksi menggunakan `DefaultFirebaseOptions.currentPlatform`.
- Tidak menggunakan emulator (Firestore/Auth) dan tidak ada flag `USE_EMULATOR`.

### Android Permissions
Aplikasi memerlukan permissions berikut:
- Internet access
- Camera (untuk foto profil)
- Storage (untuk menyimpan gambar)
- Notifications

## 🧪 Testing

Jalankan test dengan perintah:
```bash
flutter test
```

Test yang tersedia:
- Unit tests untuk services
- Widget tests untuk UI components
- Firestore rules testing

## 📚 Spesifikasi Resmi

Dokumentasi dan konfigurasi sistem Trainix dapat ditemukan di folder `/docs`, meliputi:

- `trainix_core_rules.yaml` – Aturan inti aplikasi & kebijakan logika
- `firestore_schema.md` – Struktur koleksi & bidang Firestore
- `firestore_rules_summary.yaml` – Ringkasan izin akses Firestore
- `README_TRAINIX_CORE.md` – Penjelasan korelasi antar file dokumentasi

## 🔒 Keamanan & Role-based Access

- Akses data berbasis **role (Coach / Athlete / Owner)**.
- Hanya Coach dan Owner (`is_owner:true`) yang dapat membuat atau memperbarui program latihan, log latihan, serta leaderboard.
- Leaderboard hanya tersedia sebagai subkoleksi `teams/{teamId}/leaderboards` dan penulisan manual dinonaktifkan (diupdate melalui Cloud Function/Admin SDK).
- Athlete hanya dapat melihat data tim dan mengelola reminder pribadi.
- **Join Policy Management**: Hanya Owner yang dapat mengubah kebijakan bergabung tim (open, ask_to_join, closed).
- **Pending Members**: Coach dan Owner dapat menyetujui atau menolak permintaan bergabung untuk tim dengan kebijakan `ask_to_join`.

## 🤝 Kontribusi

1. Fork repository
2. Buat branch fitur (`git checkout -b feature/AmazingFeature`)
3. Commit perubahan (`git commit -m 'Add some AmazingFeature'`)
4. Push ke branch (`git push origin feature/AmazingFeature`)
5. Buat Pull Request

## 📄 Lisensi

Project ini menggunakan lisensi MIT. Lihat file `LICENSE` untuk detail lebih lanjut.

## 👨‍💻 Developer

Dikembangkan sebagai bagian dari project skripsi untuk aplikasi manajemen intensitas latihan atlet Tarung Derajat berbasis Android menggunakan metode Scrum.