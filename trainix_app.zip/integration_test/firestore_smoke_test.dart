import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_app_check/firebase_app_check.dart';
import 'dart:io' show Platform;

import 'package:trainix_app/firebase_options.dart';

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('Firestore create team smoke test', (tester) async {
    await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
    final firestore = FirebaseFirestore.instance;
    final auth = FirebaseAuth.instance;

    final host = Platform.isAndroid ? '10.0.2.2' : '127.0.0.1';
    const firestorePort = int.fromEnvironment('EMU_FIRESTORE_PORT', defaultValue: 8080);
    const authPort = int.fromEnvironment('EMU_AUTH_PORT', defaultValue: 9099);
    firestore.useFirestoreEmulator(host, firestorePort);
    await auth.useAuthEmulator(host, authPort);

    await FirebaseAppCheck.instance.activate(
      androidProvider: AndroidProvider.debug,
      appleProvider: AppleProvider.debug,
    );

    // Ensure a test user exists
    const email = 'smoke_coach@test.com';
    const password = 'password123';
    try {
      await auth.createUserWithEmailAndPassword(email: email, password: password);
    } catch (_) {}

    await auth.signInWithEmailAndPassword(email: email, password: password);
    final uid = auth.currentUser!.uid;
    print('[SMOKE] Signed in as: ' + uid);

    // Probe read
    try {
      final probe = await firestore.collection('teams').doc('__smoke_probe__').get();
      print('[SMOKE] Probe read exists=' + probe.exists.toString());
    } catch (e) {
      print('[SMOKE] Probe read failed: ' + e.toString());
    }

    // Try minimal create
    final teamRef = firestore.collection('teams').doc();
    final payload = {
      'name': 'Smoke Team',
      'coach_id': uid,
      'join_policy': 'open',
      'member_count': 1,
      'pending_count': 0,
      'coach_count': 1,
      'is_active': true,
      'created_at': FieldValue.serverTimestamp(),
      'created_by': uid,
      'updated_at': FieldValue.serverTimestamp(),
      'updated_by': uid,
    };
    print('[SMOKE] Creating team with payload: ' + payload.toString());

    try {
      await teamRef.set(payload);
      print('[SMOKE] Team created: ' + teamRef.id);
    } catch (e) {
      fail('[SMOKE] Team create failed: ' + e.toString());
    }

    // Clean up
    try {
      await teamRef.delete();
      await auth.signOut();
    } catch (_) {}
  });
}