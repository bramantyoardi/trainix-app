import 'dart:io' show Platform;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:trainix_app/firebase_options.dart';

// Helper: ensure a user exists and sign in, returning uid
Future<String> _ensureUser(FirebaseAuth auth, String email) async {
  const password = 'password123';
  try {
    final cred = await auth.signInWithEmailAndPassword(email: email, password: password);
    return cred.user!.uid;
  } on FirebaseAuthException catch (e) {
    if (e.code == 'user-not-found') {
      final cred = await auth.createUserWithEmailAndPassword(email: email, password: password);
      return cred.user!.uid;
    }
    // Fallback: if other errors, try create then sign-in
    try {
      final cred = await auth.createUserWithEmailAndPassword(email: email, password: password);
      return cred.user!.uid;
    } catch (_) {
      final cred = await auth.signInWithEmailAndPassword(email: email, password: password);
      return cred.user!.uid;
    }
  }
}

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('Firestore Rules E2E (Android-only)', () {
    late FirebaseFirestore firestore;
    late FirebaseAuth auth;

    setUpAll(() async {
      WidgetsFlutterBinding.ensureInitialized();
      await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

      firestore = FirebaseFirestore.instance;
      auth = FirebaseAuth.instance;

      // Use emulator only when explicitly enabled via dart-define
      const useEmu = bool.fromEnvironment('USE_FIREBASE_EMULATOR', defaultValue: false);
      if (useEmu) {
        final host = Platform.isAndroid ? '10.0.2.2' : '127.0.0.1';
        const firestorePort = int.fromEnvironment('EMU_FIRESTORE_PORT', defaultValue: 8080);
        const authPort = int.fromEnvironment('EMU_AUTH_PORT', defaultValue: 9099);
        firestore.useFirestoreEmulator(host, firestorePort);
        await auth.useAuthEmulator(host, authPort);
      } else {
        debugPrint('Using PRODUCTION backend for Firestore/Auth (no emulator)');
      }
    });

    tearDown(() async {
      await _signOutIfNeeded(auth);
    });

    testWidgets('Programs: coach write ✅, athlete write ❌', (tester) async {
      const teamId = 'e2e-team-1';

      // Create and sign in coach
      final coachUid = await _ensureUser(auth, 'coach_e2e1@test.com');
      await firestore.collection('teams').doc(teamId).collection('members').doc(coachUid).set({
        'role': 'Coach', 'status': 'approved', 'is_active': true, 'is_owner': false,
        'created_by': coachUid, 'updated_by': coachUid,
        'created_at': Timestamp.now(), 'updated_at': Timestamp.now(),
      });
      // Coach write should pass (includes audit fields)
      await expectLater(
        firestore.collection('teams').doc(teamId).collection('programs').add({
          'name': 'Program E2E', 'description': 'desc',
          'created_by': coachUid, 'updated_by': coachUid,
          'created_at': Timestamp.now(), 'updated_at': Timestamp.now(),
        }),
        completes,
      );

      // Create and sign in athlete
      final athleteUid = await _ensureUser(auth, 'ath_e2e1@test.com');
      await firestore.collection('teams').doc(teamId).collection('members').doc(athleteUid).set({
        'role': 'Athlete', 'status': 'approved', 'is_active': true, 'is_owner': false,
        'created_by': athleteUid, 'updated_by': athleteUid,
        'created_at': Timestamp.now(), 'updated_at': Timestamp.now(),
      });
      // Athlete write should fail
      await expectLater(
        firestore.collection('teams').doc(teamId).collection('programs').add({
          'name': 'Program Athlete', 'description': 'desc',
          'created_by': athleteUid, 'updated_by': athleteUid,
          'created_at': Timestamp.now(), 'updated_at': Timestamp.now(),
        }),
        throwsA(isA<FirebaseException>()),
      );
    });

    testWidgets('TrainingLogs: coach write ✅, athlete write ❌', (tester) async {
      const teamId = 'e2e-team-2';

      // ensure coach and register membership, signed-in as coach
      final coachUid = await _ensureUser(auth, 'coach_e2e2@test.com');
      await firestore.collection('teams').doc(teamId).collection('members').doc(coachUid).set({
        'role': 'Coach', 'status': 'approved', 'is_active': true, 'is_owner': false,
        'created_by': coachUid, 'updated_by': coachUid,
        'created_at': Timestamp.now(), 'updated_at': Timestamp.now(),
      });
      await expectLater(
        firestore.collection('teams').doc(teamId).collection('training_logs').add({
          'program_id': 'p-1', 'athlete_id': coachUid, 'score': 88.0, 'date': Timestamp.fromDate(DateTime.now()),
          'created_by': coachUid, 'updated_by': coachUid,
          'created_at': Timestamp.now(), 'updated_at': Timestamp.now(),
        }),
        completes,
      );

      // ensure athlete and register membership, signed-in as athlete
      final athleteUid = await _ensureUser(auth, 'ath_e2e2@test.com');
      await firestore.collection('teams').doc(teamId).collection('members').doc(athleteUid).set({
        'role': 'Athlete', 'status': 'approved', 'is_active': true, 'is_owner': false,
        'created_by': athleteUid, 'updated_by': athleteUid,
        'created_at': Timestamp.now(), 'updated_at': Timestamp.now(),
      });
      await expectLater(
        firestore.collection('teams').doc(teamId).collection('training_logs').add({
          'program_id': 'p-1', 'athlete_id': athleteUid, 'score': 88.0, 'date': Timestamp.fromDate(DateTime.now()),
          'created_by': athleteUid, 'updated_by': athleteUid,
          'created_at': Timestamp.now(), 'updated_at': Timestamp.now(),
        }),
        throwsA(isA<FirebaseException>()),
      );
    });

    testWidgets('TrainingLogs: athlete read own ✅, read others ❌', (tester) async {
      const teamId = 'e2e-team-3';

      // ensure coach and register membership
      final coachUid = await _ensureUser(auth, 'coach_e2e3@test.com');
      await firestore.collection('teams').doc(teamId).collection('members').doc(coachUid).set({
        'role': 'Coach', 'status': 'approved', 'is_active': true, 'is_owner': false,
        'created_by': coachUid, 'updated_by': coachUid,
        'created_at': Timestamp.now(), 'updated_at': Timestamp.now(),
      });

      // ensure athlete A and B and register membership
      final athleteAUid = await _ensureUser(auth, 'athA_e2e3@test.com');
      await firestore.collection('teams').doc(teamId).collection('members').doc(athleteAUid).set({
        'role': 'Athlete', 'status': 'approved', 'is_active': true, 'is_owner': false,
        'created_by': athleteAUid, 'updated_by': athleteAUid,
        'created_at': Timestamp.now(), 'updated_at': Timestamp.now(),
      });
      final athleteBUid = await _ensureUser(auth, 'athB_e2e3@test.com');
      await firestore.collection('teams').doc(teamId).collection('members').doc(athleteBUid).set({
        'role': 'Athlete', 'status': 'approved', 'is_active': true, 'is_owner': false,
        'created_by': athleteBUid, 'updated_by': athleteBUid,
        'created_at': Timestamp.now(), 'updated_at': Timestamp.now(),
      });

      // switch to coach for writing logs
      await auth.signInWithEmailAndPassword(email: 'coach_e2e3@test.com', password: 'password123');
      await firestore.collection('teams').doc(teamId).collection('training_logs').add({
        'program_id': 'p-1', 'athlete_id': athleteAUid, 'score': 80.0, 'date': Timestamp.fromDate(DateTime.now()),
        'created_by': coachUid, 'updated_by': coachUid,
        'created_at': Timestamp.now(), 'updated_at': Timestamp.now(),
      });
      await firestore.collection('teams').doc(teamId).collection('training_logs').add({
        'program_id': 'p-1', 'athlete_id': athleteBUid, 'score': 90.0, 'date': Timestamp.fromDate(DateTime.now()),
        'created_by': coachUid, 'updated_by': coachUid,
        'created_at': Timestamp.now(), 'updated_at': Timestamp.now(),
      });

      // athlete A reads own logs succeeds
      await auth.signInWithEmailAndPassword(email: 'athA_e2e3@test.com', password: 'password123');
      await expectLater(
        firestore.collection('teams').doc(teamId).collection('training_logs').where('athlete_id', isEqualTo: athleteAUid).get(),
        completes,
      );
      // athlete A reads B's logs denied
      await expectLater(
        firestore.collection('teams').doc(teamId).collection('training_logs').where('athlete_id', isEqualTo: athleteBUid).get(),
        throwsA(isA<FirebaseException>()),
      );
    });

    testWidgets('Leaderboards: team member read ✅, non-member read ❌, coach write ❌', (tester) async {
      const teamId = 'e2e-team-4';

      // ensure coach
      final coachUid = await _ensureUser(auth, 'coach_e2e4@test.com');
      await firestore.collection('teams').doc(teamId).collection('members').doc(coachUid).set({
        'role': 'Coach', 'status': 'approved', 'is_active': true, 'is_owner': false,
        'created_by': coachUid, 'updated_by': coachUid,
        'created_at': Timestamp.now(), 'updated_at': Timestamp.now(),
      });

      // ensure athlete
      final athleteUid = await _ensureUser(auth, 'ath_e2e4@test.com');
      await firestore.collection('teams').doc(teamId).collection('members').doc(athleteUid).set({
        'role': 'Athlete', 'status': 'approved', 'is_active': true, 'is_owner': false,
        'created_by': athleteUid, 'updated_by': athleteUid,
        'created_at': Timestamp.now(), 'updated_at': Timestamp.now(),
      });

      // coach write leaderboard (denied by rules)
      await auth.signInWithEmailAndPassword(email: 'coach_e2e4@test.com', password: 'password123');
      await expectLater(
        firestore.collection('teams').doc(teamId).collection('leaderboards').doc('lb-1').set({
          'team_id': teamId, 'athlete_id': athleteUid, 'total_score': 70.0, 'rank': 2, 'last_updated': Timestamp.fromDate(DateTime.now()),
        }),
        throwsA(isA<FirebaseException>()),
      );

      // team member read
      await auth.signInWithEmailAndPassword(email: 'ath_e2e4@test.com', password: 'password123');
      await expectLater(
        firestore.collection('teams').doc(teamId).collection('leaderboards').doc('lb-1').get(),
        completes,
      );

      // outsider read denied
      final outsiderUid = await _ensureUser(auth, 'out_e2e4@test.com');
      await expectLater(
        firestore.collection('teams').doc(teamId).collection('leaderboards').doc('lb-1').get(),
        throwsA(isA<FirebaseException>()),
      );
    });

    testWidgets('Reminders: athlete create & edit own ✅', (tester) async {
      const teamId = 'e2e-team-5';
      const athleteEmail = 'athA_e2e5@test.com';

      // ensure athlete user and register as team member
      final athleteUid = await _ensureUser(auth, athleteEmail);
      await firestore.collection('teams').doc(teamId).collection('members').doc(athleteUid).set({
        'role': 'Athlete', 'status': 'approved', 'is_active': true, 'is_owner': false,
        'created_by': athleteUid, 'updated_by': athleteUid,
        'created_at': Timestamp.now(), 'updated_at': Timestamp.now(),
      });

      // athlete creates own reminder with canonical snake_case payload
      await firestore.collection('teams').doc(teamId).collection('reminders').doc('rem-a').set({
        'team_id': teamId,
        'title': 'Latihan Pagi',
        'description': 'Pemanasan 10 menit',
        'status': 'pending',
        'date_time': Timestamp.fromDate(DateTime.now().add(Duration(hours: 2))),
        'athlete_id': athleteUid,
        'created_by': athleteUid,
        'updated_by': athleteUid,
        'created_at': Timestamp.now(),
        'updated_at': Timestamp.now(),
      });

      // edit own reminder
      await expectLater(
        firestore.collection('teams').doc(teamId).collection('reminders').doc('rem-a').update({
          'title': 'Latihan Pagi Update',
          'updated_by': athleteUid,
          'updated_at': Timestamp.now(),
        }),
        completes,
      );
    });

    testWidgets('Reminders B: athlete edit others ❌', (tester) async {
      const teamId = 'e2e-team-5b';
      const athleteAEmail = 'athA_e2e5b@test.com';
      const athleteBEmail = 'athB_e2e5b@test.com';

      // Create and register athlete A
      final athleteAUid = await _ensureUser(auth, athleteAEmail);
      await firestore.collection('teams').doc(teamId).collection('members').doc(athleteAUid).set({
        'role': 'Athlete', 'status': 'approved', 'is_active': true, 'is_owner': false,
        'created_by': athleteAUid, 'updated_by': athleteAUid,
        'created_at': Timestamp.now(), 'updated_at': Timestamp.now(),
      });

      // Create and register athlete B
      final athleteBUid = await _ensureUser(auth, athleteBEmail);
      await firestore.collection('teams').doc(teamId).collection('members').doc(athleteBUid).set({
        'role': 'Athlete', 'status': 'approved', 'is_active': true, 'is_owner': false,
        'created_by': athleteBUid, 'updated_by': athleteBUid,
        'created_at': Timestamp.now(), 'updated_at': Timestamp.now(),
      });

      // athlete B creates reminder
      await auth.signInWithEmailAndPassword(email: athleteBEmail, password: 'password123');
      await firestore.collection('teams').doc(teamId).collection('reminders').doc('rem-b').set({
        'team_id': teamId,
        'title': 'Latihan Sore',
        'description': 'Pendinginan',
        'status': 'pending',
        'date_time': Timestamp.fromDate(DateTime.now().add(Duration(hours: 3))),
        'athlete_id': athleteBUid,
        'created_by': athleteBUid,
        'updated_by': athleteBUid,
        'created_at': Timestamp.now(),
        'updated_at': Timestamp.now(),
      });

      // athlete A tries to edit B's reminder → should deny
      await auth.signInWithEmailAndPassword(email: athleteAEmail, password: 'password123');
      await expectLater(
        firestore.collection('teams').doc(teamId).collection('reminders').doc('rem-b').update({
          'title': 'Diubah oleh A',
          'updated_by': athleteAUid,
          'updated_at': Timestamp.now(),
        }),
        throwsA(isA<FirebaseException>()),
      );
    });

    testWidgets('Reminders C: coach create for athlete ✅', (tester) async {
      const teamId = 'e2e-team-5c';
      const coachEmail = 'coach_e2e5c@test.com';
      const athleteEmail = 'athA_e2e5c@test.com';

      // ensure coach and athlete, register membership
      final coachUid = await _ensureUser(auth, coachEmail);
      await firestore.collection('teams').doc(teamId).collection('members').doc(coachUid).set({
        'role': 'Coach', 'status': 'approved', 'is_active': true, 'is_owner': false,
        'created_by': coachUid, 'updated_by': coachUid,
        'created_at': Timestamp.now(), 'updated_at': Timestamp.now(),
      });

      final athleteUid = await _ensureUser(auth, athleteEmail);
      await firestore.collection('teams').doc(teamId).collection('members').doc(athleteUid).set({
        'role': 'Athlete', 'status': 'approved', 'is_active': true, 'is_owner': false,
        'created_by': athleteUid, 'updated_by': athleteUid,
        'created_at': Timestamp.now(), 'updated_at': Timestamp.now(),
      });

      // coach creates reminder for athlete
      await auth.signInWithEmailAndPassword(email: coachEmail, password: 'password123');
      await expectLater(
        firestore.collection('teams').doc(teamId).collection('reminders').add({
          'team_id': teamId,
          'title': 'Tes HRR',
          'description': 'Latihan HRR 20 menit',
          'status': 'pending',
          'date_time': Timestamp.fromDate(DateTime.now().add(Duration(hours: 1))),
          'athlete_id': athleteUid,
          'created_by': coachUid,
          'updated_by': coachUid,
          'created_at': Timestamp.now(),
          'updated_at': Timestamp.now(),
        }),
        completes,
      );
    });
  });
}

Future<void> _signOutIfNeeded(FirebaseAuth auth) async {
  try {
    await auth.signOut();
  } catch (_) {}
}
