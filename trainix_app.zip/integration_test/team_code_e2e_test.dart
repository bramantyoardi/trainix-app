import 'dart:io' show Platform;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:trainix_app/firebase_options.dart';
import 'package:trainix_app/models/team.dart';
import 'package:trainix_app/services/firestore_service.dart';
import 'package:trainix_app/services/team_service.dart';

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('E2E: TeamService + Firestore Rules for team_code', () {
    late FirebaseFirestore firestore;
    late FirebaseAuth auth;
    late TeamService teamService;

    setUpAll(() async {
      WidgetsFlutterBinding.ensureInitialized();
      await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

      firestore = FirebaseFirestore.instance;
      auth = FirebaseAuth.instance;
      teamService = TeamService(FirestoreService());

      final host = Platform.isAndroid ? '10.0.2.2' : '127.0.0.1';
      firestore.useFirestoreEmulator(host, 8080);
      await auth.useAuthEmulator(host, 9099);
    });

    tearDown(() async {
      await _signOutIfNeeded(auth);
    });

    group('createTeam: skenario gagal untuk team_code tidak valid', () {
      setUp(() async {
        await auth.createUserWithEmailAndPassword(email: 'create_invalid@test.com', password: 'password123');
      });

      testWidgets('Format tidak sesuai pola (lowercase) ditolak', (tester) async {
        final team = Team(
          id: '',
          name: 'Invalid Lowercase',
          description: 'desc',
          coachId: auth.currentUser!.uid,
          coachName: 'Coach Invalid',
          createdAt: Timestamp.now(),
          config: TeamConfig(targetDays: 6, weights: {'consistency': 0.6, 'intensity': 0.4}),
          teamCode: 'abc123',
        );
        final teamId = await teamService.createTeam(team, auth.currentUser!.uid);
        expect(teamId, isNull, reason: 'createTeam harus gagal ketika team_code lowercase');
      });

      testWidgets('Mengandung karakter terlarang ditolak', (tester) async {
        final team = Team(
          id: '',
          name: 'Invalid SpecialChars',
          description: 'desc',
          coachId: auth.currentUser!.uid,
          coachName: 'Coach Invalid',
          createdAt: Timestamp.now(),
          config: TeamConfig(targetDays: 6, weights: {'consistency': 0.6, 'intensity': 0.4}),
          teamCode: 'ABC!12',
        );
        final teamId = await teamService.createTeam(team, auth.currentUser!.uid);
        expect(teamId, isNull, reason: 'createTeam harus gagal ketika team_code mengandung karakter terlarang');
      });

      testWidgets('Panjang < 6 atau > 6 ditolak', (tester) async {
        final t5 = Team(
          id: '', name: 'Len5', description: 'desc', coachId: auth.currentUser!.uid,
          coachName: 'Coach Invalid', createdAt: Timestamp.now(),
          config: TeamConfig(targetDays: 6, weights: {'consistency': 0.6, 'intensity': 0.4}), teamCode: 'ABC12',
        );
        final t7 = Team(
          id: '', name: 'Len7', description: 'desc', coachId: auth.currentUser!.uid,
          coachName: 'Coach Invalid', createdAt: Timestamp.now(),
          config: TeamConfig(targetDays: 6, weights: {'consistency': 0.6, 'intensity': 0.4}), teamCode: 'ABC1234',
        );
        final id5 = await teamService.createTeam(t5, auth.currentUser!.uid);
        final id7 = await teamService.createTeam(t7, auth.currentUser!.uid);
        expect(id5, isNull, reason: 'createTeam harus gagal ketika panjang < 6');
        expect(id7, isNull, reason: 'createTeam harus gagal ketika panjang > 6');
      });
    });

    group('createTeam: skenario sukses', () {
      setUp(() async {
        await auth.createUserWithEmailAndPassword(email: 'create_valid@test.com', password: 'password123');
      });

      testWidgets('Berhasil dengan team_code valid (disuplai)', (tester) async {
        final validCode = 'AB12C3';
        final team = Team(
          id: '',
          name: 'Valid Supplied',
          description: 'desc',
          coachId: auth.currentUser!.uid,
          coachName: 'Coach Valid',
          createdAt: Timestamp.now(),
          config: TeamConfig(targetDays: 6, weights: {'consistency': 0.6, 'intensity': 0.4}),
          teamCode: validCode,
        );
        final teamId = await teamService.createTeam(team, auth.currentUser!.uid);
        expect(teamId, isNotNull, reason: 'createTeam harus berhasil dengan kode valid');

        // Verifikasi data yang tersimpan sesuai input
        final doc = await firestore.collection('teams').doc(teamId!).get();
        expect(doc.exists, true);
        expect(doc.data()!['team_code'], validCode);
        expect(doc.data()!['name'], 'Valid Supplied');
      });

      testWidgets('Berhasil tanpa menyuplai team_code (generate otomatis)', (tester) async {
        final team = Team(
          id: '',
          name: 'Auto Code',
          description: 'desc',
          coachId: auth.currentUser!.uid,
          coachName: 'Coach Valid',
          createdAt: Timestamp.now(),
          config: TeamConfig(targetDays: 6, weights: {'consistency': 0.6, 'intensity': 0.4}),
        );
        final teamId = await teamService.createTeam(team, auth.currentUser!.uid);
        expect(teamId, isNotNull, reason: 'createTeam harus berhasil tanpa menyuplai kode');
        final doc = await firestore.collection('teams').doc(teamId!).get();
        final code = doc.data()!['team_code'] as String;
        expect(RegExp(r'^[A-Z0-9]{6}$').hasMatch(code), true, reason: 'kode otomatis harus 6 uppercase alfanumerik');
      });
    });

    group('update team_code: ditolak untuk tim yang sudah memiliki kode', () {
      setUp(() async {
        await auth.createUserWithEmailAndPassword(email: 'update_denied@test.com', password: 'password123');
      });

      testWidgets('Update team_code ditolak dan data original tidak berubah', (tester) async {
        // Buat tim dengan kode valid
        final team = Team(
          id: '',
          name: 'Update Denied',
          description: 'desc',
          coachId: auth.currentUser!.uid,
          coachName: 'Coach Valid',
          createdAt: Timestamp.now(),
          config: TeamConfig(targetDays: 6, weights: {'consistency': 0.6, 'intensity': 0.4}),
        );
        final teamId = await teamService.createTeam(team, auth.currentUser!.uid);
        expect(teamId, isNotNull);

        final originalDoc = await firestore.collection('teams').doc(teamId!).get();
        final originalCode = originalDoc.data()!['team_code'] as String;

        // Coba update team_code → harus ditolak oleh rules
        final ok = await teamService.updateTeam(teamId, {'team_code': 'ZZZZZZ'});
        expect(ok, false, reason: 'updateTeam harus gagal saat mencoba mengubah team_code');

        // Verifikasi data tidak berubah
        final afterDoc = await firestore.collection('teams').doc(teamId).get();
        expect(afterDoc.data()!['team_code'], originalCode);
      });
    });
  });
}

Future<void> _signOutIfNeeded(FirebaseAuth auth) async {
  try {
    await auth.signOut();
  } catch (_) {}
}