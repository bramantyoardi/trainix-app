import 'dart:io' show Platform;
import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:trainix_app/firebase_options.dart';
import 'package:trainix_app/models/team.dart';
import 'package:trainix_app/services/firestore_service.dart';
import 'package:trainix_app/services/team_service.dart';

void logWrite(String tag, String path, Map<String, dynamic> payload, FirebaseAuth auth) {
  final uid = auth.currentUser?.uid;
  final printable = payload.map((k, v) {
    if (v is FieldValue) return MapEntry(k, 'Timestamp.now()');
    if (v is Timestamp) return MapEntry(k, 'Timestamp(' + v.toDate().toString() + ')');
    return MapEntry(k, v);
  });
  debugPrint('[E2E][' + tag + '] uid=' + (uid ?? '(none)') + ' path=' + path + ' payload=' + printable.toString());
}

void logError(String tag, Object error) {
  debugPrint('[E2E][ERROR][' + tag + '] ' + error.toString());
}

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('Firestore Rules E2E - Reminders only', () {
    late FirebaseFirestore firestore;
    late FirebaseAuth auth;
    late TeamService teamService;

    setUpAll(() async {
      WidgetsFlutterBinding.ensureInitialized();
      await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

      firestore = FirebaseFirestore.instance;
      auth = FirebaseAuth.instance;
      teamService = TeamService(FirestoreService());

      final host = Platform.isAndroid ? '10.0.2.2' : '127.0.0.1';
      firestore.useFirestoreEmulator(host, 8080);
      await auth.useAuthEmulator(host, 9099);
    });

    tearDown(() async {
      await _signOutIfNeeded(auth);
    });

    testWidgets('Reminders: athlete own create/edit ✅, edit others ❌; coach create for athlete ✅', (tester) async {
      const athleteAEmail = 'athA_e2e5@test.com';
      const athleteBEmail = 'athB_e2e5@test.com';
      const coachEmail = 'coach_e2e5@test.com';

      // helper: ensure user exists or sign-in if already created
      Future<String> ensureUser(String email) async {
        const password = 'password123';
        try {
          final cred = await auth.signInWithEmailAndPassword(email: email, password: password);
          return cred.user!.uid;
        } on FirebaseAuthException catch (e) {
          if (e.code == 'user-not-found') {
            final cred = await auth.createUserWithEmailAndPassword(email: email, password: password);
            return cred.user!.uid;
          }
          // fallback: try create then sign-in
          try {
            final cred = await auth.createUserWithEmailAndPassword(email: email, password: password);
            return cred.user!.uid;
          } catch (_) {
            final cred = await auth.signInWithEmailAndPassword(email: email, password: password);
            return cred.user!.uid;
          }
        }
      }

      final coachUid = await ensureUser(coachEmail);
      await auth.signInWithEmailAndPassword(email: coachEmail, password: 'password123');

      // Try to create team via TeamService as coach (ensures audit fields + generates code)
      final team = Team(
        id: '',
        name: 'E2E Team 5',
        description: 'Reminders test',
        coachId: coachUid,
        coachName: 'Coach E2E5',
        createdAt: Timestamp.now(),
        config: TeamConfig(targetDays: 6, weights: {'consistency': 0.6, 'intensity': 0.4}),
      );
      String? teamId = await teamService.createTeam(team, coachUid);

      // Fallback: Manually create a team doc with minimal fields to satisfy rules (audit + team_code)
      if (teamId == null) {
        final manualTeamRef = firestore.collection('teams').doc();
        final manualTeamId = manualTeamRef.id;
        try {
          final teamData = {
            'name': 'E2E Team 5',
            'description': 'Reminders test',
            'coach_id': coachUid,
            'coach_name': 'Coach E2E5',
            'team_code': 'E2E5A1', // valid 6-char uppercase alnum
            'is_active': true,
            // audit (snake_case) with server timestamps to ensure equality and auth binding
            'created_by': coachUid,
            'updated_by': coachUid,
            'created_at': Timestamp.now(),
            'updated_at': Timestamp.now(),
          };
          await manualTeamRef.set(teamData);
          logWrite('team.create', 'teams/' + manualTeamId, teamData, auth);
          // ignore: avoid_print
          print('Manual team create OK: ' + manualTeamId);
        } catch (e) {
          // ignore: avoid_print
          print('Manual team create FAILED: ' + e.toString());
          rethrow;
        }
        teamId = manualTeamId;
      }

      expect(teamId, isNotNull, reason: 'Team must be created for reminders test');

      // Seed coach membership to satisfy isCoach(teamId, coachUid)
      await auth.signInWithEmailAndPassword(email: coachEmail, password: 'password123');
      try {
        final memberData = {
          'user_id': coachUid,
          'role': 'Coach',
          'status': 'approved',
          'is_owner': true,
          'created_by': auth.currentUser!.uid,
          'updated_by': auth.currentUser!.uid,
          'created_at': Timestamp.now(),
          'updated_at': Timestamp.now(),
        };
        await firestore.collection('teams').doc(teamId!).collection('members').doc(coachUid).set(memberData);
        logWrite('member.create', 'teams/' + teamId! + '/members/' + coachUid, memberData, auth);
        // verify coach role/status
        final coachMemberSnap = await firestore.collection('teams').doc(teamId!).collection('members').doc(coachUid).get();
        final coachMember = coachMemberSnap.data();
        debugPrint('Coach member doc: ' + (coachMember != null ? coachMember.toString() : '(null)'));
        // ignore: avoid_print
        print('Seed membership for coach ${coachUid} OK');
      } catch (e) {
        // ignore: avoid_print
        print('Seed membership for coach ${coachUid} FAILED: ' + e.toString());
      }

      // Sanity: try minimal program create (should require Coach + audit)
      await auth.signInWithEmailAndPassword(email: coachEmail, password: 'password123');
      try {
        final now = DateTime.now();
        final tsNow = Timestamp.fromDate(now);
        final programMin = {
          'createdBy': auth.currentUser!.uid,
          'updatedBy': auth.currentUser!.uid,
          'createdAt': Timestamp.now(),
          'updatedAt': Timestamp.now(),
        };
        await firestore.collection('teams').doc(teamId!).collection('programs').doc('prog-min').set(programMin);
        logWrite('program.create', 'teams/' + teamId! + '/programs/prog-min', programMin, auth);
        // ignore: avoid_print
        print('Program minimal create OK');
      } catch (e) {
        // ignore: avoid_print
        print('Program minimal create FAILED: ' + e.toString());
      }

      // Coach diagnostic: try minimal reminder create first (camelCase)
      await auth.signInWithEmailAndPassword(email: coachEmail, password: 'password123');
      try {
        final now = DateTime.now();
        final tsNow = Timestamp.fromDate(now);
        final reminderCoachMin = {
          'teamId': teamId,
          'dateTime': tsNow,
          'title': 'Coach Seed',
          'createdBy': auth.currentUser!.uid, 
          'updatedBy': auth.currentUser!.uid,
          'createdAt': Timestamp.now(), 
          'updatedAt': Timestamp.now(),
        };
        await firestore.collection('teams').doc(teamId!).collection('reminders').doc('rem-coach-min').set(reminderCoachMin);
        logWrite('reminder.create', 'teams/' + teamId! + '/reminders/rem-coach-min', reminderCoachMin, auth);
        // ignore: avoid_print
        print('Coach minimal reminder create OK');
      } catch (e) {
        // ignore: avoid_print
        print('Coach minimal reminder create FAILED: ' + e.toString());
      }

      // Coach diagnostic: try minimal reminder create with snake_case
      await auth.signInWithEmailAndPassword(email: coachEmail, password: 'password123');
      try {
        final now = DateTime.now();
        final tsNow = Timestamp.fromDate(now);
        final reminderCoachMinSnake = {
          'team_id': teamId,
          'date_time': tsNow,
          'title': 'Coach Seed snake',
          'created_by': auth.currentUser!.uid, 
          'updated_by': auth.currentUser!.uid,
          'created_at': Timestamp.now(), 
          'updated_at': Timestamp.now(),
        };
        await firestore.collection('teams').doc(teamId!).collection('reminders').doc('rem-coach-min-snake').set(reminderCoachMinSnake);
        logWrite('reminder.create', 'teams/' + teamId! + '/reminders/rem-coach-min-snake', reminderCoachMinSnake, auth);
        // ignore: avoid_print
        print('Coach minimal reminder (snake_case) create OK');
      } catch (e) {
        // ignore: avoid_print
        print('Coach minimal reminder (snake_case) create FAILED: ' + e.toString());
      }

      // Ensure athlete A and B users exist
      final athleteAUid = await ensureUser(athleteAEmail);
      final athleteBUid = await ensureUser(athleteBEmail);

      // Seed memberships: add athlete A and B to team as members (role athlete)
      await auth.signInWithEmailAndPassword(email: coachEmail, password: 'password123');
      for (final entry in [athleteAUid, athleteBUid]) {
        try {
          final athleteMemberData = {
        'user_id': entry,
        'role': 'Athlete',
        'status': 'approved',
        'is_owner': false,
        'created_by': auth.currentUser!.uid, 'updated_by': auth.currentUser!.uid,
        'created_at': Timestamp.now(), 'updated_at': Timestamp.now(),
      };
      await firestore.collection('teams').doc(teamId!).collection('members').doc(entry).set(athleteMemberData);
      logWrite('member.create', 'teams/' + teamId! + '/members/' + entry, athleteMemberData, auth);
      // verify membership exists
      final check = await firestore.collection('teams').doc(teamId!).collection('members').doc(entry).get();
      // ignore: avoid_print
      print('Membership for ' + entry + ' exists? ' + check.exists.toString());
      // ignore: avoid_print
      print('Seed membership for $entry OK');
        } catch (e) {
          // ignore: avoid_print
          print('Seed membership for $entry FAILED: ' + e.toString());
        }
      }

      // athlete A creates and edits own reminder
      await auth.signInWithEmailAndPassword(email: athleteAEmail, password: 'password123');
      
      // Debug: Check membership status
      try {
        final memberDoc = await firestore.collection('teams').doc(teamId!).collection('members').doc(athleteAUid).get();
        // ignore: avoid_print
        print('Athlete A membership exists: ${memberDoc.exists}');
        if (memberDoc.exists) {
          // ignore: avoid_print
          print('Athlete A membership data: ${memberDoc.data()}');
        }
      } catch (e) {
        // ignore: avoid_print
        print('Error checking membership: $e');
      }
      
      try {
        final tsMinCreate = Timestamp.now();
        final reminderMinData = {
          'team_id': teamId,
          'date_time': Timestamp.now(),
          'target_date': Timestamp.now(),
          'athlete_id': athleteAUid,
          'title': 'Minimal Athlete Reminder',
          'description': 'diagnostic full payload',
          'status': 'pending',
          'is_completed': false,
          'created_by': auth.currentUser!.uid, 
          'updated_by': auth.currentUser!.uid,
          'created_at': tsMinCreate, 
          'updated_at': tsMinCreate,
        };
        await firestore.collection('teams').doc(teamId!).collection('reminders').doc('rem-min').set(reminderMinData);
        logWrite('reminder.create', 'teams/' + teamId! + '/reminders/rem-min', reminderMinData, auth);
        // ignore: avoid_print
        print('Create minimal reminder OK');
      } catch (e) {
        // ignore: avoid_print
        print('Create minimal reminder FAILED: ' + e.toString());
        // Probe variants to isolate rule condition
        try {
          await firestore.collection('teams').doc(teamId!).collection('reminders').add({
            'team_id': teamId,
            'date_time': Timestamp.now(),
            'createdBy': auth.currentUser!.uid, 'updatedBy': auth.currentUser!.uid,
            'createdAt': Timestamp.now(), 'updatedAt': Timestamp.now(),
          });
          // ignore: avoid_print
          print('Variant: serverTimestamp audit (camelCase) PASSED');
        } catch (e2) {
          // ignore: avoid_print
          print('Variant: serverTimestamp audit (camelCase) FAILED: ' + e2.toString());
        }
        try {
          final tsSnakeCreate = Timestamp.now();
          final reminderSnakeAudit = {
            'team_id': teamId,
            'date_time': Timestamp.now(),
            'is_completed': false,
            'created_by': auth.currentUser!.uid, 
            'updated_by': auth.currentUser!.uid,
            'created_at': tsSnakeCreate, 
            'updated_at': tsSnakeCreate,
          };
          await firestore.collection('teams').doc(teamId!).collection('reminders').doc('rem-min-snake').set(reminderSnakeAudit);
          logWrite('reminder.create', 'teams/' + teamId! + '/reminders/rem-min-snake', reminderSnakeAudit, auth);
          // ignore: avoid_print
          print('Variant: snake_case audit PASSED');
        } catch (e3) {
          // ignore: avoid_print
          print('Variant: snake_case audit FAILED: ' + e3.toString());
        }
        try {
          final reminderDateCamel = {
            'team_id': teamId,
            'dateTime': Timestamp.now(),
            'createdBy': auth.currentUser!.uid, 'updatedBy': auth.currentUser!.uid,
            'createdAt': Timestamp.now(), 'updatedAt': Timestamp.now(),
          };
          await firestore.collection('teams').doc(teamId!).collection('reminders').doc('rem-min-dateCamel').set(reminderDateCamel);
          logWrite('reminder.create', 'teams/' + teamId! + '/reminders/rem-min-dateCamel', reminderDateCamel, auth);
          // ignore: avoid_print
          print('Variant: dateTime camelCase PASSED');
        } catch (e4) {
          // ignore: avoid_print
          print('Variant: dateTime camelCase FAILED: ' + e4.toString());
        }
        // continue without rethrow to allow subsequent checks
      }
      try {
        final tsNow = Timestamp.now();
        final reminderAData = {
          'team_id': teamId,
          'date_time': tsNow,
          'target_date': tsNow,
          'athlete_id': athleteAUid,
          'status': 'pending',
          'is_completed': false,
          'created_by': auth.currentUser!.uid, 
          'updated_by': auth.currentUser!.uid,
          'created_at': tsNow, 
          'updated_at': tsNow,
        };
        logWrite('reminder.create', 'teams/' + teamId! + '/reminders/rem-a2', reminderAData, auth);
        await firestore.collection('teams').doc(teamId!).collection('reminders').doc('rem-a2').set(reminderAData);
        // ignore: avoid_print
        print('Create athlete A reminder OK');
      } catch (e) {
        // ignore: avoid_print
        print('Create athlete A reminder FAILED: ' + e.toString());
        rethrow;
      }
      try {
        final reminderAUpdate = {
          'team_id': teamId,
          'athlete_id': athleteAUid,
          'title': 'Latihan Pagi Update',
          'updated_at': Timestamp.now(),
          'updated_by': athleteAUid,
          'date_time': Timestamp.now(),
          'target_date': Timestamp.now(),
        };
        await firestore.collection('teams').doc(teamId!).collection('reminders').doc('rem-a').update(reminderAUpdate);
        logWrite('reminder.update', 'teams/' + teamId! + '/reminders/rem-a', reminderAUpdate, auth);
        // ignore: avoid_print
        print('Update athlete A own reminder OK');
      } catch (e) {
        // ignore: avoid_print
        print('Update athlete A own reminder FAILED: ' + e.toString());
        rethrow;
      }

      final updateBByA = {
        'team_id': teamId,
        'athlete_id': athleteBUid,
        'title': 'Diubah oleh A',
        'updated_at': Timestamp.now(),
        'updated_by': athleteAUid,
        'date_time': Timestamp.now(),
        'target_date': Timestamp.now(),
      };
      logWrite('reminder.update-attempt', 'teams/' + teamId! + '/reminders/rem-b', updateBByA, auth);
      await expectLater(
        firestore.collection('teams').doc(teamId!).collection('reminders').doc('rem-b').update(updateBByA),
        throwsA(isA<FirebaseException>()),
      );

      // coach creates a minimal reminder first to validate rule behavior
      await auth.signInWithEmailAndPassword(email: coachEmail, password: 'password123');
      try {
        final nowCoach2 = DateTime.now();
        final tsCoachCreate = Timestamp.fromDate(nowCoach2);
        final reminderCoachMin2 = {
            'teamId': teamId,
            'dateTime': Timestamp.fromDate(nowCoach2),
            'targetDate': Timestamp.fromDate(nowCoach2),
            'title': 'Coach Seed',
            'description': 'minimal by coach',
            'status': 'pending',
            'isCompleted': false,
            'athleteId': athleteAUid,
            'createdBy': auth.currentUser!.uid, 
            'updatedBy': auth.currentUser!.uid,
            'createdAt': Timestamp.now(), 
            'updatedAt': Timestamp.now(),
          };
        await firestore.collection('teams').doc(teamId!).collection('reminders').doc('rem-coach-min').set(reminderCoachMin2);
        logWrite('reminder.create', 'teams/' + teamId! + '/reminders/rem-coach-min', reminderCoachMin2, auth);
        // ignore: avoid_print
        print('Coach minimal reminder create OK');
      } catch (e) {
        // ignore: avoid_print
        print('Coach minimal reminder create FAILED: ' + e.toString());
      }

      // athlete A creates and edits own reminder
      await auth.signInWithEmailAndPassword(email: athleteAEmail, password: 'password123');
      try {
        final nowA = DateTime.now();
        final tsCreate = Timestamp.fromDate(nowA);
        final reminderAData = {
          'teamId': teamId,
          'title': 'Reminder A',
          'description': 'Test reminder for athlete A',
          'dateTime': Timestamp.now(),
          'targetDate': Timestamp.now(),
          'athleteId': athleteAUid,
          'status': 'pending',
          'isCompleted': false,
          'createdBy': auth.currentUser!.uid, 
          'updatedBy': auth.currentUser!.uid,
          'createdAt': Timestamp.now(), 
          'updatedAt': Timestamp.now(),
        };
        await firestore.collection('teams').doc(teamId!).collection('reminders').doc('rem-a2').set(reminderAData);
        logWrite('reminder.create', 'teams/' + teamId! + '/reminders/rem-a2', reminderAData, auth);
        // ignore: avoid_print
        print('Create athlete A reminder OK');
      } catch (e) {
        // ignore: avoid_print
        print('Create athlete A reminder FAILED: ' + e.toString());
        rethrow;
      }
      try {
        final reminderAUpdate = {
          'team_id': teamId,
          'athlete_id': athleteAUid,
          'title': 'Latihan Pagi Update',
          'updated_at': Timestamp.now(),
          'updated_by': athleteAUid,
          'date_time': Timestamp.now(),
          'target_date': Timestamp.now(),
        };
        await firestore.collection('teams').doc(teamId!).collection('reminders').doc('rem-a2').update(reminderAUpdate);
        logWrite('reminder.update', 'teams/' + teamId! + '/reminders/rem-a2', reminderAUpdate, auth);
        // ignore: avoid_print
        print('Update athlete A own reminder OK');
      } catch (e) {
        // ignore: avoid_print
        print('Update athlete A own reminder FAILED: ' + e.toString());
        rethrow;
      }

      final updateBByA2 = {
        'team_id': teamId,
        'athlete_id': athleteBUid,
        'title': 'Diubah oleh A',
        'updated_at': Timestamp.now(),
        'updated_by': athleteAUid,
        'date_time': Timestamp.now(),
        'target_date': Timestamp.now(),
      };
      logWrite('reminder.update-attempt', 'teams/' + teamId! + '/reminders/rem-b', updateBByA2, auth);
      await expectLater(
        firestore.collection('teams').doc(teamId!).collection('reminders').doc('rem-b').update(updateBByA2),
        throwsA(isA<FirebaseException>()),
      );

      // coach creates reminder for athlete A
      await auth.signInWithEmailAndPassword(email: coachEmail, password: 'password123');
      await expectLater(
        () async {
          final nowCoach = DateTime.now();
          final tsCreateCoach = Timestamp.fromDate(nowCoach);
          return firestore.collection('teams').doc(teamId!).collection('reminders').add({
             'teamId': teamId,
             // gunakan camelCase dan timestamp nyata sesuai test terdahulu
             'dateTime': Timestamp.fromDate(nowCoach),
             'targetDate': Timestamp.fromDate(nowCoach),
             'title': 'Tes HRR', 'description': 'Latihan HRR 20 menit',
             'athleteId': athleteAUid,
             'status': 'pending',
             'isCompleted': false,
             'createdBy': auth.currentUser!.uid, 
             'updatedBy': auth.currentUser!.uid,
             'createdAt': tsCreateCoach, 
             'updatedAt': tsCreateCoach,
           });
         }(),
        completes,
      );
    });
  });
}

Future<void> _signOutIfNeeded(FirebaseAuth auth) async {
  try {
    await auth.signOut();
  } catch (_) {}
}
