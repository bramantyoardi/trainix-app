import 'dart:io' show Platform;
import 'package:flutter/widgets.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_app_check/firebase_app_check.dart';

import 'package:trainix_app/firebase_options.dart';

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('Batch D – Owner, Join Policy, Approval, Delete (E2E)', () {
    late FirebaseFirestore firestore;
    late FirebaseAuth auth;

    // Users: owner coach, other coach (non-owner), athlete
    final owner = {'email': 'owner@test.com', 'password': 'password123', 'name': 'Owner Coach'};
    final coach = {'email': 'coach2@test.com', 'password': 'password123', 'name': 'Second Coach'};
    final athlete = {'email': 'athlete@test.com', 'password': 'password123', 'name': 'Athlete User'};

    setUpAll(() async {
      // Ensure Flutter bindings before any Firebase calls
      WidgetsFlutterBinding.ensureInitialized();

      await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

      // Clear Firestore persistence very early to avoid stale caches interfering with emulator
      try {
        await FirebaseFirestore.instance.clearPersistence();
      } catch (_) {}

      // Activate App Check in debug mode for emulator/testing
      try {
        await FirebaseAppCheck.instance.activate(androidProvider: AndroidProvider.debug, appleProvider: AppleProvider.debug);
      } catch (_) {}

      firestore = FirebaseFirestore.instance;
      auth = FirebaseAuth.instance;
      try {
        final host = Platform.isAndroid ? '10.0.2.2' : '127.0.0.1';
        const firestorePort = int.fromEnvironment('EMU_FIRESTORE_PORT', defaultValue: 8080);
        const authPort = int.fromEnvironment('EMU_AUTH_PORT', defaultValue: 9099);
        firestore.useFirestoreEmulator(host, firestorePort);
        await auth.useAuthEmulator(host, authPort);
        print('Using emulator for Auth/Firestore at host=' + host);
      } catch (e) {
        print('Emulator not available, using production: ' + e.toString());
      }
 
      // Create users
      Future<void> ensureUser(Map<String, String> u) async {
        try {
          await auth.createUserWithEmailAndPassword(email: u['email']!, password: u['password']!);
          await auth.currentUser?.updateDisplayName(u['name']);
          await firestore.collection('users').doc(auth.currentUser!.uid).set({
            'name': u['name'], 'email': u['email'], 'created_at': FieldValue.serverTimestamp(),
          });
          await auth.signOut();
        } catch (e) {
          // ignore if already exists
          print('ensureUser error for ' + (u['email'] ?? 'unknown') + ': ' + e.toString());
        }
      }
      await ensureUser(owner);
      await ensureUser(coach);
      await ensureUser(athlete);
    });

    tearDownAll(() async {
      // Delete created teams and memberships
      final teams = await firestore.collection('teams').where('name', isEqualTo: 'BatchD Team').get();
      for (final t in teams.docs) {
        final members = await t.reference.collection('members').get();
        for (final m in members.docs) { await m.reference.delete(); }
        await t.reference.delete();
      }
      // Leave auth signed out
      try { await auth.signOut(); } catch (_) {}
    });

    Future<String> createTeam({required String joinPolicy}) async {
      // Sign in as owner
      await auth.signInWithEmailAndPassword(email: owner['email']!, password: owner['password']!);
      final ownerUid = auth.currentUser!.uid;

      // DEBUG: log current user and a read probe to confirm auth context reaches Firestore rules
      print('[DEBUG] Owner signed in as: ' + (auth.currentUser?.uid ?? 'null'));
      try {
        final probe = await firestore.collection('teams').doc('__probe__').get();
        print('[DEBUG] Owner probe read allowed (exists=${probe.exists})');
      } catch (e) {
        print('[DEBUG] Owner probe read failed: ' + e.toString());
      }

      final teamRef = firestore.collection('teams').doc();
      await teamRef.set({
        'name': 'BatchD Team',
        'description': 'Batch D policies test',
        'join_policy': joinPolicy,
        'team_code': 'ABC123',
        'member_count': 1,
        'pending_count': 0,
        'coach_count': 1,
        'is_active': true,
        'coach_id': ownerUid,
        'coach_name': owner['name'],
        'created_at': FieldValue.serverTimestamp(),
        'created_by': ownerUid,
        'updated_at': FieldValue.serverTimestamp(),
        'updated_by': ownerUid,
      });
      await teamRef.collection('members').doc(ownerUid).set({
        'user_id': ownerUid,
        'team_id': teamRef.id,
        'role': 'Coach',
        'status': 'approved',
        'is_owner': true,
        'is_active': true,
        'joined_at': FieldValue.serverTimestamp(),
        'created_at': FieldValue.serverTimestamp(),
        'created_by': ownerUid,
      });
      return teamRef.id;
    }

    Future<Map<String, String>> signInAll() async {
      await auth.signInWithEmailAndPassword(email: owner['email']!, password: owner['password']!);
      final ownerUid = auth.currentUser!.uid;
      await auth.signInWithEmailAndPassword(email: coach['email']!, password: coach['password']!);
      final coachUid = auth.currentUser!.uid;
      await auth.signInWithEmailAndPassword(email: athlete['email']!, password: athlete['password']!);
      final athleteUid = auth.currentUser!.uid;
      await auth.signOut(); // leave neutral
      return {'ownerUid': ownerUid, 'coachUid': coachUid, 'athleteUid': athleteUid};
    }

    Future<void> verifyCounters(String teamId) async {
      final teamDoc = await firestore.collection('teams').doc(teamId).get();
      final members = await firestore.collection('teams').doc(teamId).collection('members').get();
      final approved = members.docs.where((m) => m.data()['status'] == 'approved' && (m.data()['is_active'] == true)).length;
      final pending = members.docs.where((m) => m.data()['status'] == 'pending').length;
      final coaches = members.docs.where((m) => m.data()['role'] == 'Coach' && m.data()['status'] == 'approved' && (m.data()['is_active'] == true)).length;
      final data = teamDoc.data()!;
      expect(data['member_count'], approved);
      expect(data['pending_count'], pending);
      expect(data['coach_count'], coaches);
    }

    testWidgets('A. Owner-only join_policy update; non-owner coach denied', (tester) async {
      final teamId = await createTeam(joinPolicy: 'ask_to_join');
      final ids = await signInAll();

      // Owner updates policy OK
      await auth.signInWithEmailAndPassword(email: owner['email']!, password: owner['password']!);
      try {
        await firestore.collection('teams').doc(teamId).update({'join_policy': 'open', 'updated_at': FieldValue.serverTimestamp()});
      } catch (e) {
        fail('Owner should be able to update join_policy: $e');
      }

      // Add non-owner coach to team
      await auth.signInWithEmailAndPassword(email: coach['email']!, password: coach['password']!);
      final coachUid = ids['coachUid']!;
      await firestore.collection('teams').doc(teamId).collection('members').doc(coachUid).set({
        'user_id': coachUid,
        'team_id': teamId,
        'role': 'Coach',
        'status': 'approved',
        'is_owner': false,
        'is_active': true,
        'joined_at': FieldValue.serverTimestamp(),
        'created_at': FieldValue.serverTimestamp(),
        'created_by': coachUid,
      });

      // Non-owner coach attempts to update policy -> denied
      try {
        await firestore.collection('teams').doc(teamId).update({'join_policy': 'closed'});
        fail('Non-owner coach should NOT be able to update join_policy');
      } catch (e) {
        expect(e.toString().contains('permission-denied'), true);
      }
    });

    testWidgets('B. Ask-to-join: athlete pending; coach approves', (tester) async {
      final teamId = await createTeam(joinPolicy: 'ask_to_join');
      final ids = await signInAll();

      // Athlete self-create pending membership
      await auth.signInWithEmailAndPassword(email: athlete['email']!, password: athlete['password']!);
      final athleteUid = ids['athleteUid']!;
      await firestore.collection('teams').doc(teamId).collection('members').doc(athleteUid).set({
        'user_id': athleteUid,
        'team_id': teamId,
        'role': 'Athlete',
        'status': 'pending',
        'is_owner': false,
        'is_active': true,
        'joined_at': FieldValue.serverTimestamp(),
        'created_at': FieldValue.serverTimestamp(),
        'created_by': athleteUid,
      });

      // Non-owner coach approves (allowed)
      await auth.signInWithEmailAndPassword(email: coach['email']!, password: coach['password']!);
      // Ensure coach is a team coach (approved, non-owner)
      final coachUid = ids['coachUid']!;
      await firestore.collection('teams').doc(teamId).collection('members').doc(coachUid).set({
        'user_id': coachUid,
        'team_id': teamId,
        'role': 'Coach',
        'status': 'approved',
        'is_owner': false,
        'is_active': true,
        'joined_at': FieldValue.serverTimestamp(),
      });
      try {
        await firestore.collection('teams').doc(teamId).collection('members').doc(athleteUid).update({
          'status': 'approved',
          'approved_by': auth.currentUser!.uid,
          'updated_at': FieldValue.serverTimestamp(),
          'updated_by': auth.currentUser!.uid,
          'is_active': true,
        });
      } catch (e) {
        fail('Coach should be able to approve pending member: $e');
      }
      await verifyCounters(teamId);
    });

    testWidgets('C. Delete: owner deletes non-owner; cannot delete owner; self-leave rules', (tester) async {
      final teamId = await createTeam(joinPolicy: 'open');
      final ids = await signInAll();
      final ownerUid = ids['ownerUid']!;
      final coachUid = ids['coachUid']!;
      final athleteUid = ids['athleteUid']!;

      // Add coach (non-owner) and athlete approved
      await auth.signInWithEmailAndPassword(email: coach['email']!, password: coach['password']!);
      await firestore.collection('teams').doc(teamId).collection('members').doc(coachUid).set({
        'user_id': coachUid,
        'team_id': teamId,
        'role': 'Coach',
        'status': 'approved',
        'is_owner': false,
        'is_active': true,
        'joined_at': FieldValue.serverTimestamp(),
      });
      await auth.signInWithEmailAndPassword(email: athlete['email']!, password: athlete['password']!);
      await firestore.collection('teams').doc(teamId).collection('members').doc(athleteUid).set({
        'user_id': athleteUid,
        'team_id': teamId,
        'role': 'Athlete',
        'status': 'approved',
        'is_owner': false,
        'is_active': true,
        'joined_at': FieldValue.serverTimestamp(),
      });

      // Owner deletes non-owner coach (allowed)
      await auth.signInWithEmailAndPassword(email: owner['email']!, password: owner['password']!);
      try {
        await firestore.collection('teams').doc(teamId).collection('members').doc(coachUid).delete();
      } catch (e) {
        fail('Owner should be able to delete non-owner member: $e');
      }

      // Owner tries to delete another owner (denied)
      // Create a second owner (setup to test denial)
      await firestore.collection('teams').doc(teamId).collection('members').doc('tempOwner').set({
        'user_id': 'tempOwner',
        'team_id': teamId,
        'role': 'Coach',
        'status': 'approved',
        'is_owner': true,
        'is_active': true,
        'joined_at': FieldValue.serverTimestamp(),
      });
      try {
        await firestore.collection('teams').doc(teamId).collection('members').doc('tempOwner').delete();
        fail('Deleting an owner should be explicitly denied');
      } catch (e) {
        expect(e.toString().contains('permission-denied'), true);
      }

      // Self-leave allowed for coach/athlete
      await auth.signInWithEmailAndPassword(email: athlete['email']!, password: athlete['password']!);
      try {
        await firestore.collection('teams').doc(teamId).collection('members').doc(athleteUid).delete();
      } catch (e) {
        fail('Athlete should be able to self-leave: $e');
      }

      // Self-leave denied for owner
      await auth.signInWithEmailAndPassword(email: owner['email']!, password: owner['password']!);
      try {
        await firestore.collection('teams').doc(teamId).collection('members').doc(ownerUid).delete();
        fail('Owner self-leave must be denied');
      } catch (e) {
        expect(e.toString().contains('permission-denied'), true);
      }

      await verifyCounters(teamId);
    });
  });
}