import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_app_check/firebase_app_check.dart';

import 'package:trainix_app/main.dart' as app;
import 'package:trainix_app/firebase_options.dart';

import 'dart:io' show Platform;

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('Team Management E2E Tests (v1.3)', () {
    late FirebaseFirestore firestore;
    late FirebaseAuth auth;
    
    // Test users
    final testUsers = [
      {'email': 'coach@test.com', 'password': 'password123', 'name': 'Test Coach'},
      {'email': 'athlete1@test.com', 'password': 'password123', 'name': 'Test Athlete 1'},
      {'email': 'athlete2@test.com', 'password': 'password123', 'name': 'Test Athlete 2'},
      {'email': 'athlete3@test.com', 'password': 'password123', 'name': 'Test Athlete 3'},
    ];

    setUpAll(() async {
      // Ensure Flutter bindings before any Firebase calls
      WidgetsFlutterBinding.ensureInitialized();
    
      await Firebase.initializeApp(
        options: DefaultFirebaseOptions.currentPlatform,
      );
      
      firestore = FirebaseFirestore.instance;
      auth = FirebaseAuth.instance;
      
      // Use emulator only when explicitly enabled via dart-define
      const useEmu = bool.fromEnvironment('USE_FIREBASE_EMULATOR', defaultValue: false);
      if (useEmu) {
        final host = Platform.isAndroid ? '10.0.2.2' : '127.0.0.1';
        const firestorePort = int.fromEnvironment('EMU_FIRESTORE_PORT', defaultValue: 8080);
        const authPort = int.fromEnvironment('EMU_AUTH_PORT', defaultValue: 9099);
        firestore.useFirestoreEmulator(host, firestorePort);
        await auth.useAuthEmulator(host, authPort);
        print('Using emulator for Auth/Firestore at host=' + host + ' ports fs=' + firestorePort.toString() + ' auth=' + authPort.toString());
      } else {
        print('Using PRODUCTION backend for Auth/Firestore');
      }
      
      // App Check debug (prevent reCAPTCHA/App Check prompts when tests accidentally hit prod)
      // NOTE: Disable App Check activation during emulator tests to avoid placeholder/too-many-attempts issues
      // await FirebaseAppCheck.instance.activate(
      //   androidProvider: AndroidProvider.debug,
      //   appleProvider: AppleProvider.debug,
      // );

      // Ensure clean Firestore state across test runs
      await firestore.clearPersistence();
      
      // Create test users
      for (final user in testUsers) {
        try {
          await auth.createUserWithEmailAndPassword(
            email: user['email']!,
            password: user['password']!,
          );
          
          // Update display name
          await auth.currentUser?.updateDisplayName(user['name']);
          
          // Create user profile in Firestore
          await firestore.collection('users').doc(auth.currentUser!.uid).set({
            'name': user['name'],
            'email': user['email'],
            'created_at': FieldValue.serverTimestamp(),
          });
          
          await auth.signOut();
        } catch (e) {
          print('User ${user['email']} might already exist: ' + e.toString());
        }
      }
    });

    tearDownAll(() async {
      // Allow skipping cleanup to preserve production snapshot
      const skipCleanup = bool.fromEnvironment('SKIP_CLEANUP', defaultValue: false);
      if (skipCleanup) {
        print('[E2E] SKIP_CLEANUP=true — preserving test data in production for snapshot');
        return;
      }
      // Clean up test data
      try {
        // Delete test teams
        final teams = await firestore.collection('teams')
            .where('name', whereIn: ['Test Team Open', 'Test Team Ask', 'Test Team Closed'])
            .get();
        
        for (final doc in teams.docs) {
          // Delete members subcollection
          final members = await doc.reference.collection('members').get();
          for (final member in members.docs) {
            await member.reference.delete();
          }
          // Delete team
          await doc.reference.delete();
        }
        
        // Delete test users
        for (final user in testUsers) {
          try {
            await auth.signInWithEmailAndPassword(
              email: user['email']!,
              password: user['password']!,
            );
            
            // Delete user profile
            await firestore.collection('users').doc(auth.currentUser!.uid).delete();
            
            // Delete auth user
            await auth.currentUser?.delete();
          } catch (e) {
            print('Error deleting user ${user['email']}: $e');
          }
        }
      } catch (e) {
        print('Cleanup error: $e');
      }
    });

    // Helper function to verify team counts
    Future<void> verifyTeamCounts(String teamId) async {
      final teamDoc = await firestore.collection('teams').doc(teamId).get();
      final members = await firestore.collection('teams').doc(teamId).collection('members').get();

      final approved = members.docs.where((m) => m.data()['status'] == 'approved').length;
      final pending = members.docs.where((m) => m.data()['status'] == 'pending').length;
      final coaches = members.docs.where((m) => m.data()['role'] == 'Coach' && m.data()['status'] == 'approved').length;

      final teamData = teamDoc.data()!;
      expect(teamData['member_count'], approved, reason: 'Member count mismatch');
      expect(teamData['pending_count'], pending, reason: 'Pending count mismatch');
      expect(teamData['coach_count'], coaches, reason: 'Coach count mismatch');
    }

    // Helper function to create team with specific join policy
    Future<String> createTestTeam(String name, String joinPolicy) async {
      // Sign in as coach
      await auth.signInWithEmailAndPassword(
        email: testUsers[0]['email']!,
        password: testUsers[0]['password']!,
      );

      // DEBUG: log current user and a read probe to confirm auth context reaches Firestore rules
      print('[DEBUG] Signed in as: ' + (auth.currentUser?.uid ?? 'null'));

      // Ensure auth token is fully propagated to Firestore rules before making writes
      try {
        await auth.currentUser?.getIdToken();
      } catch (_) {}
      // Probe loop: try up to 5 times to confirm authenticated reads are permitted
      bool probeOk = false;
      for (int i = 0; i < 5; i++) {
        try {
          final probe = await firestore.collection('teams').doc('__probe__').get();
          print('[DEBUG] Probe read allowed (exists=' + probe.exists.toString() + ')');
          probeOk = true;
          break;
        } catch (e) {
          print('[DEBUG] Probe read failed attempt ' + (i+1).toString() + ': ' + e.toString());
          await Future.delayed(const Duration(milliseconds: 200));
        }
      }
      if (!probeOk) {
        // As a fallback, wait a bit more to allow auth context to sync
        await Future.delayed(const Duration(milliseconds: 400));
      }

      final teamRef = firestore.collection('teams').doc();
      try {
        await teamRef.set({
          'name': name,
          'description': 'Test team for $joinPolicy policy',
          'coach_id': auth.currentUser!.uid,
          'coach_name': testUsers[0]['name'],
          'join_policy': joinPolicy,
          'member_count': 1, // Coach is initial member
          'pending_count': 0,
          'coach_count': 1,
          'is_active': true,
          'max_members': 50,
          'created_at': FieldValue.serverTimestamp(),
          'created_by': auth.currentUser!.uid,
          'updated_at': FieldValue.serverTimestamp(),
          'updated_by': auth.currentUser!.uid,
        });
      } catch (e) {
        print('[DEBUG] teamRef.set failed: ' + e.toString() + ' — retrying after short delay');
        await Future.delayed(const Duration(milliseconds: 500));
        await teamRef.set({
          'name': name,
          'description': 'Test team for $joinPolicy policy',
          'coach_id': auth.currentUser!.uid,
          'coach_name': testUsers[0]['name'],
          'join_policy': joinPolicy,
          'member_count': 1,
          'pending_count': 0,
          'coach_count': 1,
          'is_active': true,
          'max_members': 50,
          'created_at': FieldValue.serverTimestamp(),
          'created_by': auth.currentUser!.uid,
          'updated_at': FieldValue.serverTimestamp(),
          'updated_by': auth.currentUser!.uid,
        });
      }

      // Beri jeda singkat agar dokumen team terkomit sebelum membuat membership owner
      await Future.delayed(const Duration(milliseconds: 300));

      // Create owner membership
      await teamRef.collection('members').doc(auth.currentUser!.uid).set({
        'user_id': auth.currentUser!.uid,
        'team_id': teamRef.id,
        'role': 'Coach',
        'status': 'approved',
        'is_owner': true,
        'is_active': true,
        'joined_at': FieldValue.serverTimestamp(),
        'created_at': FieldValue.serverTimestamp(),
        'created_by': auth.currentUser!.uid,
        // Ensure updated_at to satisfy Functions counters sync
        'updated_at': FieldValue.serverTimestamp(),
        'updated_by': auth.currentUser!.uid,
      });

      return teamRef.id;
    }

    testWidgets('A. Join Policy - Open Mode', (WidgetTester tester) async {
      // Create team with open policy
      final teamId = await createTestTeam('Test Team Open', 'open');
      
      // Sign in as athlete
      await auth.signInWithEmailAndPassword(
        email: testUsers[1]['email']!,
        password: testUsers[1]['password']!,
      );

      // Athlete joins team directly
      await firestore.collection('teams').doc(teamId).collection('members')
          .doc(auth.currentUser!.uid).set({
        'user_id': auth.currentUser!.uid,
        'team_id': teamId,
        'role': 'Athlete',
        'status': 'approved', // Should be auto-approved for open policy
        'is_owner': false,
        'is_active': true,
        'joined_at': FieldValue.serverTimestamp(),
        'created_at': FieldValue.serverTimestamp(),
        'created_by': auth.currentUser!.uid,
      });

      // Update team counts
      await firestore.collection('teams').doc(teamId).update({
        'member_count': FieldValue.increment(1),
        'updated_at': FieldValue.serverTimestamp(),
      });

      // Verify member status is approved
      final memberDoc = await firestore.collection('teams').doc(teamId)
          .collection('members').doc(auth.currentUser!.uid).get();
      
      expect(memberDoc.exists, true);
      expect(memberDoc.data()!['status'], 'approved');
      expect(memberDoc.data()!['role'], 'Athlete');

      // Verify team counts
      await verifyTeamCounts(teamId);
    });

    testWidgets('A. Join Policy - Ask to Join Mode', (WidgetTester tester) async {
      // Create team with ask_to_join policy
      final teamId = await createTestTeam('Test Team Ask', 'ask_to_join');
      
      // Sign in as athlete
      await auth.signInWithEmailAndPassword(
        email: testUsers[1]['email']!,
        password: testUsers[1]['password']!,
      );

      final athleteUid = auth.currentUser!.uid;

      // Athlete requests to join team
      await firestore.collection('teams').doc(teamId).collection('members')
          .doc(athleteUid).set({
        'user_id': athleteUid,
        'team_id': teamId,
        'role': 'Athlete',
        'status': 'pending', // Should be pending for ask_to_join policy
        'is_owner': false,
        'is_active': true,
        'joined_at': FieldValue.serverTimestamp(),
        'created_at': FieldValue.serverTimestamp(),
        'created_by': athleteUid,
      });

      // Update team counts
      // Sign in kembali sebagai coach karena update tim hanya boleh oleh Coach/Owner sesuai rules
      await auth.signInWithEmailAndPassword(
        email: testUsers[0]['email']!,
        password: testUsers[0]['password']!,
      );
      await firestore.collection('teams').doc(teamId).update({
        'pending_count': FieldValue.increment(1),
        'updated_at': FieldValue.serverTimestamp(),
      });

      // Verify member status is pending
      final memberDoc = await firestore.collection('teams').doc(teamId)
          .collection('members').doc(athleteUid).get();
      
      expect(memberDoc.exists, true);
      expect(memberDoc.data()!['status'], 'pending');

      // Coach approves the request
      await auth.signInWithEmailAndPassword(
        email: testUsers[0]['email']!,
        password: testUsers[0]['password']!,
      );

      await firestore.collection('teams').doc(teamId).collection('members')
          .doc(athleteUid).update({
        'status': 'approved',
        'approved_by': auth.currentUser!.uid,
        'updated_at': FieldValue.serverTimestamp(),
      });

      // Update team counts
      await firestore.collection('teams').doc(teamId).update({
        'member_count': FieldValue.increment(1),
        'pending_count': FieldValue.increment(-1),
        'updated_at': FieldValue.serverTimestamp(),
      });

      // Verify counts after approval
      await verifyTeamCounts(teamId);
    });

    testWidgets('A. Join Policy - Closed Mode', (WidgetTester tester) async {
      // Create team with closed policy
      final teamId = await createTestTeam('Test Team Closed', 'closed');
      
      // Sign in as athlete
      await auth.signInWithEmailAndPassword(
        email: testUsers[1]['email']!,
        password: testUsers[1]['password']!,
      );

      // Attempt to join closed team should fail
      try {
        await firestore.collection('teams').doc(teamId).collection('members')
            .doc(auth.currentUser!.uid).set({
          'user_id': auth.currentUser!.uid,
          'team_id': teamId,
          'role': 'Athlete',
          'status': 'pending',
          'is_owner': false,
          'is_active': true,
          'joined_at': FieldValue.serverTimestamp(),
          'created_at': FieldValue.serverTimestamp(),
          'created_by': auth.currentUser!.uid,
        });
        
        // This should fail due to Firestore rules
        fail('Expected join to be rejected for closed team');
      } catch (e) {
        expect(e.toString().contains('permission-denied'), true);
      }
    });

    testWidgets('B. Role Management - Promote Athlete to Coach', (WidgetTester tester) async {
      // Create team
      final teamId = await createTestTeam('Test Team Role', 'open');
      
      // Add athlete
      await auth.signInWithEmailAndPassword(
        email: testUsers[1]['email']!,
        password: testUsers[1]['password']!,
      );
      
      final athleteUid = auth.currentUser!.uid;
      
      await firestore.collection('teams').doc(teamId).collection('members')
          .doc(athleteUid).set({
        'user_id': athleteUid,
        'team_id': teamId,
        'role': 'Athlete',
        'status': 'approved',
        'is_owner': false,
        'is_active': true,
        'joined_at': FieldValue.serverTimestamp(),
        'created_at': FieldValue.serverTimestamp(),
        'created_by': athleteUid,
      });

      // Owner promotes athlete to coach
      await auth.signInWithEmailAndPassword(
        email: testUsers[0]['email']!,
        password: testUsers[0]['password']!,
      );

      await firestore.collection('teams').doc(teamId).collection('members')
          .doc(athleteUid).update({
        'role': 'Coach',
        'updated_at': FieldValue.serverTimestamp(),
        'updated_by': auth.currentUser!.uid,
      });

      // Update team coach count
      await firestore.collection('teams').doc(teamId).update({
        'coach_count': FieldValue.increment(1),
        'updated_at': FieldValue.serverTimestamp(),
      });

      // Verify promotion
      final memberDoc = await firestore.collection('teams').doc(teamId)
          .collection('members').doc(athleteUid).get();
      
      expect(memberDoc.data()!['role'], 'Coach');
      
      // Verify team counts
      await verifyTeamCounts(teamId);
    });

    testWidgets('B. Role Management - Demote Coach to Athlete', (WidgetTester tester) async {
      // Create team
      final teamId = await createTestTeam('Test Team Demote', 'open');
      
      // Add coach (not owner)
      await auth.signInWithEmailAndPassword(
        email: testUsers[1]['email']!,
        password: testUsers[1]['password']!,
      );
      
      final coachUid = auth.currentUser!.uid;
      
      await firestore.collection('teams').doc(teamId).collection('members')
          .doc(coachUid).set({
        'user_id': coachUid,
        'team_id': teamId,
        'role': 'Coach',
        'status': 'approved',
        'is_owner': false,
        'is_active': true,
        'joined_at': FieldValue.serverTimestamp(),
        'created_at': FieldValue.serverTimestamp(),
        'created_by': coachUid,
      });

      // Update initial coach count
      await firestore.collection('teams').doc(teamId).update({
        'coach_count': 2, // Owner + new coach
        'member_count': 2,
      });

      // Owner demotes coach to athlete
      await auth.signInWithEmailAndPassword(
        email: testUsers[0]['email']!,
        password: testUsers[0]['password']!,
      );

      await firestore.collection('teams').doc(teamId).collection('members')
          .doc(coachUid).update({
        'role': 'Athlete',
        'updated_at': FieldValue.serverTimestamp(),
        'updated_by': auth.currentUser!.uid,
      });

      // Update team coach count
      await firestore.collection('teams').doc(teamId).update({
        'coach_count': FieldValue.increment(-1),
        'updated_at': FieldValue.serverTimestamp(),
      });

      // Verify demotion
      final memberDoc = await firestore.collection('teams').doc(teamId)
          .collection('members').doc(coachUid).get();
      
      expect(memberDoc.data()!['role'], 'Athlete');
      
      // Verify team counts
      await verifyTeamCounts(teamId);
    });

    testWidgets('B. Role Management - Self-promotion/demotion should fail', (WidgetTester tester) async {
      // Create team
      final teamId = await createTestTeam('Test Team Self', 'open');
      
      // Add athlete
      await auth.signInWithEmailAndPassword(
        email: testUsers[1]['email']!,
        password: testUsers[1]['password']!,
      );
      
      final athleteUid = auth.currentUser!.uid;
      
      await firestore.collection('teams').doc(teamId).collection('members')
          .doc(athleteUid).set({
        'user_id': athleteUid,
        'team_id': teamId,
        'role': 'Athlete',
        'status': 'approved',
        'is_owner': false,
        'is_active': true,
        'joined_at': FieldValue.serverTimestamp(),
        'created_at': FieldValue.serverTimestamp(),
        'created_by': athleteUid,
      });

      // Athlete tries to promote themselves
      try {
        await firestore.collection('teams').doc(teamId).collection('members')
            .doc(athleteUid).update({
          'role': 'Coach',
          'updated_at': FieldValue.serverTimestamp(),
          'updated_by': athleteUid,
        });
        
        // This should fail due to Firestore rules
        fail('Expected self-promotion to be rejected');
      } catch (e) {
        expect(e.toString().contains('permission-denied'), true);
      }
    });

    testWidgets('C. Member Count Sync - Complex scenario', (WidgetTester tester) async {
      // Create team
      final teamId = await createTestTeam('Test Team Counts', 'ask_to_join');
      
      // Add 3 approved members + 1 pending
      final memberUids = <String>[];
      
      for (int i = 1; i <= 4; i++) {
        await auth.signInWithEmailAndPassword(
          email: testUsers[i % testUsers.length]['email']!,
          password: testUsers[i % testUsers.length]['password']!,
        );
        
        final uid = auth.currentUser!.uid;
        memberUids.add(uid);
        
        // Ask-to-join policy: self-create must be pending
        await firestore.collection('teams').doc(teamId).collection('members')
            .doc(uid).set({
          'user_id': uid,
          'team_id': teamId,
          'role': 'Athlete',
          'status': 'pending',
          'is_owner': false,
          'is_active': true,
          'joined_at': FieldValue.serverTimestamp(),
          'created_at': FieldValue.serverTimestamp(),
          'created_by': uid,
        });
      }

      // Owner approves first 3 pending members
      await auth.signInWithEmailAndPassword(
        email: testUsers[0]['email']!,
        password: testUsers[0]['password']!,
      );
      for (int j = 0; j < 3; j++) {
        await firestore.collection('teams').doc(teamId).collection('members')
            .doc(memberUids[j]).update({
          'status': 'approved',
          'approved_by': auth.currentUser!.uid,
          'updated_at': FieldValue.serverTimestamp(),
          'updated_by': auth.currentUser!.uid,
        });
      }

      // Update team counts to reflect 1 coach + 3 approved athletes + 1 pending
      await firestore.collection('teams').doc(teamId).update({
        'member_count': 4,
        'pending_count': 1,
        'coach_count': 1,
      });

      // Verify initial counts
      // Sign in as owner to ensure member read permissions for counts verification
      await auth.signInWithEmailAndPassword(
        email: testUsers[0]['email']!,
        password: testUsers[0]['password']!,
      );
      await verifyTeamCounts(teamId);

      // Approve pending member
      await auth.signInWithEmailAndPassword(
        email: testUsers[0]['email']!,
        password: testUsers[0]['password']!,
      );

      await firestore.collection('teams').doc(teamId).collection('members')
          .doc(memberUids.last).update({
        'status': 'approved',
        'approved_by': auth.currentUser!.uid,
        'updated_at': FieldValue.serverTimestamp(),
      });

      // Update counts after approval
      await firestore.collection('teams').doc(teamId).update({
        'member_count': FieldValue.increment(1),
        'pending_count': FieldValue.increment(-1),
      });

      // Verify counts after approval
      await verifyTeamCounts(teamId);

      // Promote one athlete to coach
      await firestore.collection('teams').doc(teamId).collection('members')
          .doc(memberUids[0]).update({
        'role': 'Coach',
        'updated_at': FieldValue.serverTimestamp(),
      });

      await firestore.collection('teams').doc(teamId).update({
        'coach_count': FieldValue.increment(1),
      });

      // Verify final counts
      await verifyTeamCounts(teamId);
    });

    testWidgets('D. Firestore Rules Alignment - Join Policy Enforcement', (WidgetTester tester) async {
      // Test that rules properly enforce join policies
      
      // Create teams with different policies
      final openTeamId = await createTestTeam('Open Team Rules', 'open');
      final askTeamId = await createTestTeam('Ask Team Rules', 'ask_to_join');
      final closedTeamId = await createTestTeam('Closed Team Rules', 'closed');

      // Sign in as athlete
      await auth.signInWithEmailAndPassword(
        email: testUsers[1]['email']!,
        password: testUsers[1]['password']!,
      );

      // Test open team - should succeed
      try {
        await firestore.collection('teams').doc(openTeamId).collection('members')
            .doc(auth.currentUser!.uid).set({
          'user_id': auth.currentUser!.uid,
          'team_id': openTeamId,
          'role': 'Athlete',
          'status': 'approved',
          'is_owner': false,
          'is_active': true,
          'joined_at': FieldValue.serverTimestamp(),
        });
        // Should succeed
      } catch (e) {
        fail('Open team join should succeed: $e');
      }

      // Test ask_to_join team - should succeed with pending status
      try {
        await firestore.collection('teams').doc(askTeamId).collection('members')
            .doc(auth.currentUser!.uid).set({
          'user_id': auth.currentUser!.uid,
          'team_id': askTeamId,
          'role': 'Athlete',
          'status': 'pending',
          'is_owner': false,
          'is_active': true,
          'joined_at': FieldValue.serverTimestamp(),
        });
        // Should succeed
      } catch (e) {
        fail('Ask to join team should succeed: $e');
      }

      // Test closed team - should fail
      try {
        await firestore.collection('teams').doc(closedTeamId).collection('members')
            .doc(auth.currentUser!.uid).set({
          'user_id': auth.currentUser!.uid,
          'team_id': closedTeamId,
          'role': 'Athlete',
          'status': 'pending',
          'is_owner': false,
          'is_active': true,
          'joined_at': FieldValue.serverTimestamp(),
        });
        
        fail('Closed team join should fail');
      } catch (e) {
        expect(e.toString().contains('permission-denied'), true);
      }
    });

    testWidgets('D. Firestore Rules - Update Join Policy by Owner Only', (WidgetTester tester) async {
      // Ensure we're signed in as the team owner (coach) before creating the team
      await auth.signInWithEmailAndPassword(
        email: testUsers[0]['email']!,
        password: testUsers[0]['password']!,
      );

      // Create team
      final teamId = await createTestTeam('Policy Update Test', 'ask_to_join');
      
      // Owner updates join policy
      await auth.signInWithEmailAndPassword(
        email: testUsers[0]['email']!,
        password: testUsers[0]['password']!,
      );

      try {
        await firestore.collection('teams').doc(teamId).update({
          'join_policy': 'open',
          'updated_at': FieldValue.serverTimestamp(),
        });
        // Should succeed for owner
      } catch (e) {
        fail('Owner should be able to update join policy: $e');
      }

      // Non-owner tries to update join policy
      await auth.signInWithEmailAndPassword(
        email: testUsers[1]['email']!,
        password: testUsers[1]['password']!,
      );

      try {
        await firestore.collection('teams').doc(teamId).update({
          'join_policy': 'closed',
          'updated_at': FieldValue.serverTimestamp(),
        });
        
        fail('Non-owner should not be able to update join policy');
      } catch (e) {
        expect(e.toString().contains('permission-denied'), true);
      }
    });
  });
}