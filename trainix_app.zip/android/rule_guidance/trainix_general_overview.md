# 🧩 Gambaran Umum Trainix (General Overview)

**Trainix** adalah aplikasi **manajemen intensitas latihan atlet Tarung Derajat berbasis Android**.
Aplikasi ini membantu **pelatih (Coach)** dan **atlet (Athlete)** dalam mengelola program latihan, mencatat hasil, serta memantau intensitas dan konsistensi latihan secara digital dan terukur.

Tujuan utamanya adalah:

* Meningkatkan efektivitas manajemen latihan,
* Menggantikan pencatatan manual dengan sistem digital,
* Memantau performa individu dan tim secara real-time,
* Menghadirkan leaderboard mingguan berbasis **intensitas (HRR)** dan **konsistensi kehadiran**.

---

# ⚙️ Struktur dan Aturan Utama (Core Rules)

## 1. Arsitektur Aplikasi

* **Frontend:** Flutter (Android)
* **Backend:** Firebase (Authentication + Firestore Database)
* **Teknologi Pendukung:** Provider (state management), Firebase Storage, Cloud Functions (opsional)
* **Figma UI:** [Trainix App Design v1.3](https://www.figma.com/design/nH8nCKFqzsZDZKTFhHU4SX/Trainix?node-id=0-1)

---

## 2. Role dan Hak Akses

| Role        | Deskripsi                                                                  | Hak Akses                                                                   |
| ----------- | -------------------------------------------------------------------------- | --------------------------------------------------------------------------- |
| **Coach**   | Pembuat dan pengelola tim. Memasukkan data program latihan dan intensitas. | Full Access (write/read) untuk Program, TrainingLog, Reminder, Leaderboard. |
| **Athlete** | Anggota tim yang mengikuti program latihan.                                | Read-only. Tidak dapat mengedit atau membuat entri baru.                    |

📌 **Kebijakan utama:**
TrainingLog dan Program **hanya dapat dibuat dan diubah oleh Coach**.
Athlete hanya dapat **melihat data** tanpa izin menulis.

---

## 3. Struktur Data Firestore

```
/users/{userId}
  id, email, username, name, usia, gender, photo_url,
  tinggi, berat, created_at, updated_at

/teams/{teamId}
  id, name, cabor, kontingen, event, tgl_mulai, tgl_selesai,
  created_by, config { target_days, weights, allow_recovery },
  created_at, updated_at

/teams/{teamId}/members/{userRoleId}
  id, user_id, role("Athlete"|"Coach"), isOwner,
  status("pending"|"approved"), date_joined, approved_by

/teams/{teamId}/programs/{programId}
  id, week_anchor, template, categories, target_days,
  created_by, created_at, updated_at

/teams/{teamId}/trainingLogs/{logId}
  id, programId, athleteId, score, hrr_band, date,
  input_by, created_at, updated_at

/teams/{teamId}/reminders/{reminderId}
  id, title, description, target_date, created_by, status,
  created_at, updated_at

/leaderboards/{leaderboardId}
  id, team_id, week, athleteId,
  scores { consistency, intensity, total },
  eligible, breakdown, last_updated
```

---

## 4. Mekanisme Program dan Latihan

### a. Program Mingguan

* Dibuat oleh **Coach**, berlaku untuk satu minggu latihan.
* Memuat **kategori latihan**: Cardio, Strength, Teknik, Tarung, Recovery/Flexibility.
* Masing-masing kategori bisa diatur agar **dihitung atau tidak** dalam skor intensitas.

### b. Input Intensitas

* Dilakukan oleh **Coach**, menggunakan formula **HRR (Heart Rate Reserve)**.
* **HRmax (Tanaka):** `208 - (0.7 × usia)`
* **Karvonen Formula:** `Target HR = HRrest + (HRR × intensitas)`
* Hasilnya digunakan untuk menentukan **zona latihan (band)** dan **skor mingguan**.

---

## 5. Leaderboard dan Skor

| Komponen                      | Deskripsi                                                                        |
| ----------------------------- | -------------------------------------------------------------------------------- |
| **Konsistensi (Consistency)** | Berdasarkan jumlah sesi latihan yang dilaksanakan dibanding target.              |
| **Intensitas (Intensity)**    | Berdasarkan kesesuaian HRR dengan band target tiap kategori latihan.             |
| **Total Skor (Total)**        | Hasil gabungan dari konsistensi dan intensitas.                                  |
| **Eligible**                  | Status kelayakan masuk leaderboard (misal latihan <50% target → tidak eligible). |
| **Breakdown**                 | Rincian per kategori dan hari latihan.                                           |

Sorting default leaderboard:
`total desc → intensity desc → consistency desc`

---

## 6. UI dan Alur Navigasi

1. **Auth Page (Combined)**

   * Login dan Register dalam **satu halaman** (toggle/tab).
   * Mendukung Firebase Email/Password + Google Sign-In.
   * Setelah login → otomatis ke Home.

2. **Home Page**

   * Header berisi **salam dan tanggal lokal**.
   * Daftar tim aktif, atau pesan **“No teams available”** bila belum tergabung tim.

3. **Teams Page**

   * **Create Team:** Coach otomatis jadi Owner.
   * **Join Team:** via kode → status pending → menunggu approval Coach.
   * Coach Owner dapat **approve/reject** anggota.

4. **Training Page**

   * Menampilkan jadwal program mingguan.
   * **Coach:** dapat menambah/mengedit log intensitas.
   * **Athlete:** hanya dapat melihat.

5. **Leaderboard Page**

   * Menampilkan peringkat atlet berdasarkan skor mingguan.
   * Menyertakan badge “Eligible” dan “Not Eligible”.
   * Bisa difilter per minggu.

6. **Settings Page**

   * Edit profil, ubah foto, logout.

---

## 7. Aturan Keamanan (Firestore Rules)

```js
match /teams/{teamId}/programs/{programId} {
  allow read: if true;
  allow write: if request.auth != null &&
    get(/databases/$(database)/documents/teams/$(teamId)/members/$(request.auth.uid)).data.role == "Coach";
}

match /teams/{teamId}/trainingLogs/{logId} {
  allow read: if true;
  allow write: if request.auth != null &&
    get(/databases/$(database)/documents/teams/$(teamId)/members/$(request.auth.uid)).data.role == "Coach";
}
```

---

## 8. Standar UI/UX & QA Rules

| Area               | Rule Utama                                                          |
| ------------------ | ------------------------------------------------------------------- |
| **Auth**           | Gabungan login/register dalam 1 halaman; logout kembali ke Auth.    |
| **Teams**          | Join → pending approval; hanya Coach Owner dapat approve/reject.    |
| **Program/Log**    | Input/edit hanya Coach; Athlete view-only.                          |
| **Leaderboard**    | Dua skor (konsistensi & intensitas) + total; badge eligible tampil. |
| **Home**           | Header salam + tanggal; empty state bila belum ada tim.             |
| **UI Consistency** | Bottom nav muncul di semua halaman utama.                           |

---

## 9. Prinsip Desain dan Implementasi

* **Modular UI Components** untuk reusability
* **Firestore Real-Time Updates**
* **Audit Fields wajib:** `created_at/by`, `updated_at/by`
* **Offline Persistence** (Firestore cache)
* **Provider Pattern** untuk state management
* **Security by Role Enforcement**

---

## 10. Tujuan Penelitian dan Kontribusi

* Menjadi **model penerapan metode Scrum** dalam pengembangan aplikasi olahraga digital.
* Menyediakan **alat bantu pelatih** untuk mengukur dan mengontrol intensitas latihan atlet dengan lebih objektif.
* Menunjukkan **implementasi nyata metode Agile–Scrum** yang dapat diterapkan untuk penelitian pengembangan perangkat lunak berbasis data latihan.
* Menjadi dasar pengembangan lebih lanjut untuk **fitur periodisasi latihan, AI-based recommendation, dan analisis performa jangka panjang.**
