package com.trainix.trainix_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
